'use client';

import { useState } from 'react';
import { ShoppingBag, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { toast } from '@/hooks/use-toast';

interface PiNetworkAppButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
  showFeatures?: boolean;
  fullWidth?: boolean;
}

export function PiNetworkAppButton({ 
  onSuccess, 
  variant = 'default', 
  showPriceInLabel = true, 
  showFeatures = false,
  fullWidth = false 
}: PiNetworkAppButtonProps) {
  const piAuth = usePiAuth();
  const { go } = useNav();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the Pi network app product using the correct product ID (6a3bde60a47964d7596f0016 - 0.5 Pi)
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a3bde60a47964d7596f0016);

  // Check if already purchased
  const isPiNetworkAppPurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Show activated badge if already purchased
  if (isPiNetworkAppPurchased) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2">
        <ShoppingBag className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium text-primary">Pi Network App Unlocked</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Pi network app not available');
      toast({
        title: 'Error',
        description: 'Pi network app not available',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        
        toast({
          title: 'Success!',
          description: 'Pi Network App unlocked successfully!',
        });
        
        onSuccess?.();
        
        // Refresh data after a short delay
        setTimeout(() => {
          setSuccess(false);
        }, 1500);
      } else {
        setError('Purchase failed. Please try again.');
        toast({
          title: 'Purchase Failed',
          description: 'Please try again.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Pi network app product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      const errorMsg = errorMessages[errorCode] || 'Purchase failed';
      setError(errorMsg);
      toast({
        title: 'Purchase Error',
        description: errorMsg,
        variant: 'destructive',
      });
      console.error('[Pi Network App] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <AlertCircle className="mr-2 h-4 w-4" />
        App Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <ShoppingBag className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel && product ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  const features = [
    'Decentralized Marketplace',
    'Buy & Sell Products',
    'Services & Freelancers',
    'Job Listings',
    'Vehicle Marketplace',
    'Real Estate Hub',
    'Secure Pi Payments',
    'Escrow Protection'
  ];

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg bg-primary/5 border border-primary/20 p-3 space-y-2">
          <h3 className="text-sm font-semibold text-foreground">Pi Network App Features:</h3>
          <ul className="text-xs text-muted-foreground space-y-1">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Zap className="h-3 w-3 mt-0.5 text-primary flex-shrink-0" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading || !product || !sdk}
        variant={buttonVariant}
        className={isDefaultVariant ? `${fullWidth ? 'w-full' : ''} bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 text-primary-foreground` : fullWidth ? 'w-full' : ''}
      >
        <ShoppingBag className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Pi Network App${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          ✓ Pi Network App unlocked successfully!
        </div>
      )}
    </div>
  );
}
