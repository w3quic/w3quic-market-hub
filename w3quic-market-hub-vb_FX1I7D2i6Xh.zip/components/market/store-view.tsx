'use client';
import { useMemo } from 'react';
import Image from 'next/image';
import { Store, Users, TrendingUp, Heart } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { formatPi } from '@/lib/market/helpers';
import { ProductCard } from './product-card';
import { RatingStars, VerifiedBadge } from './ui-bits';
import { Button } from '@/components/ui/button';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty';

export function StoreView({ sellerId }: { sellerId: string }) {
  const market = useMarket();
  const { getSeller, getStore, products, toggleFavoriteSeller, favoriteSellers } = market;
  const { go } = useNav();
  const seller = getSeller(sellerId);
  const store = getStore(sellerId);
  const storeProducts = useMemo(() => products.filter((p) => p.sellerId === sellerId && p.stock > 0), [products, sellerId]);
  const isFavorited = favoriteSellers.includes(sellerId);

  if (!seller || !store) {
    return (
      <Empty className="py-20">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <Store />
          </EmptyMedia>
          <EmptyTitle>Store not found</EmptyTitle>
        </EmptyHeader>
        <Button variant="outline" onClick={() => go({ name: 'home' })}>
          Back home
        </Button>
      </Empty>
    );
  }

  return (
    <div className="animate-fade-in px-4 py-4">
      {/* Store header */}
      <div className="relative -mx-4 mb-4 h-40 w-screen overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 lg:mx-0 lg:rounded-xl">
        {store.bannerUrl && <Image src={store.bannerUrl} alt={store.name} fill className="object-cover" />}
      </div>

      {/* Store info */}
      <div className="mb-4 flex items-start gap-3">
        {store.logoUrl && (
          <div className="relative -mt-12 h-20 w-20 overflow-hidden rounded-lg border-4 border-background">
            <Image src={store.logoUrl} alt={store.name} fill className="object-cover" />
          </div>
        )}
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold">{store.name}</h1>
            <Button
              variant={isFavorited ? 'default' : 'outline'}
              size="sm"
              onClick={() => toggleFavoriteSeller(sellerId)}
            >
              <Heart className={`mr-1 h-4 w-4 ${isFavorited ? 'fill-current' : ''}`} />
              {isFavorited ? 'Following' : 'Follow'}
            </Button>
          </div>
          {store.description && <p className="mt-1 text-sm text-muted-foreground">{store.description}</p>}
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-3 gap-2">
        <StatCard
          icon={<Users className="h-5 w-5" />}
          label="Followers"
          value={store.followersCount}
        />
        <StatCard
          icon={<TrendingUp className="h-5 w-5" />}
          label="Products"
          value={storeProducts.length}
        />
        <StatCard
          icon={<Store className="h-5 w-5" />}
          label="Rating"
          value={seller.rating.toFixed(1)}
        />
      </div>

      {/* Store announcements */}
      {store.announcements && store.announcements.length > 0 && (
        <div className="mt-4">
          <h2 className="mb-2 text-sm font-bold">Announcements</h2>
          {store.announcements.map((a, idx) => (
            <div key={idx} className="rounded-lg border-l-4 border-primary bg-primary/5 p-3 text-sm">
              <p className="font-semibold">{a.title}</p>
              <p className="mt-1 text-muted-foreground">{a.text}</p>
            </div>
          ))}
        </div>
      )}

      {/* Seller info card */}
      <div className="mt-4 rounded-xl border border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">{seller.displayName}</p>
            <div className="mt-1 flex items-center gap-1">
              <RatingStars value={seller.rating} size={12} />
              <span className="text-xs text-muted-foreground">({seller.ratingCount})</span>
              <VerifiedBadge level={seller.verification} />
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Reputation</p>
            <p className="font-bold">{seller.reputationScore}</p>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="mt-4">
        <h2 className="mb-2 text-sm font-bold">Featured products</h2>
        {storeProducts.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Store />
              </EmptyMedia>
              <EmptyTitle>No products available</EmptyTitle>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {storeProducts.slice(0, 12).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>

      {/* Contact */}
      <Button
        className="mt-4 w-full"
        onClick={() => {
          const cid = market.getOrCreateConversation(sellerId);
          go({ name: 'messages', conversationId: cid });
        }}
      >
        Contact seller
      </Button>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="flex flex-col items-center gap-1 rounded-lg border border-border bg-card p-3 text-center">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">{icon}</span>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-bold">{value}</p>
    </div>
  );
}
