'use client';

import { useMemo } from 'react';
import { useMarket } from '@/lib/market/store';
import { formatPi, timeAgo } from '@/lib/market/helpers';
import { VerifiedBadge } from './ui-bits';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Crown, TrendingUp, CheckCircle2 } from 'lucide-react';
import { useNav } from '@/lib/market/nav';
import { PremiumSellerButton } from './premium-seller-button';
import { PremiumSellerSubscriptionButton } from './premium-seller-subscription-button';
import { UnlockAllModulesButton } from './unlock-all-modules-button';
import { ValidationKeyButton } from './validation-key-button';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';

export function SubscriptionManagementView() {
  const market = useMarket();
  const { me } = market;
  const { back } = useNav();

  const premiumBenefits = [
    { icon: '⭐', title: 'Featured Listings', desc: 'Get top placement in search results' },
    { icon: '📊', title: 'Advanced Analytics', desc: 'Detailed sales and customer insights' },
    { icon: '🚀', title: 'Priority Search Visibility', desc: 'Higher ranking in marketplace searches' },
    { icon: '✓', title: 'Seller Verification', desc: 'Blue verified badge to build trust' },
    { icon: '🛠️', title: 'Premium Tools', desc: 'Bulk operations, auto-pricing, scheduling' },
    { icon: '🎯', title: 'Exclusive Promotions', desc: 'Access to promotional campaigns' },
    { icon: '📈', title: 'Growth Features', desc: 'Business intelligence and market insights' },
  ];

  const plans = [
    {
      name: 'Premium Seller',
      price: '0.5',
      period: 'Lifetime',
      description: 'Everything you need to scale your business',
      features: premiumBenefits,
      isCurrent: me?.isPremium,
      productId: '6a34b3d1ac92b4f7f73dd4d3',
    },
  ];

  if (!me.isSeller) {
    return (
      <div className="px-4 py-4">
        <button onClick={back} className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Crown />
            </EmptyMedia>
            <EmptyTitle>Not a seller yet</EmptyTitle>
            <EmptyDescription>Become a seller to access premium subscriptions.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      </div>
    );
  }

  return (
    <div className="animate-fade-in px-4 py-4 pb-20">
      <button onClick={back} className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Back
      </button>

      <h1 className="mb-2 text-2xl font-bold">Subscription Management</h1>
      <p className="mb-6 text-sm text-muted-foreground">Upgrade to Premium Seller and unlock powerful tools to grow your business.</p>

      <div className="space-y-6">
        {/* Premium Seller Subscription Card */}
        <Card className={`overflow-hidden transition-all ${me?.isPremium ? 'border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100/50' : 'hover:shadow-lg'}`}>
          {me?.isPremium && (
            <div className="flex items-center gap-2 bg-purple-200 px-4 py-2 text-sm font-semibold text-purple-900">
              <CheckCircle2 className="h-4 w-4" />
              Current Plan
            </div>
          )}

          <div className="p-6">
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h2 className="mb-1 text-2xl font-bold flex items-center gap-2">
                  <Crown className="h-6 w-6 text-purple-600" />
                  Premium Seller Subscription
                </h2>
                <p className="text-sm text-muted-foreground">Unlock verified seller benefits with one-time payment</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold text-primary">0.5 <span className="text-sm text-muted-foreground">π</span></p>
                <p className="text-xs text-muted-foreground">Lifetime Access</p>
              </div>
            </div>

            {/* Benefits list */}
            <div className="mb-6 space-y-3">
              <p className="text-sm font-semibold text-foreground">What's included:</p>
              <div className="grid grid-cols-1 gap-2">
                {[
                  { icon: '✓', title: 'Verified Seller Badge', desc: 'Build trust with verified badge on all listings' },
                  { icon: '⭐', title: 'Featured Listings', desc: 'Get top placement in search results and categories' },
                  { icon: '🚀', title: 'Priority Search Visibility', desc: 'Higher ranking in marketplace searches' },
                  { icon: '📊', title: 'Advanced Analytics', desc: 'Detailed sales and customer insights' },
                  { icon: '🎯', title: 'Promotional Tools', desc: 'Access to promotional campaigns and features' },
                  { icon: '🛠️', title: 'Premium Features', desc: 'Exclusive seller features and business tools' },
                  { icon: '💎', title: 'Increased Buyer Trust', desc: 'Higher conversion rates with verified status' },
                ].map((feature) => (
                  <div key={feature.title} className="flex gap-3 rounded-lg bg-background p-3">
                    <div className="text-lg flex-shrink-0">{feature.icon}</div>
                    <div>
                      <p className="text-sm font-medium">{feature.title}</p>
                      <p className="text-xs text-muted-foreground">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Current subscription info */}
            {me?.isPremium && (
              <div className="mb-4 rounded-lg border border-green-200 bg-green-50 p-3">
                <p className="text-sm text-green-800">
                  <span className="font-semibold">✓ Active</span> — Enjoy all premium subscription benefits
                </p>
              </div>
            )}

            {/* Action button */}
            {!me?.isPremium ? (
              <PremiumSellerSubscriptionButton 
                variant="default"
                showPriceInLabel={false}
                showFeatures={false}
                fullWidth={true}
                onSuccess={() => {
                  // Optional: show success notification or refresh
                }}
              />
            ) : (
              <Button disabled className="w-full" variant="outline">
                Current Subscription
              </Button>
            )}
          </div>
        </Card>

        {/* Original Premium Seller Plans - kept for reference */}
        {plans.map((plan) => (
          <Card key={plan.name} className={`overflow-hidden transition-all ${plan.isCurrent ? 'border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100/50' : 'hover:shadow-lg'}`}>
            {plan.isCurrent && (
              <div className="flex items-center gap-2 bg-amber-200 px-4 py-2 text-sm font-semibold text-amber-900">
                <CheckCircle2 className="h-4 w-4" />
                Current Plan
              </div>
            )}

            <div className="p-6">
              <div className="mb-4 flex items-start justify-between">
                <div>
                  <h2 className="mb-1 text-2xl font-bold flex items-center gap-2">
                    <Crown className="h-6 w-6 text-amber-600" />
                    {plan.name}
                  </h2>
                  <p className="text-sm text-muted-foreground">{plan.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-primary">{plan.price} <span className="text-sm text-muted-foreground">π</span></p>
                  <p className="text-xs text-muted-foreground">{plan.period}</p>
                </div>
              </div>

              {/* Benefits list */}
              <div className="mb-6 space-y-3">
                <p className="text-sm font-semibold text-foreground">What's included:</p>
                <div className="grid grid-cols-1 gap-2">
                  {plan.features.map((feature) => (
                    <div key={feature.title} className="flex gap-3 rounded-lg bg-background p-3">
                      <div className="text-lg flex-shrink-0">{feature.icon}</div>
                      <div>
                        <p className="text-sm font-medium">{feature.title}</p>
                        <p className="text-xs text-muted-foreground">{feature.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Current subscription info */}
              {plan.isCurrent && (
                <div className="mb-4 rounded-lg border border-green-200 bg-green-50 p-3">
                  <p className="text-sm text-green-800">
                    <span className="font-semibold">✓ Active</span> — Enjoy all premium features
                  </p>
                </div>
              )}

              {/* Action button */}
              {!plan.isCurrent ? (
                <PremiumSellerButton 
                  variant="default"
                  showPriceInLabel={false}
                  showFeatures={false}
                  onSuccess={() => {
                    // Optional: show success notification or refresh
                  }}
                />
              ) : (
                <Button disabled className="w-full" variant="outline">
                  Current Subscription
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      {/* FAQ section */}
      <section className="mt-8">
        <h2 className="mb-4 text-lg font-bold">Frequently Asked Questions</h2>
        <div className="space-y-3">
          {[
            {
              q: 'Can I upgrade anytime?',
              a: 'Yes! You can upgrade to Premium Seller at any time and start enjoying benefits immediately.',
            },
            {
              q: 'Is this a recurring subscription?',
              a: 'No, Premium Seller is a one-time lifetime purchase. Once purchased, you keep your premium status forever.',
            },
            {
              q: 'What if I\'m not satisfied?',
              a: 'Contact our support team within 7 days of purchase for assistance or refund requests.',
            },
            {
              q: 'Do I get support with Premium Seller?',
              a: 'Yes! Premium sellers have access to priority support and dedicated seller resources.',
            },
          ].map((faq, idx) => (
            <div key={idx} className="rounded-lg border border-border p-4">
              <p className="font-semibold text-sm mb-1">{faq.q}</p>
              <p className="text-sm text-muted-foreground">{faq.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Validation Key Section */}
      <section className="mt-8">
        <h2 className="mb-4 text-lg font-bold">Validation Key</h2>
        <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 p-6">
          <div className="mb-4">
            <h3 className="mb-2 text-lg font-semibold text-emerald-900 flex items-center gap-2">
              🔐 Unlock Premium Features
            </h3>
            <p className="text-sm text-emerald-800 mb-4">
              Unlock premium features in Pi Market Hub to promote products, reach more buyers, increase visibility, and enjoy a faster, safer buying and selling experience using Pi cryptocurrency.
            </p>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {[
                '🚀 Promoted Listings',
                '👥 Reach More Buyers',
                '⭐ Increased Visibility',
                '⚡ Faster Processing',
                '🔒 Enhanced Security',
                '🎯 Premium Tools',
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs text-emerald-700">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <ValidationKeyButton 
            variant="default" 
            fullWidth={true}
          />
        </Card>
      </section>

      {/* All Modules Section */}
      <section className="mt-8">
        <h2 className="mb-4 text-lg font-bold">Unlock All Marketplace Modules</h2>
        <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50 p-6">
          <div className="mb-4">
            <h3 className="mb-2 text-lg font-semibold text-emerald-900 flex items-center gap-2">
              🚀 Complete Marketplace Ecosystem
            </h3>
            <p className="text-sm text-emerald-800 mb-4">
              Get instant access to all advanced Pi Market Hub modules including real estate, vehicle marketplace, services platform, jobs board, business center suite, AI tools, community features, advanced analytics, premium business tools, and all future updates.
            </p>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {[
                '🏠 Real Estate',
                '🚗 Vehicles',
                '💼 Services',
                '💼 Jobs',
                '🏢 Business Center',
                '🤖 AI Tools',
                '👥 Community',
                '📊 Analytics',
                '📈 Business Tools',
                '🔄 Future Updates',
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs text-emerald-700">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <UnlockAllModulesButton 
            variant="default" 
            showFeatures={false}
            fullWidth={true}
            showPrice={true}
          />
        </Card>
      </section>

      {/* Call to action */}
      {!me?.isPremium && (
        <section className="mt-8 rounded-lg border border-amber-200 bg-gradient-to-r from-amber-50 to-amber-100 p-6 text-center">
          <h2 className="mb-2 text-lg font-bold text-amber-900">Ready to Scale Your Business?</h2>
          <p className="mb-4 text-sm text-amber-800">Join thousands of sellers using Premium Seller to grow their marketplace presence.</p>
          <PremiumSellerButton variant="default" showFeatures={false} />
        </section>
      )}
    </div>
  );
}
