'use client';

import { useState } from 'react';
import { Zap, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';

interface AdvancedFeaturesButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
}

export function AdvancedFeaturesButton({ 
  onSuccess, 
  variant = 'default', 
  showPriceInLabel = true 
}: AdvancedFeaturesButtonProps) {
  const piAuth = usePiAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the advanced features product
  const product = products?.find(
    p => p.id === PRODUCT_CONFIG.PRODUCT_6a34391f7573bc8a2abd951c
  );

  // Check if already purchased
  const isAdvancedFeaturesActive = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Don't show button if already purchased
  if (isAdvancedFeaturesActive) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2">
        <Zap className="h-4 w-4 text-blue-600" />
        <span className="text-sm font-medium text-blue-700">Advanced Features Active</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Advanced features product not available');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        
        onSuccess?.();
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccess(false);
        }, 3000);
      } else {
        setError('Purchase failed. Please try again.');
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Advanced features product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      setError(errorMessages[errorCode] || 'Purchase failed');
      console.error('[Advanced Features] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className="w-full">
        <AlertCircle className="mr-2 h-4 w-4" />
        Advanced Features Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className="w-full">
        <Zap className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  return (
    <div className="space-y-2">
      <Button
        onClick={handlePurchase}
        disabled={isLoading}
        variant={buttonVariant}
        className={isDefaultVariant ? 'w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white' : 'w-full'}
      >
        <Zap className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Unlock Advanced Features${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          Advanced features activated successfully! 🎉
        </div>
      )}
    </div>
  );
}
