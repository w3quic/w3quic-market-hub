'use client';

import { useState } from 'react';
import { Home, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { toast } from '@/hooks/use-toast';

interface RealEstateButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
  showFeatures?: boolean;
  fullWidth?: boolean;
}

export function RealEstateButton({ 
  onSuccess, 
  variant = 'default', 
  showPriceInLabel = true, 
  showFeatures = false,
  fullWidth = false 
}: RealEstateButtonProps) {
  const piAuth = usePiAuth();
  const { go } = useNav();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the real estate product using the correct product ID (6a34be24a8ef8768974a87be - 0.5 Pi)
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a34be24a8ef8768974a87be);

  // Check if already purchased
  const isRealEstatePurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Show activated badge if already purchased
  if (isRealEstatePurchased) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-3 py-2">
        <Home className="h-4 w-4 text-green-600" />
        <span className="text-sm font-medium text-green-700">Real Estate Hub Activated</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Real estate product not available');
      toast({
        title: 'Error',
        description: 'Real estate product not available',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        
        toast({
          title: 'Success!',
          description: 'Real Estate Hub unlocked successfully!',
        });
        
        onSuccess?.();
        
        // Navigate to real estate hub after a short delay
        setTimeout(() => {
          setSuccess(false);
          go({ name: 'real-estate' });
        }, 1500);
      } else {
        setError('Purchase failed. Please try again.');
        toast({
          title: 'Purchase Failed',
          description: 'Please try again.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Real estate product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      const errorMsg = errorMessages[errorCode] || 'Purchase failed';
      setError(errorMsg);
      toast({
        title: 'Purchase Error',
        description: errorMsg,
        variant: 'destructive',
      });
      console.error('[Real Estate] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <AlertCircle className="mr-2 h-4 w-4" />
        Real Estate Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Home className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel && product ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  const features = [
    'Buy, Sell & Rent Properties',
    'Houses, Apartments & Land',
    'Commercial Properties',
    'Advanced Property Search',
    'Property Verification',
    'Location-Based Filtering',
    'Secure Transactions'
  ];

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg bg-blue-50 border border-blue-200 p-3 space-y-2">
          <h3 className="text-sm font-semibold text-blue-900">Real Estate Hub Features:</h3>
          <ul className="text-xs text-blue-800 space-y-1">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Zap className="h-3 w-3 mt-0.5 text-blue-600 flex-shrink-0" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading || !product || !sdk}
        variant={buttonVariant}
        className={isDefaultVariant ? `${fullWidth ? 'w-full' : ''} bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white` : fullWidth ? 'w-full' : ''}
      >
        <Home className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Real Estate${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          ✓ Real Estate Hub unlocked successfully!
        </div>
      )}
    </div>
  );
}
