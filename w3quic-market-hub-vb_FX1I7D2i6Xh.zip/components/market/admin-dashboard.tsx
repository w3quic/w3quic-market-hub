"use client"

import React, { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import {
  AlertTriangle,
  Users,
  ShoppingCart,
  TrendingUp,
  Activity,
  Shield,
  CheckCircle,
  XCircle,
  Clock,
} from "lucide-react"
import type { MarketplaceAnalytics, SystemMetrics } from "@/lib/market/types"

interface AdminDashboardProps {
  analytics: MarketplaceAnalytics
  metrics: SystemMetrics
  alerts: string[]
  onSuspendSeller?: (sellerId: string) => void
  onApproveVerification?: (verificationId: string) => void
}

export function AdminDashboard({
  analytics,
  metrics,
  alerts,
  onSuspendSeller,
  onApproveVerification,
}: AdminDashboardProps) {
  const [selectedTab, setSelectedTab] = useState("overview")

  const categoryColors = [
    "#3b82f6",
    "#ef4444",
    "#10b981",
    "#f59e0b",
    "#8b5cf6",
  ]

  return (
    <div className="space-y-6">
      {/* Critical Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((alert, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 p-4 bg-red-50 border border-red-200 rounded-lg"
            >
              <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0" />
              <span className="text-sm font-medium text-red-900">{alert}</span>
            </div>
          ))}
        </div>
      )}

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Total Users</p>
              <p className="text-3xl font-bold text-gray-900">
                {analytics.totalUsers.toLocaleString()}
              </p>
            </div>
            <Users className="h-8 w-8 text-blue-600 opacity-20" />
          </div>
          <p className="text-xs text-gray-600 mt-2">
            +{analytics.newUsers} new this month
          </p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Total Orders</p>
              <p className="text-3xl font-bold text-gray-900">
                {analytics.totalOrders.toLocaleString()}
              </p>
            </div>
            <ShoppingCart className="h-8 w-8 text-green-600 opacity-20" />
          </div>
          <p className="text-xs text-gray-600 mt-2">
            ₽{analytics.totalRevenue.toFixed(2)} total revenue
          </p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">Conversion Rate</p>
              <p className="text-3xl font-bold text-gray-900">
                {analytics.conversionRate.toFixed(1)}%
              </p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-600 opacity-20" />
          </div>
          <p className="text-xs text-gray-600 mt-2">
            Avg order: ₽{analytics.averageOrderValue.toFixed(2)}
          </p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 font-medium">System Health</p>
              <p className="text-3xl font-bold text-gray-900">
                {metrics.uptime.toFixed(2)}%
              </p>
            </div>
            <Activity className="h-8 w-8 text-orange-600 opacity-20" />
          </div>
          <p className="text-xs text-gray-600 mt-2">
            Latency: {metrics.apiLatency.toFixed(0)}ms
          </p>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
          <TabsTrigger value="moderation">Moderation</TabsTrigger>
        </TabsList>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          {/* Top Categories */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Top Categories
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analytics.topCategories}
                  dataKey="count"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  label
                >
                  {analytics.topCategories.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={categoryColors[index % categoryColors.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Top Sellers */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Sellers</h3>
            <div className="space-y-3">
              {analytics.topSellers.slice(0, 5).map((seller, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{idx + 1}</Badge>
                    <span className="font-medium text-gray-900">
                      Seller {seller.id.slice(0, 8)}
                    </span>
                  </div>
                  <span className="text-sm font-semibold text-gray-900">
                    {seller.sales} sales
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* System Tab */}
        <TabsContent value="system" className="space-y-4">
          {/* Performance Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">API Latency</h4>
              <div className="text-4xl font-bold text-blue-600 mb-2">
                {metrics.apiLatency.toFixed(0)}ms
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full"
                  style={{ width: `${Math.min(metrics.apiLatency, 100)}%` }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">Target: &lt; 100ms</p>
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Error Rate</h4>
              <div className="text-4xl font-bold text-red-600 mb-2">
                {(metrics.errorRate * 100).toFixed(2)}%
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-red-600 h-2 rounded-full"
                  style={{ width: `${Math.min(metrics.errorRate * 100, 100)}%` }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">Target: &lt; 0.1%</p>
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">Memory Usage</h4>
              <div className="text-4xl font-bold text-purple-600 mb-2">
                {metrics.memoryUsage.toFixed(1)}%
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-purple-600 h-2 rounded-full"
                  style={{ width: `${metrics.memoryUsage}%` }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">Available: 80%</p>
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold text-gray-900 mb-4">CPU Usage</h4>
              <div className="text-4xl font-bold text-orange-600 mb-2">
                {metrics.cpuUsage.toFixed(1)}%
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-orange-600 h-2 rounded-full"
                  style={{ width: `${metrics.cpuUsage}%` }}
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">Healthy: &lt; 70%</p>
            </Card>
          </div>
        </TabsContent>

        {/* Moderation Tab */}
        <TabsContent value="moderation" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="p-6 border-yellow-200 bg-yellow-50">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="h-5 w-5 text-yellow-600" />
                <h4 className="font-semibold text-gray-900">Pending Reviews</h4>
              </div>
              <p className="text-3xl font-bold text-yellow-900 mb-3">12</p>
              <Button variant="outline" size="sm" className="w-full">
                Review Pending Items
              </Button>
            </Card>

            <Card className="p-6 border-red-200 bg-red-50">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="h-5 w-5 text-red-600" />
                <h4 className="font-semibold text-gray-900">Fraud Alerts</h4>
              </div>
              <p className="text-3xl font-bold text-red-900 mb-3">3</p>
              <Button variant="outline" size="sm" className="w-full">
                Review Fraud Cases
              </Button>
            </Card>
          </div>
        </TabsContent>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              User Retention
            </h3>
            <div className="flex items-center gap-8">
              <div>
                <p className="text-sm text-gray-600 font-medium">30-Day Retention</p>
                <p className="text-4xl font-bold text-blue-600">
                  {analytics.userRetention.toFixed(1)}%
                </p>
              </div>
              <div className="flex-1 h-24">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[{ value: analytics.userRetention }]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Line type="monotone" dataKey="value" stroke="#3b82f6" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
