'use client';

import { useState, useMemo } from 'react';
import { Search, Filter, MapPin, Star, Briefcase, CheckCircle2 } from 'lucide-react';
import { useNav } from '@/lib/market/nav';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';
import { EscrowPaymentButton } from './escrow-payment-button';

interface Service {
  id: string;
  title: string;
  provider: string;
  category: 'developer' | 'designer' | 'electrician' | 'plumber' | 'lawyer' | 'doctor' | 'consultant' | 'home-service' | 'freelancer';
  price: number;
  rating: number;
  reviews: number;
  location: string;
  image: string;
  verified: boolean;
  description: string;
}

// Sample services data
const SAMPLE_SERVICES: Service[] = [
  {
    id: '1',
    title: 'Full Stack Web Development',
    provider: 'Alex Developer',
    category: 'developer',
    price: 2.5,
    rating: 4.8,
    reviews: 156,
    location: 'Remote',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional web development services using React, Node.js, and modern stack',
  },
  {
    id: '2',
    title: 'UI/UX Design Services',
    provider: 'Creative Studio',
    category: 'designer',
    price: 1.8,
    rating: 4.9,
    reviews: 203,
    location: 'Remote',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Custom design solutions for web and mobile applications',
  },
  {
    id: '3',
    title: 'Home Electrical Installation',
    provider: 'Pro Electricians',
    category: 'electrician',
    price: 0.8,
    rating: 4.7,
    reviews: 89,
    location: 'Local Service',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional electrical installation and repair services',
  },
  {
    id: '4',
    title: 'Plumbing Services',
    provider: 'QuickFix Plumbing',
    category: 'plumber',
    price: 0.6,
    rating: 4.6,
    reviews: 142,
    location: 'Local Service',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Emergency plumbing repairs and installations',
  },
  {
    id: '5',
    title: 'Legal Consultation',
    provider: 'Law Associates',
    category: 'lawyer',
    price: 3.2,
    rating: 4.9,
    reviews: 67,
    location: 'Remote',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional legal advice and consultation services',
  },
  {
    id: '6',
    title: 'Medical Consultation',
    provider: 'HealthCare Plus',
    category: 'doctor',
    price: 1.2,
    rating: 4.8,
    reviews: 234,
    location: 'Online Consultation',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional medical consultation with qualified doctors',
  },
  {
    id: '7',
    title: 'Business Consulting',
    provider: 'Strategy Experts',
    category: 'consultant',
    price: 4.0,
    rating: 4.9,
    reviews: 78,
    location: 'Remote',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Strategic business consulting and growth planning',
  },
  {
    id: '8',
    title: 'Home Cleaning & Maintenance',
    provider: 'CleanPro Services',
    category: 'home-service',
    price: 0.5,
    rating: 4.7,
    reviews: 312,
    location: 'Local Service',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional home cleaning and maintenance services',
  },
  {
    id: '9',
    title: 'Content Writing & SEO',
    provider: 'WordSmith Freelancers',
    category: 'freelancer',
    price: 0.9,
    rating: 4.8,
    reviews: 156,
    location: 'Remote',
    image: '/placeholder.svg?height=200&width=300',
    verified: true,
    description: 'Professional content writing and SEO optimization services',
  },
];

const CATEGORIES = [
  { id: 'developer', label: 'Developers', icon: '💻' },
  { id: 'designer', label: 'Designers', icon: '🎨' },
  { id: 'electrician', label: 'Electricians', icon: '⚡' },
  { id: 'plumber', label: 'Plumbers', icon: '🔧' },
  { id: 'lawyer', label: 'Lawyers', icon: '⚖️' },
  { id: 'doctor', label: 'Doctors', icon: '🏥' },
  { id: 'consultant', label: 'Consultants', icon: '📊' },
  { id: 'home-service', label: 'Home Services', icon: '🏠' },
  { id: 'freelancer', label: 'Freelancers', icon: '👤' },
];

export function ServicesMarketplaceView() {
  const { go } = useNav();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'rating' | 'price' | 'reviews'>('rating');

  const filteredServices = useMemo(() => {
    let result = SAMPLE_SERVICES;

    if (searchQuery) {
      result = result.filter(
        (s) =>
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.provider.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory) {
      result = result.filter((s) => s.category === selectedCategory);
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'price') return a.price - b.price;
      if (sortBy === 'reviews') return b.reviews - a.reviews;
      return 0;
    });

    return result;
  }, [searchQuery, selectedCategory, sortBy]);

  return (
    <div className="animate-fade-in space-y-4 pb-6">
      {/* Search Bar */}
      <div className="sticky top-14 z-20 space-y-3 bg-background px-4 pt-4">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search services..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {/* Sort Options */}
        <div className="flex gap-2">
          <Button
            variant={sortBy === 'rating' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('rating')}
          >
            Top Rated
          </Button>
          <Button
            variant={sortBy === 'price' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('price')}
          >
            Lowest Price
          </Button>
          <Button
            variant={sortBy === 'reviews' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('reviews')}
          >
            Most Reviewed
          </Button>
        </div>

        {/* Category Filter */}
        <div className="no-scrollbar flex gap-2 overflow-x-auto pb-2">
          <Button
            variant={selectedCategory === null ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(null)}
          >
            All
          </Button>
          {CATEGORIES.map((cat) => (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat.id)}
            >
              {cat.icon} {cat.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Services List */}
      <div className="px-4">
        {filteredServices.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Briefcase />
              </EmptyMedia>
              <EmptyTitle>No services found</EmptyTitle>
              <EmptyDescription>Try adjusting your filters or search query.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {filteredServices.map((service) => (
              <button
                key={service.id}
                onClick={() => go({ name: 'service-detail', id: service.id })}
                className="overflow-hidden rounded-lg border border-border bg-card transition-all hover:shadow-md"
              >
                {/* Image */}
                <div className="relative h-40 w-full bg-muted">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="h-full w-full object-cover"
                  />
                  {service.verified && (
                    <div className="absolute right-2 top-2 flex items-center gap-1 rounded-full bg-green-500/90 px-2 py-1 text-xs font-semibold text-white">
                      <CheckCircle2 className="h-3 w-3" />
                      Verified
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-3">
                  <h3 className="line-clamp-2 text-left font-semibold text-foreground">{service.title}</h3>
                  <p className="text-left text-xs text-muted-foreground">{service.provider}</p>

                  {/* Rating */}
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                      <span className="text-xs font-semibold">{service.rating}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">({service.reviews} reviews)</span>
                  </div>

                  {/* Location */}
                  <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    <MapPin className="h-3 w-3" />
                    {service.location}
                  </div>

                  {/* Price */}
                  <div className="mt-3 flex items-center justify-between">
                    <span className="font-bold text-primary">{service.price} π</span>
                    <Button size="sm" variant="default">
                      View Details
                    </Button>
                  </div>
                </div>
              </button>
            ))}
          </>
        )}
      </div>

      {/* Escrow Protection Button */}
      {filteredServices.length > 0 && (
        <div className="fixed inset-x-0 bottom-20 z-30 mx-auto max-w-2xl px-4">
          <EscrowPaymentButton fullWidth variant="default" />
        </div>
      )}
    </div>
  );
}
