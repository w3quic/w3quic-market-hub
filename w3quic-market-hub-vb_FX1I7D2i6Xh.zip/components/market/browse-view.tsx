"use client"

import { useMemo, useState } from "react"
import { Search, SlidersHorizontal, X } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { CATEGORIES, type Category } from "@/lib/market/types"
import { effectivePrice } from "@/lib/market/helpers"
import { ProductCard } from "./product-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetFooter } from "@/components/ui/sheet"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"
import { VehicleMarketplaceButton } from "./vehicle-marketplace-button"

type Sort = "trending" | "newest" | "price-low" | "price-high" | "rating" | "popularity"

export function BrowseView({ category, query, filter }: { category?: string; query?: string; filter?: string }) {
  const { products, getSeller } = useMarket()
  const [q, setQ] = useState(query || "")
  const [cat, setCat] = useState<Category | "all">((category as Category) || "all")
  const [sort, setSort] = useState<Sort>("trending")
  const [maxPrice, setMaxPrice] = useState(700)
  const [verifiedOnly, setVerifiedOnly] = useState(false)
  const [dealsOnly, setDealsOnly] = useState(filter === "flash")
  const [auctionOnly, setAuctionOnly] = useState(filter === "auction")
  const [sponsoredOnly, setSponsoredOnly] = useState(false)
  const [open, setOpen] = useState(false)

  const list = useMemo(() => {
    let r = products.filter((p) => p.stock > 0 || p.auction)
    if (q.trim()) {
      const s = q.toLowerCase()
      r = r.filter((p) => p.title.toLowerCase().includes(s) || p.description.toLowerCase().includes(s))
    }
    if (cat !== "all") r = r.filter((p) => p.category === cat)
    r = r.filter((p) => effectivePrice(p) <= maxPrice)
    if (verifiedOnly) r = r.filter((p) => { const s = getSeller(p.sellerId); return s && (s.verification === "verified" || s.verification === "trusted") })
    if (dealsOnly) r = r.filter((p) => p.flashDeal && p.flashDeal.endsAt > Date.now())
    if (auctionOnly) r = r.filter((p) => p.auction && p.auction.endsAt > Date.now())
    if (sponsoredOnly) r = r.filter((p) => p.sponsored)

    const sellerRating = (id: string) => getSeller(id)?.rating ?? 0
    switch (sort) {
      case "newest": r = [...r].sort((a, b) => b.createdAt - a.createdAt); break
      case "price-low": r = [...r].sort((a, b) => effectivePrice(a) - effectivePrice(b)); break
      case "price-high": r = [...r].sort((a, b) => effectivePrice(b) - effectivePrice(a)); break
      case "rating": r = [...r].sort((a, b) => sellerRating(b.sellerId) - sellerRating(a.sellerId)); break
      case "popularity": r = [...r].sort((a, b) => b.views - a.views); break
      default: r = [...r].sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || b.views - a.views)
    }
    // boost low scam score / reputation ranking
    return r
  }, [products, q, cat, maxPrice, verifiedOnly, dealsOnly, auctionOnly, sponsoredOnly, sort, getSeller])

  const activeFilters = [verifiedOnly, dealsOnly, auctionOnly, sponsoredOnly].filter(Boolean).length + (maxPrice < 700 ? 1 : 0)

  return (
    <div className="animate-fade-in px-4 py-4">
      <div className="sticky top-14 z-20 -mx-4 mb-3 bg-background/95 px-4 py-2 backdrop-blur">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search products..." className="pl-9" aria-label="Search products" />
            {q && <button onClick={() => setQ("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-label="Clear"><X className="h-4 w-4" /></button>}
          </div>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="relative shrink-0" aria-label="Filters">
                <SlidersHorizontal className="h-4 w-4" />
                {activeFilters > 0 && <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground">{activeFilters}</span>}
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetHeader><SheetTitle>Filters & Sort</SheetTitle></SheetHeader>
              <div className="flex flex-col gap-5 overflow-y-auto px-4 py-2">
                <div className="grid gap-2">
                  <Label>Sort by</Label>
                  <Select value={sort} onValueChange={(v) => setSort(v as Sort)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="trending">Trending / Relevance</SelectItem>
                      <SelectItem value="newest">Newest</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                      <SelectItem value="rating">Top Rated</SelectItem>
                      <SelectItem value="popularity">Most Popular</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Category</Label>
                  <Select value={cat} onValueChange={(v) => setCat(v as Category | "all")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All categories</SelectItem>
                      {CATEGORIES.map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label>Max price: {maxPrice} π</Label>
                  <Slider value={[maxPrice]} min={10} max={700} step={10} onValueChange={(v) => setMaxPrice(v[0])} />
                </div>
                <div className="flex items-center justify-between"><Label htmlFor="vf">Verified sellers only</Label><Switch id="vf" checked={verifiedOnly} onCheckedChange={setVerifiedOnly} /></div>
                <div className="flex items-center justify-between"><Label htmlFor="df">Flash deals only</Label><Switch id="df" checked={dealsOnly} onCheckedChange={setDealsOnly} /></div>
                <div className="flex items-center justify-between"><Label htmlFor="af">Auctions only</Label><Switch id="af" checked={auctionOnly} onCheckedChange={setAuctionOnly} /></div>
                <div className="flex items-center justify-between"><Label htmlFor="sf">Sponsored only</Label><Switch id="sf" checked={sponsoredOnly} onCheckedChange={setSponsoredOnly} /></div>
              </div>
              <SheetFooter>
                <Button onClick={() => setOpen(false)}>Show {list.length} results</Button>
              </SheetFooter>
            </SheetContent>
          </Sheet>
        </div>
        <div className="no-scrollbar mt-2 flex gap-1.5 overflow-x-auto">
          <CatChip active={cat === "all"} onClick={() => setCat("all")} label="All" />
          {CATEGORIES.map((c) => <CatChip key={c.id} active={cat === c.id} onClick={() => setCat(c.id)} label={c.label} />)}
        </div>
      </div>

      {/* Vehicle Marketplace promotional section */}
      <div className="mb-6 rounded-2xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h2 className="text-sm font-bold text-amber-900">Explore Vehicle Marketplace</h2>
            <p className="text-xs text-amber-800 mt-1">Buy, sell & trade vehicles</p>
          </div>
          <span className="text-xs font-semibold bg-amber-600 text-white px-2 py-1 rounded-full">0.5 π</span>
        </div>
        <VehicleMarketplaceButton variant="default" fullWidth={true} />
      </div>

      {list.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Search /></EmptyMedia>
            <EmptyTitle>No products found</EmptyTitle>
            <EmptyDescription>Try adjusting your search or filters.</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {list.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}

function CatChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium transition-colors ${active ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>
      {label}
    </button>
  )
}
