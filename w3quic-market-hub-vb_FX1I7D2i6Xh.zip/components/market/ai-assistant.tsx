"use client"

import { useState, useRef, useEffect } from "react"
import { Sparkles, Send, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { parseShoppingQuery } from "@/lib/market/adapters"
import { formatPi, effectivePrice } from "@/lib/market/helpers"
import type { Product } from "@/lib/market/types"

interface ChatMsg { role: "user" | "bot"; text: string; results?: Product[] }

export function AiAssistant({ open, onClose, contextProductCategory }: { open: boolean; onClose: () => void; contextProductCategory?: string }) {
  const { products } = useMarket()
  const { go } = useNav()
  const [input, setInput] = useState("")
  const [msgs, setMsgs] = useState<ChatMsg[]>([
    { role: "bot", text: "Hi! I'm your Pi shopping assistant. Try: \"find me a cheap laptop under 500 Pi\" or \"good gifts for gamers\"." },
  ])
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }) }, [msgs])

  if (!open) return null

  const ask = (q: string) => {
    if (!q.trim()) return
    const { results, reply } = parseShoppingQuery(q, products)
    setMsgs((m) => [...m, { role: "user", text: q }, { role: "bot", text: reply, results }])
    setInput("")
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/30 backdrop-blur-sm sm:items-center" onClick={onClose}>
      <div
        className="flex h-[80vh] w-full max-w-md flex-col overflow-hidden rounded-t-2xl border border-border bg-card shadow-xl sm:rounded-2xl animate-fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between border-b border-border bg-primary px-4 py-3 text-primary-foreground">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            <h2 className="font-semibold">AI Shopping Assistant</h2>
          </div>
          <button onClick={onClose} aria-label="Close assistant" className="rounded-full p-1 hover:bg-primary-foreground/20">
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {msgs.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className="max-w-[85%] space-y-2">
                <div className={`rounded-2xl px-3 py-2 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                  {m.text}
                </div>
                {m.results && m.results.length > 0 && (
                  <div className="space-y-1.5">
                    {m.results.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => { go({ name: "product", id: p.id }); onClose() }}
                        className="flex w-full items-center gap-2 rounded-lg border border-border bg-background p-2 text-left hover:bg-muted"
                      >
                        <img src={p.images[0] || "/placeholder.svg"} alt={p.title} className="h-10 w-10 rounded object-cover" />
                        <span className="flex-1 line-clamp-1 text-xs font-medium">{p.title}</span>
                        <span className="text-xs font-bold text-primary">{formatPi(effectivePrice(p))}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={endRef} />
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); ask(input) }}
          className="flex items-center gap-2 border-t border-border p-3"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about products..."
            className="h-11 flex-1 rounded-full border border-input bg-background px-4 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <Button type="submit" size="icon" className="h-11 w-11 shrink-0 rounded-full" aria-label="Send">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
    </div>
  )
}
