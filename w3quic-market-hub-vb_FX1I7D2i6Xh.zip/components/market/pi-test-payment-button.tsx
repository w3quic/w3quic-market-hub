'use client';

import { useState } from 'react';
import { Coins, CheckCircle, AlertCircle } from 'lucide-react';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';

interface PiTestPaymentButtonProps {
  variant?: 'default' | 'outline' | 'secondary';
  size?: 'default' | 'sm' | 'lg';
  className?: string;
}

export function PiTestPaymentButton({ 
  variant = 'default', 
  size = 'default', 
  className = '' 
}: PiTestPaymentButtonProps) {
  const { sdk, products, restoredPurchases } = usePiAuth();
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [transactionData, setTransactionData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const productId = PRODUCT_CONFIG.PRODUCT_6a3cbb9a295f7860f52f35f0;
  const product = products?.find(p => p.id === productId);
  const quantity = restoredPurchases?.find(p => p.productId === product?.slug)?.quantity ?? 0;

  if (!product) {
    return (
      <Button 
        disabled 
        variant="outline" 
        size={size}
        className={className}
      >
        <Coins className="h-4 w-4 mr-2" />
        Payment unavailable
      </Button>
    );
  }

  const handlePayment = async () => {
    if (!sdk) {
      setError('Pi SDK not initialized');
      toast({ 
        title: 'Error', 
        description: 'Pi SDK is not initialized. Please refresh and try again.',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const result = await sdk.makePurchase(product.slug);
      
      if (result.ok) {
        const txData = {
          productId: result.productId,
          paymentId: result.paymentId,
          txid: result.txid,
          amount: product.price_in_pi,
          productName: product.name,
          timestamp: new Date().toISOString(),
        };
        
        setTransactionData(txData);
        setShowSuccess(true);
        
        // Store transaction in localStorage
        const existingTx = localStorage.getItem('pi_test_transactions');
        const transactions = existingTx ? JSON.parse(existingTx) : [];
        transactions.push(txData);
        localStorage.setItem('pi_test_transactions', JSON.stringify(transactions));
        
        toast({ 
          title: 'Payment successful!', 
          description: `Paid ${product.price_in_pi} Pi for ${product.name}`,
        });
      } else {
        throw new Error('Payment failed');
      }
    } catch (err: any) {
      const errorMessage = err?.code === 'purchase_cancelled' 
        ? 'Payment was cancelled'
        : err?.code === 'product_not_found'
        ? 'Product not found'
        : err?.message || 'Payment failed. Please try again.';
      
      setError(errorMessage);
      toast({ 
        title: 'Payment failed', 
        description: errorMessage,
        variant: 'destructive'
      });
      console.error('[PiTestPayment] Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        onClick={handlePayment}
        disabled={loading || quantity > 0}
        variant={variant}
        size={size}
        className={`gap-2 ${className}`}
      >
        <Coins className="h-4 w-4" />
        Pay {product.price_in_pi} Pi
        {quantity > 0 && ' ✓'}
      </Button>

      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              Payment Successful
            </DialogTitle>
          </DialogHeader>
          
          {transactionData && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-muted-foreground">Product:</div>
                <div className="font-medium">{transactionData.productName}</div>
                
                <div className="text-muted-foreground">Amount:</div>
                <div className="font-medium">{transactionData.amount} Pi</div>
                
                <div className="text-muted-foreground">Payment ID:</div>
                <div className="font-mono text-xs break-all">{transactionData.paymentId}</div>
                
                <div className="text-muted-foreground">Transaction ID:</div>
                <div className="font-mono text-xs break-all">{transactionData.txid}</div>
                
                <div className="text-muted-foreground">Time:</div>
                <div className="text-xs">{new Date(transactionData.timestamp).toLocaleString()}</div>
              </div>
              
              <div className="bg-muted p-3 rounded text-sm">
                Your transaction has been recorded and is available in Transaction History.
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button onClick={() => setShowSuccess(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {error && (
        <Dialog open={!!error} onOpenChange={() => setError(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-500" />
                Payment Error
              </DialogTitle>
            </DialogHeader>
            
            <div className="text-sm">
              {error}
            </div>
            
            <DialogFooter>
              <Button onClick={() => setError(null)}>
                Dismiss
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
