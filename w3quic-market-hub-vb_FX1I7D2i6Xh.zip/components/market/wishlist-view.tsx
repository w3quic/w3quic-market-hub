"use client"

import { useMemo } from "react"
import { Heart, ShoppingCart } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { ProductCard } from "./product-card"
import { Button } from "@/components/ui/button"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"
import { toast } from "@/hooks/use-toast"

export function WishlistView() {
  const { wishlist, getProduct, addToCart } = useMarket()
  const { go } = useNav()
  const items = useMemo(() => wishlist.map((id) => getProduct(id)).filter(Boolean) as NonNullable<ReturnType<typeof getProduct>>[], [wishlist, getProduct])

  return (
    <div className="animate-fade-in px-4 py-4">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">Wishlist ({items.length})</h1>
        {items.length > 0 && (
          <Button variant="outline" size="sm" onClick={() => { items.forEach((p) => p.variations.length === 0 && addToCart(p.id)); toast({ title: "Moved to cart", description: "Items without options were added." }) }}>
            <ShoppingCart className="mr-1 h-4 w-4" />Move all to cart
          </Button>
        )}
      </div>
      {items.length === 0 ? (
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon"><Heart /></EmptyMedia>
            <EmptyTitle>No saved items</EmptyTitle>
            <EmptyDescription>Tap the heart on any product to save it here.</EmptyDescription>
          </EmptyHeader>
          <Button onClick={() => go({ name: "browse" })}>Browse products</Button>
        </Empty>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  )
}
