"use client"

import { useMemo, useState } from "react"
import Image from "next/image"
import { Check, Truck, Package, MapPin, ShieldCheck, Star, AlertTriangle, MessageCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { formatPi, timeAgo } from "@/lib/market/helpers"
import type { OrderStatus } from "@/lib/market/types"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogClose } from "@/components/ui/dialog"
import { RatingStars } from "./ui-bits"
import { toast } from "@/hooks/use-toast"

const FLOW: OrderStatus[] = ["placed", "confirmed", "shipped", "in-transit", "delivered"]
const LABELS: Record<string, string> = { placed: "Order Placed", confirmed: "Confirmed", shipped: "Shipped", "in-transit": "In Transit", delivered: "Delivered" }

export function OrderDetailView({ id }: { id: string }) {
  const market = useMarket()
  const { orders, getProduct } = market
  const { go } = useNav()
  const order = orders.find((o) => o.id === id)
  const [rating, setRating] = useState(5)
  const [reviewText, setReviewText] = useState("")
  const [disputeReason, setDisputeReason] = useState("Item not as described")
  const [disputeMsg, setDisputeMsg] = useState("")
  const [sellerMsg, setSellerMsg] = useState("")

  const isSeller = order?.sellerId === CURRENT_USER_ID
  const timelineMap = useMemo(() => {
    const m: Record<string, number> = {}
    order?.timeline.forEach((t) => { m[t.status] = t.at })
    return m
  }, [order])

  if (!order) {
    return <div className="px-4 py-6"><Empty><EmptyHeader><EmptyMedia variant="icon"><Package /></EmptyMedia><EmptyTitle>Order not found</EmptyTitle></EmptyHeader><Button onClick={() => go({ name: "orders" })}>Back to orders</Button></Empty></div>
  }

  const currentIdx = FLOW.indexOf(order.status === "completed" ? "delivered" : order.status)
  const product0 = getProduct(order.items[0]?.productId)

  const nextStatus: Record<string, OrderStatus> = { placed: "confirmed", confirmed: "shipped", shipped: "in-transit", "in-transit": "delivered" }

  return (
    <div className="animate-fade-in px-4 py-4">
      <h1 className="text-lg font-bold">Order #{order.id.slice(-6).toUpperCase()}</h1>
      <p className="text-xs text-muted-foreground">Placed {timeAgo(order.createdAt)}</p>

      {/* Items */}
      <section className="mt-3 space-y-2">
        {order.items.map((it) => (
          <div key={`${it.productId}-${it.variationId}`} className="flex gap-3 rounded-xl border border-border bg-card p-3">
            <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-muted">
              <Image src={it.image || "/placeholder.svg"} alt={it.title} fill sizes="64px" className="object-cover" />
            </div>
            <div className="flex-1">
              <p className="line-clamp-2 text-sm font-medium">{it.title}</p>
              {it.variationName && <p className="text-xs text-muted-foreground">{it.variationName}</p>}
              <p className="text-sm font-bold text-primary">{formatPi(it.price)} × {it.quantity}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Escrow status */}
      <div className="mt-3 flex items-center gap-2 rounded-lg bg-primary/5 p-3 text-sm">
        <ShieldCheck className="h-5 w-5 text-primary" />
        <span>Escrow: <span className="font-semibold capitalize">{order.escrowStatus}</span> · {order.escrowStatus === "held" ? "Funds released when delivery is confirmed." : order.escrowStatus === "released" ? "Payment released to seller." : "Refunded to buyer."}</span>
      </div>

      {/* Timeline */}
      {order.status !== "cancelled" && (
        <section className="mt-4 rounded-xl border border-border bg-card p-4">
          <h2 className="mb-3 flex items-center gap-1.5 text-sm font-semibold"><Truck className="h-4 w-4 text-primary" />Delivery tracking</h2>
          <ol className="relative ml-3 border-l border-border">
            {FLOW.map((s, i) => {
              const reached = i <= currentIdx
              return (
                <li key={s} className="mb-4 ml-4 last:mb-0">
                  <span className={cn("absolute -left-[9px] flex h-4 w-4 items-center justify-center rounded-full", reached ? "bg-primary" : "bg-muted")}>
                    {reached && <Check className="h-2.5 w-2.5 text-primary-foreground" />}
                  </span>
                  <p className={cn("text-sm", reached ? "font-medium" : "text-muted-foreground")}>{LABELS[s]}</p>
                  {timelineMap[s] && <p className="text-xs text-muted-foreground">{new Date(timelineMap[s]).toLocaleString()}</p>}
                </li>
              )
            })}
          </ol>
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground"><MapPin className="h-3.5 w-3.5" />Ship to {order.shippingRegion} · Est. {order.estimatedDelivery}</p>
        </section>
      )}

      {/* Totals */}
      <section className="mt-3 rounded-xl border border-border bg-card p-3 text-sm">
        <Row label="Subtotal" value={formatPi(order.subtotal)} />
        {order.discount > 0 && <Row label="Discount" value={`-${formatPi(order.discount)}`} />}
        <Row label="Shipping" value={order.shipping ? formatPi(order.shipping) : "—"} />
        <div className="mt-1 flex justify-between border-t border-border pt-1 font-bold"><span>Total</span><span className="text-primary">{formatPi(order.total)}</span></div>
      </section>

      {/* Seller fulfillment actions */}
      {isSeller && order.status !== "completed" && order.status !== "cancelled" && order.status !== "disputed" && nextStatus[order.status] && (
        <Button className="mt-4 w-full" onClick={() => { market.advanceOrder(order.id, nextStatus[order.status]); toast({ title: `Order marked ${nextStatus[order.status]}` }) }}>
          Mark as {LABELS[nextStatus[order.status]] || nextStatus[order.status]}
        </Button>
      )}

      {/* Buyer: confirm delivery */}
      {!isSeller && order.status === "delivered" && (
        <Button className="mt-4 w-full" onClick={() => { market.advanceOrder(order.id, "completed"); toast({ title: "Delivery confirmed", description: "Escrow released to seller." }) }}>
          <Check className="mr-1 h-4 w-4" />Confirm delivery & release escrow
        </Button>
      )}

      {/* Buyer: leave review */}
      {!isSeller && order.status === "completed" && !order.reviewed && (
        <Dialog>
          <DialogTrigger asChild><Button className="mt-4 w-full" variant="outline"><Star className="mr-1 h-4 w-4" />Leave a review</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Rate your purchase</DialogTitle></DialogHeader>
            <div className="grid gap-3">
              <div className="flex justify-center gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button key={i} onClick={() => setRating(i)} aria-label={`${i} stars`}>
                    <Star className={cn("h-8 w-8", i <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/40")} />
                  </button>
                ))}
              </div>
              <Textarea value={reviewText} onChange={(e) => setReviewText(e.target.value)} placeholder="Share your experience..." rows={3} />
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button onClick={() => { market.addReview({ productId: order.items[0].productId, sellerId: order.sellerId, buyerId: CURRENT_USER_ID, buyerName: market.me.displayName, rating, text: reviewText || "Great!" }); market.addLoyalty(2); toast({ title: "Review posted", description: "+2 loyalty points" }) }}>Post review</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      {order.reviewed && <p className="mt-3 flex items-center gap-1 text-sm text-green-600"><Check className="h-4 w-4" />You reviewed this order</p>}

      {/* Dispute */}
      {!isSeller && ["confirmed", "shipped", "in-transit", "delivered"].includes(order.status) && (
        <Dialog>
          <DialogTrigger asChild><Button variant="ghost" className="mt-2 w-full text-destructive"><AlertTriangle className="mr-1 h-4 w-4" />Open a dispute</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Open a dispute</DialogTitle></DialogHeader>
            <div className="grid gap-2">
              <Label>Reason</Label>
              <Textarea value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)} rows={1} />
              <Label>Describe the issue</Label>
              <Textarea value={disputeMsg} onChange={(e) => setDisputeMsg(e.target.value)} rows={3} placeholder="What went wrong?" />
            </div>
            <DialogFooter><DialogClose asChild><Button variant="destructive" onClick={() => { market.openDispute(order.id, disputeReason, disputeMsg); toast({ title: "Dispute opened" }) }}>Submit dispute</Button></DialogClose></DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Dispute thread */}
      {order.dispute && (
        <section className="mt-4 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm">
          <p className="font-semibold text-destructive">Dispute: {order.dispute.reason}</p>
          <p className="mt-1 text-muted-foreground"><span className="font-medium text-foreground">Buyer:</span> {order.dispute.buyerMsg}</p>
          {order.dispute.sellerMsg && <p className="mt-1 text-muted-foreground"><span className="font-medium text-foreground">Seller:</span> {order.dispute.sellerMsg}</p>}
          {order.dispute.resolution && <p className="mt-1 rounded bg-green-500/10 p-2 text-green-700 dark:text-green-400">Resolved: {order.dispute.resolution}</p>}
          {isSeller && order.dispute.status === "open" && !order.dispute.sellerMsg && (
            <div className="mt-2 flex gap-2">
              <Textarea value={sellerMsg} onChange={(e) => setSellerMsg(e.target.value)} rows={1} placeholder="Respond to the buyer..." />
              <Button size="sm" onClick={() => { market.respondDispute(order.id, sellerMsg); toast({ title: "Response sent" }) }}>Reply</Button>
            </div>
          )}
        </section>
      )}

      <Button variant="outline" className="mt-4 w-full" onClick={() => { const cid = market.getOrCreateConversation(isSeller ? order.buyerId : order.sellerId, product0?.id); go({ name: "messages", conversationId: cid }) }}>
        <MessageCircle className="mr-1 h-4 w-4" />Message {isSeller ? "buyer" : "seller"}
      </Button>
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between py-0.5"><span className="text-muted-foreground">{label}</span><span className="font-medium">{value}</span></div>
}
