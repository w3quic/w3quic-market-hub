'use client';
import { useMemo, useState } from 'react';
import Image from 'next/image';
import { Plus, Edit, BarChart3, DollarSign } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { CURRENT_USER_ID } from '@/lib/market/seed';
import { formatPi } from '@/lib/market/helpers';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from '@/components/ui/empty';
import { EscrowPaymentButton } from './escrow-payment-button';
import { PremiumSubscriptionButton } from './premium-subscription-button';
import { PremiumSellerButton } from './premium-seller-button';
import { PremiumSellerSubscriptionButton } from './premium-seller-subscription-button';
import { PremiumJobListingsButton } from './premium-job-listings-button';
import { AdvancedFeaturesButton } from './advanced-features-button';
import { PiHubAdvancedButton } from './pi-hub-advanced-button';
import { UnlockAllModulesButton } from './unlock-all-modules-button';
import { RealEstateButton } from './real-estate-button';
import { VehicleMarketplaceButton } from './vehicle-marketplace-button';
import { ServicesMarketplaceButton } from './services-marketplace-button';

export function SellerView() {
  const market = useMarket();
  const { go } = useNav();
  const { products, orders, me, updateStore } = market;
  const [tab, setTab] = useState('overview');

  const myProducts = useMemo(() => products.filter((p) => p.sellerId === CURRENT_USER_ID), [products]);
  const myOrders = useMemo(() => orders.filter((o) => o.sellerId === CURRENT_USER_ID), [orders]);
  const completedOrders = myOrders.filter((o) => o.status === 'completed');
  const totalRevenue = completedOrders.reduce((s, o) => s + o.total, 0);
  const avgOrderValue = myOrders.length > 0 ? totalRevenue / myOrders.length : 0;

  if (!me.isSeller) {
    return (
      <div className="px-4 py-6">
        <Empty>
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <DollarSign />
            </EmptyMedia>
            <EmptyTitle>Not a seller yet</EmptyTitle>
            <EmptyDescription>Become a seller to start selling products.</EmptyDescription>
          </EmptyHeader>
          <Button
            onClick={() => {
              market.becomeSeller("My Store");
            }}
          >
            Become a seller
          </Button>
        </Empty>
      </div>
    );
  }

  return (
    <div className="animate-fade-in px-4 py-4 pb-24">
      <h1 className="mb-4 text-xl font-bold">Seller Dashboard</h1>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full">
          <TabsTrigger value="overview" className="flex-1">
            Overview
          </TabsTrigger>
          <TabsTrigger value="products" className="flex-1">
            Products
          </TabsTrigger>
          <TabsTrigger value="orders" className="flex-1">
            Orders
          </TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <KPICard label="Total Sales" value={myOrders.length} />
            <KPICard label="Revenue" value={formatPi(totalRevenue)} />
            <KPICard label="Avg Order Value" value={formatPi(avgOrderValue)} />
            <KPICard label="Products" value={myProducts.length} />
          </div>

          {/* Store settings preview */}
          <div className="rounded-xl border border-border bg-card p-4">
            <h2 className="mb-2 font-semibold">Store Info</h2>
            <p className="text-sm text-muted-foreground">
              Store name, banner, logo, and announcements configured in your store.
            </p>
            <Button variant="outline" className="mt-3 w-full" onClick={() => go({ name: 'store', sellerId: CURRENT_USER_ID })}>
              View store
            </Button>
          </div>

          {/* Escrow Protection section */}
          <div className="rounded-xl border border-green-300 bg-gradient-to-br from-green-50 to-green-100 p-4">
            <h2 className="mb-3 font-semibold text-green-900">Escrow Payment Protection (0.7 π)</h2>
            <p className="text-sm text-green-800 mb-3">
              Secure transactions with buyer protection. Funds are safely held in escrow until the buyer confirms delivery. Includes dispute resolution, transaction tracking, digital receipts, and trusted Pi Payment security.
            </p>
            <EscrowPaymentButton variant="default" className="w-full" />
          </div>

          {/* Premium seller section */}
          <div className={`rounded-xl border-2 bg-gradient-to-br p-4 ${me.isPremium ? 'border-green-300 from-green-50 to-green-100' : 'border-amber-200 from-amber-50 to-amber-100'}`}>
            <h2 className={`mb-2 font-semibold ${me.isPremium ? 'text-green-900' : 'text-amber-900'}`}>
              {me.isPremium ? '✓ Premium Seller Status' : 'Become a Premium Seller'}
            </h2>
            <p className={`text-sm mb-3 ${me.isPremium ? 'text-green-800' : 'text-amber-800'}`}>
              {me.isPremium 
                ? 'You have premium seller status! Enjoy verified seller badge, priority listings, advanced analytics, promotional tools, and increased visibility.'
                : 'Get verified seller status, priority product listings, advanced analytics, promotional tools, and increased visibility to grow your business in the Pi Network marketplace.'
              }
            </p>
            {!me.isPremium ? (
              <PremiumSellerButton 
                onSuccess={() => {
                  // Optional: refresh seller data or show success message
                }}
                variant="default"
                showFeatures={true}
              />
            ) : (
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => go({ name: 'subscription' })}
              >
                View Subscription Details
              </Button>
            )}
          </div>

          {/* Premium seller subscription section */}
          {!me.isPremium && (
            <div className="rounded-xl border border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100 p-4">
              <h2 className="mb-2 font-semibold text-purple-900">Premium Seller Subscription (0.5 π)</h2>
              <p className="text-sm text-purple-800 mb-3">
                Unlock verified seller badge, featured product listings, advanced analytics, promotional tools, priority search visibility, and higher buyer trust across Pi Market Hub.
              </p>
              <PremiumSellerSubscriptionButton 
                variant="default"
                showFeatures={true}
                fullWidth={true}
                onSuccess={() => {
                  // Optional: refresh seller data or show success message
                }}
              />
            </div>
          )}

          {/* Advanced features section */}
          <div className="rounded-xl border border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100 p-4">
            <h2 className="mb-2 font-semibold text-blue-900">Advanced Seller Tools</h2>
            <div className="text-sm text-blue-800 mb-3 space-y-1">
              <p className="font-medium">Unlock powerful tools to scale your business:</p>
              <ul className="list-inside list-disc text-xs space-y-1 ml-2">
                <li>AI-powered product promotion</li>
                <li>Featured listings boost</li>
                <li>Priority search ranking</li>
                <li>Premium analytics dashboard</li>
                <li>Advanced store customization</li>
                <li>Exclusive growth tools</li>
              </ul>
            </div>
            <AdvancedFeaturesButton 
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>

          {/* Pi Market Hub Advanced Features section */}
          <div className="rounded-xl border border-indigo-200 bg-gradient-to-br from-indigo-50 to-indigo-100 p-4">
            <h2 className="mb-3 font-semibold text-indigo-900">Pi Market Hub Advanced Features (0.5 π)</h2>
            <PiHubAdvancedButton 
              showFeatures={true}
              fullWidth={true}
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>

          {/* Unlock All Modules section */}
          <div className="rounded-xl border border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-100 p-4">
            <h2 className="mb-3 font-semibold text-emerald-900">Unlock All Modules (0.5 π)</h2>
            <p className="text-sm text-emerald-800 mb-3">
              Get complete access to all marketplace modules including real estate, vehicles, services, jobs, business center, AI tools, and more!
            </p>
            <UnlockAllModulesButton 
              showFeatures={true}
              fullWidth={true}
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>

          {/* Premium Job Listings section */}
          <div className="rounded-xl border border-cyan-300 bg-gradient-to-br from-cyan-50 to-cyan-100 p-4">
            <h2 className="mb-3 font-semibold text-cyan-900">Premium Job Listings (0.5 π)</h2>
            <p className="text-sm text-cyan-800 mb-3">
              Post featured job opportunities, access verified employers, promote vacancies, receive priority visibility, and connect with trusted job seekers.
            </p>
            <PremiumJobListingsButton 
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
              variant="default"
              className="w-full"
            />
          </div>

          {/* Real Estate Hub section */}
          <div className="rounded-xl border border-blue-300 bg-gradient-to-br from-blue-50 to-blue-100 p-4">
            <h2 className="mb-3 font-semibold text-blue-900">Real Estate Hub (0.5 π)</h2>
            <p className="text-sm text-blue-800 mb-3">
              Unlock access to buy, sell & rent properties. Manage houses, apartments, land, and commercial properties with advanced search and property verification.
            </p>
            <RealEstateButton 
              showFeatures={true}
              fullWidth={true}
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>

          {/* Vehicle Marketplace Hub section */}
          <div className="rounded-xl border border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
            <h2 className="mb-3 font-semibold text-amber-900">Vehicle Marketplace (0.5 π)</h2>
            <p className="text-sm text-amber-800 mb-3">
              Unlock access to buy, sell & trade vehicles. Manage cars, trucks, motorcycles, and heavy equipment with advanced search and seller verification.
            </p>
            <VehicleMarketplaceButton 
              showFeatures={true}
              fullWidth={true}
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>

          {/* Services Marketplace section */}
          <div className="rounded-xl border border-purple-300 bg-gradient-to-br from-purple-50 to-purple-100 p-4">
            <h2 className="mb-3 font-semibold text-purple-900">Services Marketplace (0.5 π)</h2>
            <p className="text-sm text-purple-800 mb-3">
              Unlock access to find and offer professional services. List developers, designers, electricians, plumbers, lawyers, doctors, consultants, home services, and freelancer offerings with booking, ratings, reviews, and verified provider status.
            </p>
            <ServicesMarketplaceButton 
              showFeatures={true}
              fullWidth={true}
              onSuccess={() => {
                // Optional: refresh seller data or show success message
              }}
            />
          </div>
        </TabsContent>

        {/* Products */}
        <TabsContent value="products" className="mt-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-semibold">Your listings ({myProducts.length})</h2>
            <Button size="sm" onClick={() => go({ name: 'create-listing' })}>
              <Plus className="mr-1 h-4 w-4" /> New
            </Button>
          </div>
          {myProducts.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <Plus />
                </EmptyMedia>
                <EmptyTitle>No products yet</EmptyTitle>
                <EmptyDescription>Create your first listing to start selling.</EmptyDescription>
              </EmptyHeader>
              <Button onClick={() => go({ name: 'create-listing' })}>Create listing</Button>
            </Empty>
          ) : (
            <div className="space-y-2">
              {myProducts.map((p) => (
                <div key={p.id} className="flex gap-3 rounded-lg border border-border bg-card p-3">
                  <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-muted">
                    <Image
                      src={p.images[0] || '/placeholder.svg'}
                      alt={p.title}
                      fill
                      sizes="64px"
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="line-clamp-1 text-sm font-medium">{p.title}</p>
                    <p className="text-xs text-muted-foreground">{p.stock} in stock</p>
                    <p className="font-bold text-primary">{formatPi(p.price)}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => go({ name: 'create-listing', editId: p.id })}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Orders */}
        <TabsContent value="orders" className="mt-4">
          <h2 className="mb-3 font-semibold">Incoming orders ({myOrders.length})</h2>
          {myOrders.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <BarChart3 />
                </EmptyMedia>
                <EmptyTitle>No orders yet</EmptyTitle>
              </EmptyHeader>
            </Empty>
          ) : (
            <div className="space-y-2">
              {myOrders.slice(0, 10).map((o) => (
                <button
                  key={o.id}
                  onClick={() => go({ name: 'order', id: o.id })}
                  className="flex gap-3 rounded-lg border border-border bg-card p-3 text-left transition-colors hover:bg-accent"
                >
                  <div className="flex-1">
                    <p className="text-sm font-medium">Order #{o.id.slice(-6).toUpperCase()}</p>
                    <p className="text-xs text-muted-foreground">{o.items.length} item(s) · {formatPi(o.total)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-medium capitalize">{o.status}</p>
                  </div>
                </button>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function KPICard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4 text-center">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-bold">{value}</p>
    </div>
  );
}
