'use client';

import { useState, useEffect } from 'react';
import { Wallet, Copy, Download, Trash2, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';

interface Transaction {
  productId: string;
  paymentId: string;
  txid: string;
  amount: number;
  productName: string;
  timestamp: string;
}

export function TransactionHistoryView() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  useEffect(() => {
    const txData = localStorage.getItem('pi_test_transactions');
    if (txData) {
      try {
        setTransactions(JSON.parse(txData));
      } catch (err) {
        console.error('Failed to load transactions:', err);
      }
    }
  }, []);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: `${label} copied to clipboard` });
  };

  const handleExport = () => {
    const data = JSON.stringify(transactions, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pi-transactions-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: 'Transactions exported' });
  };

  const handleDelete = (index: number) => {
    const newTransactions = transactions.filter((_, i) => i !== index);
    setTransactions(newTransactions);
    localStorage.setItem('pi_test_transactions', JSON.stringify(newTransactions));
    toast({ title: 'Transaction deleted' });
  };

  const handleClearAll = () => {
    localStorage.removeItem('pi_test_transactions');
    setTransactions([]);
    toast({ title: 'All transactions cleared' });
  };

  if (transactions.length === 0) {
    return (
      <div className="animate-fade-in px-4 py-8">
        <div className="rounded-xl border-2 border-dashed border-muted bg-muted/50 p-8 text-center">
          <Wallet className="h-12 w-12 mx-auto text-muted-foreground mb-3 opacity-50" />
          <h3 className="font-semibold text-foreground mb-1">No Transactions Yet</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Your Pi payment test transactions will appear here
          </p>
          <p className="text-xs text-muted-foreground">
            Visit the Home page or Profile to test a payment
          </p>
        </div>
      </div>
    );
  }

  const totalAmount = transactions.reduce((sum, tx) => sum + tx.amount, 0);

  return (
    <div className="animate-fade-in px-4 py-4 space-y-4">
      {/* Summary Card */}
      <div className="rounded-xl border border-border bg-gradient-to-br from-primary/10 to-accent/10 p-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground">Total Paid</h2>
            <p className="text-2xl font-bold text-foreground mt-1">{totalAmount.toFixed(2)} Pi</p>
          </div>
          <div className="bg-primary/20 rounded-lg p-2">
            <TrendingUp className="h-6 w-6 text-primary" />
          </div>
        </div>
        <div className="mt-3 text-xs text-muted-foreground">
          {transactions.length} transaction{transactions.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-semibold text-sm">Transaction History</h3>
          <div className="flex gap-1">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={handleClearAll}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {transactions.map((tx, index) => (
          <button
            key={`${tx.txid}-${index}`}
            onClick={() => setSelectedTx(tx)}
            className="w-full rounded-lg border border-border bg-card p-3 text-left transition-colors hover:bg-accent/50"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="font-medium text-foreground">{tx.productName}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {new Date(tx.timestamp).toLocaleDateString()} at {new Date(tx.timestamp).toLocaleTimeString()}
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-primary">{tx.amount} Pi</p>
                <p className="text-xs text-muted-foreground">ID: {tx.paymentId.slice(0, 8)}...</p>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Transaction Detail Dialog */}
      {selectedTx && (
        <Dialog open={!!selectedTx} onOpenChange={() => setSelectedTx(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs font-medium">Product</p>
                  <p className="font-medium mt-1">{selectedTx.productName}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs font-medium">Amount</p>
                  <p className="font-medium mt-1 text-primary">{selectedTx.amount} Pi</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs font-medium mb-1">Payment ID</p>
                  <div className="flex items-center gap-1">
                    <code className="flex-1 text-xs bg-muted p-2 rounded font-mono break-all">
                      {selectedTx.paymentId}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy(selectedTx.paymentId, 'Payment ID')}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs font-medium mb-1">Transaction ID</p>
                  <div className="flex items-center gap-1">
                    <code className="flex-1 text-xs bg-muted p-2 rounded font-mono break-all">
                      {selectedTx.txid}
                    </code>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopy(selectedTx.txid, 'Transaction ID')}
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs font-medium">Date & Time</p>
                  <p className="text-sm mt-1">
                    {new Date(selectedTx.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="bg-muted p-3 rounded text-xs text-muted-foreground">
                Keep these transaction details for your records and Pi Developer Portal verification.
              </div>
            </div>

            <DialogFooter className="flex gap-2">
              <Button
                variant="destructive"
                onClick={() => {
                  const index = transactions.indexOf(selectedTx);
                  if (index > -1) {
                    handleDelete(index);
                    setSelectedTx(null);
                  }
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
              <Button onClick={() => setSelectedTx(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
