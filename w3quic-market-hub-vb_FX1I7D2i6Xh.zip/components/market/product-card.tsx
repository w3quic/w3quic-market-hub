"use client"

import { useMemo } from "react"
import Image from "next/image"
import { Heart, Zap, Shield, Gavel, AlertTriangle } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Product } from "@/lib/market/types"
import { effectivePrice, formatPi, countdown } from "@/lib/market/helpers"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { RatingStars, Pill, VerifiedBadge } from "./ui-bits"

export function ProductCard({ product, compact }: { product: Product; compact?: boolean }) {
  const { go } = useNav()
  const { toggleWishlist, wishlist, getSeller } = useMarket()
  const seller = getSeller(product.sellerId)
  const liked = wishlist.includes(product.id)
  const onDeal = product.flashDeal && product.flashDeal.endsAt > Date.now()
  const isAuction = product.auction && product.auction.endsAt > Date.now()
  const eff = effectivePrice(product)
  const highestBid = useMemo(() => {
    if (!product.auction) return null
    return product.auction.bids.reduce((m, b) => Math.max(m, b.amount), product.auction.startingBid)
  }, [product.auction])

  return (
    <button
      onClick={() => go({ name: "product", id: product.id })}
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-lg border border-border bg-card text-left transition-all duration-300 hover:shadow-lg hover:border-primary/50 focus:outline-none focus:ring-2 focus:ring-ring active:scale-95",
        compact ? "w-40 shrink-0" : "w-full",
      )}
    >
      <div className="relative aspect-square w-full overflow-hidden bg-muted">
        <Image
          src={product.images[0] || "/placeholder.svg"}
          alt={product.title}
          fill
          sizes="(max-width:768px) 50vw, 200px"
          className="object-cover transition-transform duration-300 group-hover:scale-110"
          priority={false}
        />
        <span className="absolute left-2 top-2 flex flex-wrap gap-1">
          {product.featured && <Pill className="bg-primary/90 backdrop-blur text-primary-foreground animate-fade-in">Featured</Pill>}
          {product.sponsored && <Pill className="bg-foreground/80 backdrop-blur text-background animate-fade-in">Sponsored</Pill>}
          {onDeal && <Pill className="bg-rose-500/90 backdrop-blur text-white"><Zap className="h-3 w-3" />-{product.flashDeal!.discountPercent}%</Pill>}
          {isAuction && <Pill className="bg-amber-500/90 backdrop-blur text-white"><Gavel className="h-3 w-3" />Auction</Pill>}
          {product.scamScore >= 60 && <Pill className="bg-destructive/90 backdrop-blur text-destructive-foreground"><AlertTriangle className="h-3 w-3" />Caution</Pill>}
        </span>
        <button
          type="button"
          aria-label={liked ? "Remove from wishlist" : "Add to wishlist"}
          onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id) }}
          className="absolute right-2 top-2 flex h-9 w-9 items-center justify-center rounded-full bg-background/85 backdrop-blur transition-all hover:bg-background/95 hover:scale-110 active:scale-95"
        >
          <Heart className={cn("h-5 w-5 transition-all", liked ? "fill-rose-500 text-rose-500 scale-110" : "text-foreground")} />
        </button>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-3">
        <p className="line-clamp-2 text-sm font-semibold leading-snug text-card-foreground">{product.title}</p>
        <div className="mt-auto flex items-baseline gap-2">
          {isAuction ? (
            <span className="text-lg font-bold text-primary">{formatPi(highestBid!)}</span>
          ) : (
            <>
              <span className="text-lg font-bold text-primary">{formatPi(eff)}</span>
              {onDeal && <span className="text-xs text-muted-foreground line-through">{formatPi(product.price)}</span>}
            </>
          )}
        </div>
        <div className="flex items-center justify-between gap-2">
          <RatingStars value={seller?.rating ?? 0} size={12} showValue />
          {seller && <VerifiedBadge level={seller.verification} />}
        </div>
        {onDeal && <p className="text-[11px] font-semibold text-rose-500">{countdown(product.flashDeal!.endsAt)} left</p>}
        {isAuction && <p className="text-[11px] font-semibold text-amber-600">{countdown(product.auction!.endsAt)} left</p>}
        {!isAuction && product.stock <= 5 && product.stock > 0 && <p className="text-[11px] font-semibold text-orange-500">Only {product.stock} left</p>}
        <p className="flex items-center gap-1 text-[11px] text-muted-foreground"><Shield className="h-3 w-3 flex-shrink-0" />Buyer protected</p>
      </div>
    </button>
  )
}
