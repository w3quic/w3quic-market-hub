"use client"

import { useMemo, useState } from "react"
import Image from "next/image"
import { Package, Shield } from "lucide-react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { formatPi, timeAgo } from "@/lib/market/helpers"
import type { Order, OrderStatus } from "@/lib/market/types"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"
import { Pill } from "./ui-bits"

const STATUS_STYLE: Record<OrderStatus, string> = {
  placed: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
  confirmed: "bg-blue-500/15 text-blue-600 dark:text-blue-400",
  shipped: "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  "in-transit": "bg-amber-500/15 text-amber-600 dark:text-amber-400",
  delivered: "bg-green-500/15 text-green-600 dark:text-green-400",
  completed: "bg-green-500/15 text-green-600 dark:text-green-400",
  disputed: "bg-destructive/15 text-destructive",
  cancelled: "bg-muted text-muted-foreground",
}

export function OrderRow({ order }: { order: Order }) {
  const { go } = useNav()
  return (
    <button onClick={() => go({ name: "order", id: order.id })} className="flex w-full gap-3 rounded-xl border border-border bg-card p-3 text-left">
      <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg bg-muted">
        <Image src={order.items[0]?.image || "/placeholder.svg"} alt={order.items[0]?.title || "Order"} fill sizes="64px" className="object-cover" />
      </div>
      <div className="flex flex-1 flex-col">
        <p className="line-clamp-1 text-sm font-medium">{order.items[0]?.title}{order.items.length > 1 ? ` +${order.items.length - 1} more` : ""}</p>
        <p className="text-xs text-muted-foreground">{timeAgo(order.createdAt)} · {formatPi(order.total)}</p>
        <div className="mt-auto flex items-center gap-2">
          <Pill className={STATUS_STYLE[order.status]}>{order.status}</Pill>
          {order.escrowStatus === "held" && <span className="flex items-center gap-0.5 text-[10px] text-primary"><Shield className="h-3 w-3" />Escrow</span>}
        </div>
      </div>
    </button>
  )
}

export function OrdersView() {
  const { orders, me } = useMarket()
  const buyerOrders = useMemo(() => orders.filter((o) => o.buyerId === CURRENT_USER_ID), [orders])
  const sellerOrders = useMemo(() => orders.filter((o) => o.sellerId === CURRENT_USER_ID), [orders])
  const [scope, setScope] = useState<"buying" | "selling">("buying")

  const list = scope === "buying" ? buyerOrders : sellerOrders
  const active = list.filter((o) => !["completed", "cancelled"].includes(o.status))
  const done = list.filter((o) => ["completed", "cancelled"].includes(o.status))
  const disputed = list.filter((o) => o.status === "disputed")

  return (
    <div className="animate-fade-in px-4 py-4">
      <h1 className="mb-3 text-xl font-bold">Orders</h1>
      {me.isSeller && (
        <div className="mb-3 flex gap-2">
          <ScopeBtn active={scope === "buying"} onClick={() => setScope("buying")} label={`Buying (${buyerOrders.length})`} />
          <ScopeBtn active={scope === "selling"} onClick={() => setScope("selling")} label={`Selling (${sellerOrders.length})`} />
        </div>
      )}
      <Tabs defaultValue="active">
        <TabsList className="w-full">
          <TabsTrigger value="active" className="flex-1">Active ({active.length})</TabsTrigger>
          <TabsTrigger value="completed" className="flex-1">Completed ({done.length})</TabsTrigger>
          <TabsTrigger value="disputed" className="flex-1">Disputed ({disputed.length})</TabsTrigger>
        </TabsList>
        {([["active", active], ["completed", done], ["disputed", disputed]] as const).map(([key, arr]) => (
          <TabsContent key={key} value={key} className="mt-3 space-y-3">
            {arr.length === 0 ? (
              <Empty>
                <EmptyHeader><EmptyMedia variant="icon"><Package /></EmptyMedia><EmptyTitle>No {key} orders</EmptyTitle><EmptyDescription>They will appear here.</EmptyDescription></EmptyHeader>
              </Empty>
            ) : arr.map((o) => <OrderRow key={o.id} order={o} />)}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function ScopeBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return <button onClick={onClick} className={`flex-1 rounded-lg px-3 py-2 text-sm font-medium ${active ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}>{label}</button>
}
