'use client';

import { useState } from 'react';
import { Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';

interface PremiumSubscriptionButtonProps {
  onSuccess?: () => void;
}

export function PremiumSubscriptionButton({ onSuccess }: PremiumSubscriptionButtonProps) {
  const { products, sdk, restoredPurchases } = usePiAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Find the product
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a33675a4171349062e8b435);

  // Check if already purchased
  const isPurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Premium product not available');
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result.ok) {
        setSuccess(true);
        onSuccess?.();
        // Optional: Consume the product if it's non-renewable
        // await sdk.state.consume(product.slug, 1);
      } else {
        setError('Purchase failed');
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Premium subscription product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      setError(errorMessages[errorCode] || 'Purchase failed');
    } finally {
      setIsLoading(false);
    }
  };

  if (!product) {
    return (
      <Button disabled variant="outline" className="w-full">
        <Crown className="mr-2 h-4 w-4" />
        Premium Unavailable
      </Button>
    );
  }

  if (isPurchased) {
    return (
      <Button disabled variant="outline" className="w-full">
        <Crown className="mr-2 h-4 w-4" />
        Already Premium
      </Button>
    );
  }

  return (
    <div className="space-y-2">
      <Button
        onClick={handlePurchase}
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
      >
        <Crown className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing...' : `Upgrade Premium (${product.price_in_pi} π)`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          {error}
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          Premium subscription activated successfully!
        </div>
      )}
    </div>
  );
}
