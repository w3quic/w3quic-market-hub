'use client';
import { useMemo } from 'react';
import { Gift, TrendingUp, Users } from 'lucide-react';
import { useMarket } from '@/lib/market/store';
import { formatPi } from '@/lib/market/helpers';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function LoyaltyView() {
  const market = useMarket();
  const { me, orders } = market;
  const buyerOrders = useMemo(() => orders.filter((o) => o.buyerId === me.id), [orders, me.id]);
  const sellerOrders = useMemo(() => orders.filter((o) => o.sellerId === me.id), [orders, me.id]);

  const badges = [
    me.isSeller && me.ratingCount >= 100 && 'Top Rated',
    me.isSeller && sellerOrders.length >= 100 && '100 Sales',
    me.isSeller && sellerOrders.length >= 500 && '500 Sales',
    me.verification === 'verified' && 'Verified Seller',
    buyerOrders.length >= 50 && '50 Purchases',
  ].filter(Boolean) as string[];

  return (
    <div className="animate-fade-in px-4 py-4">
      <h1 className="mb-4 text-xl font-bold">Loyalty & Rewards</h1>

      <Tabs defaultValue="points">
        <TabsList className="w-full">
          <TabsTrigger value="points" className="flex-1">
            Points
          </TabsTrigger>
          <TabsTrigger value="badges" className="flex-1">
            Badges
          </TabsTrigger>
          <TabsTrigger value="referrals" className="flex-1">
            Referrals
          </TabsTrigger>
        </TabsList>

        {/* Points */}
        <TabsContent value="points" className="mt-4 space-y-4">
          <Card className="bg-gradient-to-br from-primary/10 to-accent/10 p-6">
            <p className="text-sm text-muted-foreground">Total Loyalty Points</p>
            <p className="mt-1 text-4xl font-bold text-primary">{me.loyaltyPoints}</p>
            <p className="mt-2 text-xs text-muted-foreground">
              1 point per 1 π spent · 10 points = 1 π discount at checkout
            </p>
          </Card>

          <div className="rounded-lg border border-border bg-card p-4">
            <h2 className="mb-3 flex items-center gap-2 font-semibold">
              <TrendingUp className="h-4 w-4" /> How to earn
            </h2>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Purchase items: 1 point per π spent</li>
              <li>• Leave a review: +2 points</li>
              <li>• Daily login: 1-7 points (streak bonus)</li>
              <li>• Referral bonus: 10 points when friend makes first purchase</li>
              {me.isSeller && <li>• Complete sales: 5% of order value as points</li>}
            </ul>
          </div>

          <div className="rounded-lg border border-orange-500/30 bg-orange-500/5 p-4">
            <h2 className="mb-2 font-semibold text-orange-700 dark:text-orange-400">
              Next milestone
            </h2>
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <div className="h-2 rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-orange-500"
                    style={{ width: `${Math.min((me.loyaltyPoints % 100) / 100, 1) * 100}%` }}
                  />
                </div>
              </div>
              <span className="text-sm text-orange-700 dark:text-orange-400">
                {me.loyaltyPoints % 100}/100
              </span>
            </div>
            {(me.loyaltyPoints % 100) + 1 === 100 && (
              <p className="mt-2 text-xs font-medium text-orange-700 dark:text-orange-400">
                🎉 Almost there! Earn {100 - (me.loyaltyPoints % 100)} more points for a reward.
              </p>
            )}
          </div>
        </TabsContent>

        {/* Badges */}
        <TabsContent value="badges" className="mt-4">
          <h2 className="mb-3 flex items-center gap-2 font-semibold">
            <Gift className="h-4 w-4" /> Your badges ({badges.length})
          </h2>
          {badges.length === 0 ? (
            <Card className="p-4 text-center text-sm text-muted-foreground">
              Keep shopping and interacting to earn badges!
            </Card>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {badges.map((badge) => (
                <Card key={badge} className="flex items-center gap-2 p-3">
                  <span className="text-xl">🏆</span>
                  <span className="text-sm font-medium">{badge}</span>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Referrals */}
        <TabsContent value="referrals" className="mt-4 space-y-3">
          <Card className="bg-primary/5 p-4">
            <h2 className="mb-2 flex items-center gap-2 font-semibold">
              <Users className="h-4 w-4" /> Referral Program
            </h2>
            <p className="text-sm text-muted-foreground">
              Share your referral code and earn 10 loyalty points for each friend&apos;s first purchase.
            </p>
          </Card>

          <Card className="p-4">
            <p className="text-xs text-muted-foreground">Your referral code</p>
            <div className="mt-2 flex items-center gap-2 rounded-lg border border-border bg-background p-2">
              <code className="flex-1 text-sm font-mono font-bold">REF-{me.id.slice(0, 8).toUpperCase()}</code>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(`REF-${me.id.slice(0, 8).toUpperCase()}`);
                }}
                className="text-xs text-primary"
              >
                Copy
              </button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Share this code with friends. They enter it during signup to get a discount, and you both earn rewards.
            </p>
          </Card>

          <Card className="p-4 text-sm">
            <p className="font-semibold">Referred friends: {me.referralCount || 0}</p>
            <p className="mt-1 text-muted-foreground">Points earned: {(me.referralCount || 0) * 10}</p>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
