"use client"

import { useState } from "react"
import { Shield, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"
import { usePiAuth } from "@/contexts/pi-auth-context"
import { PRODUCT_CONFIG } from "@/lib/product-config"
import { formatPi } from "@/lib/market/helpers"

interface EscrowPaymentButtonProps {
  variant?: "default" | "outline" | "ghost"
  size?: "default" | "sm" | "lg"
  className?: string
  fullWidth?: boolean
  onSuccess?: (result: any) => void
}

export function EscrowPaymentButton({
  variant = "outline",
  size = "default",
  className = "",
  fullWidth = false,
  onSuccess,
}: EscrowPaymentButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { sdk, products, restoredPurchases } = usePiAuth()

  const productId = PRODUCT_CONFIG.PRODUCT_6a34d2eeb44b5e3079132052
  const product = products?.find((p) => p.id === productId)

  if (!product) {
    return (
      <Button variant="ghost" size={size} className="text-muted-foreground" disabled>
        <AlertCircle className="mr-2 h-4 w-4" />
        Escrow protection unavailable
      </Button>
    )
  }

  const amount = product.price_in_pi
  const quantity = restoredPurchases?.find(
    (p) => p.productId === product.slug
  )?.quantity ?? 0

  const handlePurchase = async () => {
    if (!sdk) {
      toast({
        title: "Authentication required",
        description: "Please wait for Pi authentication to complete.",
        variant: "destructive",
      })
      return
    }

    if (!product) {
      toast({
        title: "Product not found",
        description: "Escrow protection is not available at this time.",
        variant: "destructive",
      })
      return
    }

    try {
      setIsLoading(true)

      const result = await sdk.makePurchase(product.slug)

      if (result.ok) {
        // Consume the product if it's consumable (one-time use)
        if (product.is_consumable) {
          await sdk.state.consume(product.slug, 1)
        }

        toast({
          title: "Escrow protection activated!",
          description: "Your transactions are now protected by secure escrow.",
        })

        if (onSuccess) {
          onSuccess(result)
        }
      } else {
        toast({
          title: "Purchase failed",
          description: result.error || "Unable to activate escrow protection.",
          variant: "destructive",
        })
      }
    } catch (error: any) {
      const errorCode = error?.code
      let errorMessage = "Failed to process purchase."

      if (errorCode === "product_not_found") {
        errorMessage = "Escrow protection product not found."
      } else if (errorCode === "purchase_cancelled") {
        errorMessage = "Purchase cancelled."
      } else if (errorCode === "purchase_error") {
        errorMessage = "Payment failed. Please try again."
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button
      onClick={handlePurchase}
      disabled={isLoading || !sdk}
      variant={variant}
      size={size}
      className={`${fullWidth ? "w-full" : ""} ${className}`}
    >
      <Shield className="mr-2 h-4 w-4" />
      {isLoading ? "Processing..." : `Escrow Protection · ${formatPi(amount)}`}
    </Button>
  )
}
