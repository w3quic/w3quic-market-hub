'use client';

import { useState } from 'react';
import { Briefcase, AlertCircle, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePiAuth } from '@/contexts/pi-auth-context';
import { PRODUCT_CONFIG } from '@/lib/product-config';
import { useMarket } from '@/lib/market/store';
import { useNav } from '@/lib/market/nav';
import { toast } from '@/hooks/use-toast';

interface ServicesMarketplaceButtonProps {
  onSuccess?: () => void;
  variant?: 'default' | 'outline';
  showPriceInLabel?: boolean;
  showFeatures?: boolean;
  fullWidth?: boolean;
}

export function ServicesMarketplaceButton({ 
  onSuccess, 
  variant = 'default', 
  showPriceInLabel = true, 
  showFeatures = false,
  fullWidth = false 
}: ServicesMarketplaceButtonProps) {
  const piAuth = usePiAuth();
  const { go } = useNav();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const { products, sdk, restoredPurchases } = piAuth || {};

  // Find the services marketplace product using the correct product ID (6a34c68a714b2a26856782b4 - 0.5 Pi)
  const product = products?.find(p => p.id === PRODUCT_CONFIG.PRODUCT_6a34c68a714b2a26856782b4);

  // Check if already purchased
  const isServicesMarketplacePurchased = restoredPurchases?.some(
    p => p.productId === product?.slug
  );

  // Show activated badge if already purchased
  if (isServicesMarketplacePurchased) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-green-200 bg-green-50 px-3 py-2">
        <Briefcase className="h-4 w-4 text-green-600" />
        <span className="text-sm font-medium text-green-700">Services Marketplace Activated</span>
      </div>
    );
  }

  const handlePurchase = async () => {
    if (!product || !sdk) {
      setError('Services marketplace product not available');
      toast({
        title: 'Error',
        description: 'Services marketplace product not available',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSuccess(false);

    try {
      const result = await sdk.makePurchase(product.slug);

      if (result?.ok) {
        setSuccess(true);
        
        toast({
          title: 'Success!',
          description: 'Services Marketplace unlocked successfully!',
        });
        
        onSuccess?.();
        
        // Navigate to services marketplace after a short delay
        setTimeout(() => {
          setSuccess(false);
          go({ name: 'services' });
        }, 1500);
      } else {
        setError('Purchase failed. Please try again.');
        toast({
          title: 'Purchase Failed',
          description: 'Please try again.',
          variant: 'destructive',
        });
      }
    } catch (err: any) {
      const errorCode = err?.code || 'unknown_error';
      const errorMessages: Record<string, string> = {
        product_not_found: 'Services marketplace product not found',
        purchase_cancelled: 'Purchase was cancelled',
        purchase_error: 'An error occurred during purchase',
        unknown_error: 'An unexpected error occurred',
      };
      const errorMsg = errorMessages[errorCode] || 'Purchase failed';
      setError(errorMsg);
      toast({
        title: 'Purchase Error',
        description: errorMsg,
        variant: 'destructive',
      });
      console.error('[Services] Purchase error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Product not available
  if (!product) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <AlertCircle className="mr-2 h-4 w-4" />
        Services Unavailable
      </Button>
    );
  }

  // SDK not ready
  if (!sdk || !piAuth?.isAuthenticated) {
    return (
      <Button disabled variant="outline" className={fullWidth ? 'w-full' : ''}>
        <Briefcase className="mr-2 h-4 w-4" />
        Loading...
      </Button>
    );
  }

  const priceLabel = showPriceInLabel && product ? ` (${product.price_in_pi} π)` : '';
  const buttonVariant = variant === 'outline' ? 'outline' : 'default';
  const isDefaultVariant = variant === 'default';

  const features = [
    'Find Professional Services',
    'Developers, Designers & Electricians',
    'Plumbers, Lawyers & Doctors',
    'Consultants & Home Services',
    'Freelancers & Experts',
    'Service Booking System',
    'Ratings & Reviews',
    'Verified Providers',
    'Secure Pi Payments'
  ];

  return (
    <div className="space-y-3">
      {showFeatures && (
        <div className="rounded-lg bg-purple-50 border border-purple-200 p-3 space-y-2">
          <h3 className="text-sm font-semibold text-purple-900">Services Marketplace Features:</h3>
          <ul className="text-xs text-purple-800 space-y-1">
            {features.map((f) => (
              <li key={f} className="flex items-start gap-2">
                <Zap className="h-3 w-3 mt-0.5 text-purple-600 flex-shrink-0" />
                <span>{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Button
        onClick={handlePurchase}
        disabled={isLoading || !product || !sdk}
        variant={buttonVariant}
        className={isDefaultVariant ? `${fullWidth ? 'w-full' : ''} bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white` : fullWidth ? 'w-full' : ''}
      >
        <Briefcase className="mr-2 h-4 w-4" />
        {isLoading ? 'Processing Payment...' : `Services Marketplace${priceLabel}`}
      </Button>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700 flex items-start gap-2">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {success && (
        <div className="rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-700">
          ✓ Services Marketplace unlocked successfully!
        </div>
      )}
    </div>
  );
}
