"use client"

import { useMemo } from "react"
import {
  Bell, MessageCircle, Package, Star, AlertTriangle, Zap, Gavel, Tag, Megaphone, Award, Gift, CheckCheck,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { CURRENT_USER_ID } from "@/lib/market/seed"
import { timeAgo } from "@/lib/market/helpers"
import type { NotificationType } from "@/lib/market/types"
import { Button } from "@/components/ui/button"
import { Empty, EmptyHeader, EmptyMedia, EmptyTitle, EmptyDescription } from "@/components/ui/empty"

const ICONS: Record<NotificationType, typeof Bell> = {
  message: MessageCircle, order: Package, review: Star, dispute: AlertTriangle,
  flash: Zap, flagged: AlertTriangle, auction: Gavel, offer: Tag,
  announcement: Megaphone, achievement: Award, reward: Gift,
}

export function NotificationsView() {
  const { notifications, markNotificationRead, markAllRead, getProduct } = useMarket()
  const { go } = useNav()
  const mine = useMemo(() => notifications.filter((n) => n.userId === CURRENT_USER_ID).sort((a, b) => b.at - a.at), [notifications])
  const unread = mine.filter((n) => !n.read).length

  const open = (id: string, link?: string) => {
    markNotificationRead(id)
    if (!link) return
    if (getProduct(link)) go({ name: "product", id: link })
    else if (link.startsWith("o-")) go({ name: "order", id: link })
  }

  return (
    <div className="animate-fade-in px-4 py-4">
      <div className="mb-3 flex items-center justify-between">
        <h1 className="text-xl font-bold">Notifications</h1>
        {unread > 0 && <Button variant="ghost" size="sm" onClick={markAllRead}><CheckCheck className="mr-1 h-4 w-4" />Mark all read</Button>}
      </div>
      {mine.length === 0 ? (
        <Empty>
          <EmptyHeader><EmptyMedia variant="icon"><Bell /></EmptyMedia><EmptyTitle>No notifications</EmptyTitle><EmptyDescription>Updates about orders, offers, and deals appear here.</EmptyDescription></EmptyHeader>
        </Empty>
      ) : (
        <div className="space-y-2">
          {mine.map((n) => {
            const Icon = ICONS[n.type] || Bell
            return (
              <button key={n.id} onClick={() => open(n.id, n.link)} className={cn("flex w-full gap-3 rounded-xl border p-3 text-left transition-colors", n.read ? "border-border bg-card" : "border-primary/30 bg-primary/5")}>
                <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-full", n.read ? "bg-muted text-muted-foreground" : "bg-primary/15 text-primary")}><Icon className="h-4 w-4" /></span>
                <span className="flex-1">
                  <span className="flex items-center justify-between">
                    <span className="text-sm font-medium">{n.title}</span>
                    {!n.read && <span className="h-2 w-2 rounded-full bg-primary" />}
                  </span>
                  <span className="block text-xs text-muted-foreground">{n.body}</span>
                  <span className="block text-[10px] text-muted-foreground">{timeAgo(n.at)}</span>
                </span>
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
