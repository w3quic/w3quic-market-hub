"use client"

import { useState } from "react"
import { useMarket } from "@/lib/market/store"
import { useNav } from "@/lib/market/nav"
import { VerifiedBadge } from "./ui-bits"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger, DialogClose } from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"
import { Moon, Sun, Globe, BellRing, ShieldCheck, FileCheck, ChevronLeft, LogOut, Crown } from "lucide-react"
import { PremiumSellerButton } from "./premium-seller-button"
import { PremiumSellerSubscriptionButton } from "./premium-seller-subscription-button"
import { PremiumJobListingsButton } from "./premium-job-listings-button"
import { AdvancedFeaturesButton } from "./advanced-features-button"
import { PiHubAdvancedButton } from "./pi-hub-advanced-button"
import { UnlockAllModulesButton } from "./unlock-all-modules-button"
import { ValidationKeyButton } from "./validation-key-button"

export function SettingsView() {
  const m = useMarket()
  const { go, back } = useNav()
  const me = m.me
  const [lang, setLang] = useState("en")
  const [prefs, setPrefs] = useState({ orders: true, messages: true, deals: true, achievements: true })

  function submitKyc(level: "trusted" | "verified") {
    m.updateMe({ verification: level })
    toast({
      title: "Verification submitted",
      description: level === "verified" ? "Full KYC submitted — mock approval granted." : "ID submitted — Trusted level granted.",
    })
  }

  return (
    <div className="animate-fade-in p-4 pb-8">
      <button onClick={back} className="mb-3 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-4 w-4" /> Back
      </button>
      <h1 className="mb-4 text-xl font-bold">Settings</h1>

      {/* Appearance */}
      <SectionTitle>Appearance</SectionTitle>
      <Card className="mb-4 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {m.theme === "dark" ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-primary" />}
            <div>
              <Label className="text-sm font-semibold">Dark Mode</Label>
              <p className="text-xs text-muted-foreground">Switch between light and dark themes</p>
            </div>
          </div>
          <Switch checked={m.theme === "dark"} onCheckedChange={() => m.toggleTheme()} aria-label="Toggle dark mode" />
        </div>
      </Card>

      {/* Language */}
      <SectionTitle>Language</SectionTitle>
      <Card className="mb-4 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Globe className="h-5 w-5 text-primary" />
            <div>
              <Label className="text-sm font-semibold">App Language</Label>
              <p className="text-xs text-muted-foreground">More languages coming soon</p>
            </div>
          </div>
          <Select value={lang} onValueChange={setLang}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="es" disabled>Español (soon)</SelectItem>
              <SelectItem value="fr" disabled>Français (soon)</SelectItem>
              <SelectItem value="zh" disabled>中文 (soon)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Notifications */}
      <SectionTitle>Notification Preferences</SectionTitle>
      <Card className="mb-4 divide-y p-0">
        {([
          ["orders", "Order updates"],
          ["messages", "New messages"],
          ["deals", "Flash deals & offers"],
          ["achievements", "Achievements & rewards"],
        ] as const).map(([key, label]) => (
          <div key={key} className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <BellRing className="h-4 w-4 text-muted-foreground" />
              <Label className="text-sm">{label}</Label>
            </div>
            <Switch checked={prefs[key]} onCheckedChange={(v) => setPrefs((p) => ({ ...p, [key]: v }))} aria-label={label} />
          </div>
        ))}
      </Card>

      {/* Seller Subscription Management */}
      {me.isSeller && (
        <>
          <SectionTitle>Seller Subscriptions</SectionTitle>
          
          {/* Premium Seller Subscription Card */}
          <Card className={`mb-4 p-4 ${me.isPremium ? 'border-purple-200 bg-purple-50' : 'border-purple-200 bg-purple-50'}`}>
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className={`h-5 w-5 ${me.isPremium ? 'text-purple-600' : 'text-purple-600'}`} />
                <div>
                  <Label className={`text-sm font-semibold ${me.isPremium ? 'text-purple-900' : 'text-purple-900'}`}>
                    {me.isPremium ? 'Premium Seller Subscription Active' : 'Premium Seller Subscription'}
                  </Label>
                  <p className={`text-xs ${me.isPremium ? 'text-purple-700' : 'text-purple-700'}`}>
                    {me.isPremium ? 'Enjoy all premium subscription benefits and verified seller status' : 'Upgrade to unlock verified badge, featured listings, and advanced tools (0.5 π)'}
                  </p>
                </div>
              </div>
            </div>
            {!me.isPremium && <PremiumSellerSubscriptionButton variant="default" fullWidth={true} />}
            {me.isPremium && (
              <Button variant="outline" className="w-full" onClick={() => go({ name: 'subscription' })}>
                View Subscription Details
              </Button>
            )}
          </Card>

          {/* Original Premium Seller Status Card */}
          <Card className={`mb-4 p-4 ${me.isPremium ? 'border-green-200 bg-green-50' : 'border-amber-200 bg-amber-50'}`}>
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Crown className={`h-5 w-5 ${me.isPremium ? 'text-green-600' : 'text-amber-600'}`} />
                <div>
                  <Label className={`text-sm font-semibold ${me.isPremium ? 'text-green-900' : 'text-amber-900'}`}>
                    {me.isPremium ? 'Premium Seller Status Active' : 'Premium Seller Status'}
                  </Label>
                  <p className={`text-xs ${me.isPremium ? 'text-green-700' : 'text-amber-700'}`}>
                    {me.isPremium ? 'Enjoy all premium benefits and advanced tools' : 'Upgrade your seller account to unlock advanced features'}
                  </p>
                </div>
              </div>
            </div>
            {!me.isPremium && <PremiumSellerButton variant="default" />}
            {me.isPremium && (
              <Button variant="outline" className="w-full" onClick={() => go({ name: 'subscription' })}>
                Manage Subscription
              </Button>
            )}
          </Card>
        </>
      )}

      {/* Advanced Features */}
      {me.isSeller && (
        <>
          <SectionTitle>Advanced Seller Tools</SectionTitle>
          
          <Card className="mb-4 p-4 border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50">
            <div className="mb-3 flex items-center gap-3">
              <div>
                <Label className="text-sm font-semibold text-emerald-900">Validation Key (0.5 π)</Label>
                <p className="text-xs text-emerald-700">Unlock premium features to promote products, reach more buyers & increase visibility</p>
              </div>
            </div>
            <ValidationKeyButton variant="default" fullWidth={true} />
          </Card>

          <Card className="mb-4 p-4">
            <div className="mb-3 flex items-center gap-3">
              <div>
                <Label className="text-sm font-semibold">Unlock Advanced Features</Label>
                <p className="text-xs text-muted-foreground">AI promotion, featured listings, priority ranking & more</p>
              </div>
            </div>
            <div className="text-xs text-muted-foreground mb-3 space-y-1">
              <p className="font-medium text-foreground">Includes:</p>
              <ul className="list-inside list-disc space-y-1 ml-2">
                <li>AI-powered product promotion</li>
                <li>Featured listings</li>
                <li>Priority search ranking</li>
                <li>Premium analytics</li>
                <li>Advanced customization</li>
                <li>Business growth tools</li>
              </ul>
            </div>
            <AdvancedFeaturesButton variant="default" />
          </Card>

          <SectionTitle>Pi Market Hub Advanced Features</SectionTitle>
          <Card className="mb-4 p-4 border-indigo-200">
            <div className="mb-3 flex items-center gap-3">
              <div>
                <Label className="text-sm font-semibold text-indigo-900">Advanced Marketplace Tools (0.5 π)</Label>
                <p className="text-xs text-muted-foreground">Premium tools for professional sellers</p>
              </div>
            </div>
            <PiHubAdvancedButton 
              variant="default" 
              showFeatures={true}
              fullWidth={true}
            />
          </Card>

          <SectionTitle>Unlock All Modules</SectionTitle>
          <Card className="mb-4 p-4 border-emerald-200 bg-gradient-to-br from-emerald-50 to-teal-50">
            <div className="mb-3 flex items-center gap-3">
              <div>
                <Label className="text-sm font-semibold text-emerald-900">All Marketplace Modules (0.5 π)</Label>
                <p className="text-xs text-emerald-700">Access real estate, vehicles, services, jobs, business center, AI tools and more</p>
              </div>
            </div>
            <UnlockAllModulesButton 
              variant="default" 
              showFeatures={true}
              fullWidth={true}
            />
          </Card>

          <SectionTitle>Premium Job Listings</SectionTitle>
          <Card className="mb-4 p-4 border-cyan-200 bg-gradient-to-br from-cyan-50 to-cyan-100">
            <div className="mb-3 flex items-center gap-3">
              <div>
                <Label className="text-sm font-semibold text-cyan-900">Premium Job Listings (0.5 π)</Label>
                <p className="text-xs text-cyan-700">Post featured job opportunities with priority visibility and reach verified job seekers</p>
              </div>
            </div>
            <PremiumJobListingsButton 
              variant="default" 
              className="w-full"
            />
          </Card>
        </>
      )}

      {/* Verification / KYC */}
      <SectionTitle>Verification</SectionTitle>
      <Card className="mb-4 p-4">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldCheck className="h-5 w-5 text-primary" />
            <div>
              <Label className="text-sm font-semibold">Account Level</Label>
              <p className="text-xs text-muted-foreground">Higher levels boost trust & ranking</p>
            </div>
          </div>
          <VerifiedBadge level={me.verification} />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="flex-1" disabled={me.verification === "trusted" || me.verification === "verified"} onClick={() => submitKyc("trusted")}>
            <FileCheck className="mr-1.5 h-4 w-4" /> Submit ID
          </Button>
          <Button size="sm" className="flex-1" disabled={me.verification === "verified"} onClick={() => submitKyc("verified")}>
            <ShieldCheck className="mr-1.5 h-4 w-4" /> Full KYC
          </Button>
        </div>
        <p className="mt-2 text-[11px] text-muted-foreground">KYC is mock-approved now. The KYC adapter is ready for Pi Network&apos;s identity API later.</p>
      </Card>

      {/* Account */}
      <SectionTitle>Account</SectionTitle>
      <Card className="p-4">
        <p className="text-xs text-muted-foreground">
          Signed in via Pi Network as <span className="font-semibold text-foreground">{me.displayName}</span>.
        </p>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm" className="mt-3 w-full text-destructive">
              <LogOut className="mr-1.5 h-4 w-4" /> Reset local data
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reset local data?</DialogTitle>
            </DialogHeader>
            <p className="text-sm text-muted-foreground">This clears all locally stored marketplace data on this device. Your Pi Network session is unaffected.</p>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline">Cancel</Button>
              </DialogClose>
              <Button variant="destructive" onClick={() => { localStorage.removeItem("pi-market-hub-v1"); window.location.reload() }}>
                Reset
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </Card>

      <p className="mt-6 text-center text-xs text-muted-foreground">Pi Market Hub v1.0</p>
    </div>
  )
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="mb-2 px-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">{children}</h2>
}
