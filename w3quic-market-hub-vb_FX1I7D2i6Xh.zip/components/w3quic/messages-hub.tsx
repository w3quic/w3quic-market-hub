'use client'

import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MessageCircle } from 'lucide-react'

interface MessagesHubProps {
  piUsername: string
}

export function MessagesHub({ piUsername }: MessagesHubProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Messages</h1>
        <p className="text-gray-600">No active conversations yet</p>
      </div>

      <Card>
        <CardContent className="p-12 text-center">
          <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 mb-4">Start messaging with sellers and buyers</p>
          <p className="text-xs text-gray-400 mb-4">
            Messages will appear here when you interact with buyers and sellers on W3QUIC Market Hub
          </p>
          <Button variant="outline">
            Browse Listings to Start
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
