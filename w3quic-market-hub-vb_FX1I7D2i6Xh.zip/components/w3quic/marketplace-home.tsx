'use client'

import { useW3Quic } from '@/contexts/w3quic-context'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Heart, Star, MapPin, Tag } from 'lucide-react'
import { MarketplaceCategory } from '@/lib/w3quic-types'
import Image from 'next/image'

interface MarketplaceHomeProps {
  onSelectListing: (id: string) => void
}

const CATEGORIES: Array<{ id: MarketplaceCategory; label: string; icon: string }> = [
  { id: 'products', label: 'Products', icon: '📦' },
  { id: 'services', label: 'Services', icon: '🛠️' },
  { id: 'jobs', label: 'Jobs', icon: '💼' },
  { id: 'vehicles', label: 'Vehicles', icon: '🚗' },
  { id: 'real-estate', label: 'Real Estate', icon: '🏠' },
]

export function MarketplaceHome({ onSelectListing }: MarketplaceHomeProps) {
  const { listings, sellers, isFavorited, addFavorite, removeFavorite } = useW3Quic()

  const featuredListings = listings.filter(l => l.featured).slice(0, 6)

  return (
    <div className="space-y-8">
      {/* Category Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-4">Browse by Category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {CATEGORIES.map(cat => (
            <Card key={cat.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-4 text-center">
                <div className="text-4xl mb-2">{cat.icon}</div>
                <p className="font-semibold text-sm">{cat.label}</p>
                <p className="text-xs text-gray-500">
                  {listings.filter(l => l.category === cat.id).length} listings
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Featured Listings */}
      <div>
        <h2 className="text-2xl font-bold mb-4">Featured Listings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {featuredListings.map(listing => {
            const seller = sellers.get(listing.sellerId)
            const isFav = isFavorited(listing.id)

            return (
              <Card key={listing.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                <div className="relative h-48 bg-gray-200">
                  <Image
                    src={listing.images[0] || '/placeholder.jpg'}
                    alt={listing.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute top-2 right-2 space-x-1 flex">
                    {listing.featured && <Badge>Featured</Badge>}
                    <Badge variant="secondary">{listing.category}</Badge>
                  </div>
                  <button
                    onClick={() => isFav ? removeFavorite(listing.id) : addFavorite(listing.id)}
                    className="absolute top-2 left-2 p-1.5 bg-white rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <Heart className={`w-5 h-5 ${isFav ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} />
                  </button>
                </div>

                <CardContent className="p-4">
                  <h3 className="font-semibold line-clamp-2 mb-2">{listing.title}</h3>
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-purple-600">{listing.priceInPi} π</span>
                      <Tag className="w-4 h-4 text-gray-400" />
                    </div>
                    {seller && (
                      <div className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs font-semibold">{seller.rating}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-gray-600 mb-2">
                    Seller: <span className="font-semibold">{listing.sellerUsername}</span>
                  </p>

                  {listing.location && (
                    <p className="text-xs text-gray-500 mb-3 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {listing.location}
                    </p>
                  )}

                  <Button
                    onClick={() => onSelectListing(listing.id)}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* All Listings by Category */}
      {CATEGORIES.map(cat => {
        const categoryListings = listings.filter(l => l.category === cat.id).slice(0, 3)
        
        return (
          <div key={cat.id}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">{cat.label}</h2>
              <p className="text-sm text-gray-500">{listings.filter(l => l.category === cat.id).length} total</p>
            </div>

            {categoryListings.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categoryListings.map(listing => {
                  const seller = sellers.get(listing.sellerId)
                  const isFav = isFavorited(listing.id)

                  return (
                    <Card key={listing.id} className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold line-clamp-2 flex-1">{listing.title}</h3>
                          <button
                            onClick={() => isFav ? removeFavorite(listing.id) : addFavorite(listing.id)}
                            className="ml-2 p-1 hover:bg-gray-100 rounded transition-colors"
                          >
                            <Heart className={`w-4 h-4 ${isFav ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} />
                          </button>
                        </div>

                        <div className="flex items-center justify-between mb-3">
                          <span className="font-bold text-purple-600">{listing.priceInPi} π</span>
                          {seller && (
                            <div className="flex items-center gap-1">
                              <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                              <span className="text-xs">{seller.rating}</span>
                            </div>
                          )}
                        </div>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onSelectListing(listing.id)}
                          className="w-full"
                        >
                          View
                        </Button>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-gray-500">No {cat.label.toLowerCase()} listings yet</p>
                </CardContent>
              </Card>
            )}
          </div>
        )
      })}
    </div>
  )
}
