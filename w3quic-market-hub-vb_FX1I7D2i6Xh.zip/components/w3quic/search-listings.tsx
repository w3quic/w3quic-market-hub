'use client'

import { useState } from 'react'
import { useW3Quic } from '@/contexts/w3quic-context'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Heart, Star } from 'lucide-react'
import { MarketplaceCategory } from '@/lib/w3quic-types'
import Image from 'next/image'

interface SearchListingsProps {
  onSelectListing: (id: string) => void
}

const CATEGORIES: Array<{ id: MarketplaceCategory; label: string }> = [
  { id: 'products', label: 'Products' },
  { id: 'services', label: 'Services' },
  { id: 'jobs', label: 'Jobs' },
  { id: 'vehicles', label: 'Vehicles' },
  { id: 'real-estate', label: 'Real Estate' },
]

export function SearchListings({ onSelectListing }: SearchListingsProps) {
  const { listings, sellers, isFavorited, addFavorite, removeFavorite, searchListings } = useW3Quic()
  const [query, setQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<MarketplaceCategory | null>(null)

  const results = query ? searchListings(query, selectedCategory || undefined) : []

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="space-y-4">
        <Input
          placeholder="Search listings... (products, services, jobs, vehicles, real estate)"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="h-10"
        />

        <div className="flex gap-2 overflow-x-auto pb-2">
          <Button
            variant={selectedCategory === null ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory(null)}
          >
            All Categories
          </Button>
          {CATEGORIES.map(cat => (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat.id)}
            >
              {cat.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Results */}
      <div>
        {query && (
          <h2 className="text-lg font-semibold mb-4">
            Found {results.length} listing{results.length !== 1 ? 's' : ''}
          </h2>
        )}

        {results.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {results.map(listing => {
              const seller = sellers.get(listing.sellerId)
              const isFav = isFavorited(listing.id)

              return (
                <Card key={listing.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                  <div className="relative h-40 bg-gray-200">
                    <Image
                      src={listing.images[0] || '/placeholder.jpg'}
                      alt={listing.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <Badge variant="secondary" className="text-xs">{listing.category}</Badge>
                    </div>
                    <button
                      onClick={() => isFav ? removeFavorite(listing.id) : addFavorite(listing.id)}
                      className="absolute top-2 left-2 p-1 bg-white rounded-full hover:bg-gray-100"
                    >
                      <Heart className={`w-4 h-4 ${isFav ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} />
                    </button>
                  </div>

                  <CardContent className="p-4">
                    <h3 className="font-semibold line-clamp-2 mb-2">{listing.title}</h3>
                    
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-lg font-bold text-purple-600">{listing.priceInPi} π</span>
                      {seller && (
                        <div className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs font-semibold">{seller.rating}</span>
                        </div>
                      )}
                    </div>

                    <p className="text-xs text-gray-600 mb-2">By {listing.sellerUsername}</p>

                    <Button
                      onClick={() => onSelectListing(listing.id)}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      size="sm"
                    >
                      View
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : query ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">No listings found matching your search</p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">Enter search terms to find listings</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
