'use client'

import { useState } from 'react'
import { useW3Quic } from '@/contexts/w3quic-context'
import { createPiPayment, approvePaymentOnBackend, completePaymentOnBackend } from '@/lib/pi-marketplace'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Spinner } from '@/components/ui/spinner'
import { AlertCircle, ArrowLeft, Heart, MapPin, Star, Zap } from 'lucide-react'
import Image from 'next/image'

interface ListingDetailsProps {
  listingId: string
  piUsername: string
  onBack: () => void
}

export function ListingDetails({ listingId, piUsername, onBack }: ListingDetailsProps) {
  const { getListing, getSeller, isFavorited, addFavorite, removeFavorite, createOrder } = useW3Quic()
  const listing = getListing(listingId)
  const seller = listing ? getSeller(listing.sellerId) : null
  const isFav = listing ? isFavorited(listingId) : false

  const [processingPayment, setProcessingPayment] = useState(false)
  const [paymentError, setPaymentError] = useState<string | null>(null)
  const [paymentSuccess, setPaymentSuccess] = useState(false)

  if (!listing) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-500">Listing not found</p>
          <Button variant="outline" onClick={onBack} className="mt-4">
            Back
          </Button>
        </CardContent>
      </Card>
    )
  }

  const handlePayment = async () => {
    setProcessingPayment(true)
    setPaymentError(null)
    setPaymentSuccess(false)

    try {
      const paymentId = await createPiPayment(
        listing.priceInPi,
        {
          memo: `W3QUIC Market Hub Purchase`,
          metadata: {
            productId: listing.id,
            category: listing.category,
            buyerUsername: piUsername,
            marketplace: 'W3QUIC',
          },
        },
        {
          onReadyForServerApproval: async (paymentId) => {
            console.log('[Payment] Ready for approval:', paymentId)
            const approved = await approvePaymentOnBackend(paymentId)
            if (!approved) {
              throw new Error('Server approval failed')
            }
          },
          onReadyForServerCompletion: async (paymentId) => {
            console.log('[Payment] Ready for completion:', paymentId)
            const completed = await completePaymentOnBackend(paymentId)
            if (!completed) {
              throw new Error('Server completion failed')
            }
            
            // Create order
            createOrder({
              id: `order-${Date.now()}`,
              buyerId: piUsername,
              buyerUsername: piUsername,
              sellerId: listing.sellerId,
              listingId: listing.id,
              listingTitle: listing.title,
              priceInPi: listing.priceInPi,
              payment: {
                paymentId,
                amount: listing.priceInPi,
                memo: `W3QUIC Market Hub Purchase`,
                metadata: {
                  productId: listing.id,
                  category: listing.category,
                },
                status: 'completed',
                createdAt: Date.now(),
                completedAt: Date.now(),
              },
              status: 'confirmed',
              createdAt: Date.now(),
            })

            setPaymentSuccess(true)
          },
          onCancel: () => {
            setPaymentError('Payment cancelled by user')
          },
          onError: (error) => {
            setPaymentError(error.message)
          },
        }
      )

      if (!paymentId) {
        setPaymentError('Failed to create payment')
      }
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : 'Payment failed')
    } finally {
      setProcessingPayment(false)
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left: Images and Details */}
      <div className="lg:col-span-2 space-y-4">
        <Button variant="ghost" size="sm" onClick={onBack} className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back
        </Button>

        {/* Main Image */}
        <div className="relative w-full aspect-square bg-gray-200 rounded-lg overflow-hidden">
          <Image
            src={listing.images[0] || '/placeholder.jpg'}
            alt={listing.title}
            fill
            className="object-cover"
          />
        </div>

        {/* Listing Info */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <h1 className="text-2xl font-bold">{listing.title}</h1>
                <button
                  onClick={() => isFav ? removeFavorite(listingId) : addFavorite(listingId)}
                  className="p-2 hover:bg-gray-100 rounded transition-colors"
                >
                  <Heart className={`w-6 h-6 ${isFav ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} />
                </button>
              </div>
              
              <div className="flex gap-2 flex-wrap">
                <Badge>{listing.category}</Badge>
                {listing.condition && <Badge variant="outline">{listing.condition}</Badge>}
                {listing.featured && <Badge className="bg-purple-100 text-purple-800">Featured</Badge>}
              </div>
            </div>

            <p className="text-gray-700">{listing.description}</p>

            {/* Category-Specific Info */}
            <div className="grid grid-cols-2 gap-3 py-3 border-y">
              {listing.category === 'products' && listing.stock !== undefined && (
                <div className="text-sm">
                  <p className="text-gray-500">Stock:</p>
                  <p className="font-semibold">{listing.stock} available</p>
                </div>
              )}
              {listing.category === 'services' && listing.availability && (
                <div className="text-sm">
                  <p className="text-gray-500">Availability:</p>
                  <p className="font-semibold">{listing.availability}</p>
                </div>
              )}
              {listing.category === 'jobs' && listing.jobType && (
                <div className="text-sm">
                  <p className="text-gray-500">Job Type:</p>
                  <p className="font-semibold">{listing.jobType}</p>
                </div>
              )}
              {listing.category === 'vehicles' && listing.year && (
                <div className="text-sm">
                  <p className="text-gray-500">Year:</p>
                  <p className="font-semibold">{listing.year}</p>
                </div>
              )}
              {listing.category === 'vehicles' && listing.mileage !== undefined && (
                <div className="text-sm">
                  <p className="text-gray-500">Mileage:</p>
                  <p className="font-semibold">{listing.mileage.toLocaleString()} miles</p>
                </div>
              )}
              {listing.category === 'real-estate' && listing.bedrooms && (
                <div className="text-sm">
                  <p className="text-gray-500">Bedrooms:</p>
                  <p className="font-semibold">{listing.bedrooms}</p>
                </div>
              )}
              {listing.category === 'real-estate' && listing.squareFeet && (
                <div className="text-sm">
                  <p className="text-gray-500">Sq Ft:</p>
                  <p className="font-semibold">{listing.squareFeet.toLocaleString()}</p>
                </div>
              )}
            </div>

            {listing.location && (
              <div className="flex items-start gap-2 text-sm">
                <MapPin className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                <p>{listing.location}</p>
              </div>
            )}

            <div className="text-xs text-gray-500">
              Views: {listing.views} | Posted {new Date(listing.createdAt).toLocaleDateString()}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Right: Seller & Payment */}
      <div className="space-y-4">
        {/* Seller Card */}
        <Card>
          <CardHeader>
            <CardTitle>Seller</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="font-semibold text-lg">{seller?.displayName || listing.sellerUsername}</p>
              <p className="text-sm text-gray-500">@{listing.sellerUsername}</p>
            </div>

            {seller && (
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Rating:</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{seller.rating}</span>
                    <span className="text-gray-500">({seller.ratingCount})</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Sales:</span>
                  <span className="font-semibold">{seller.totalSales}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Member Since:</span>
                  <span className="text-xs">{new Date(seller.joinedAt).toLocaleDateString()}</span>
                </div>
                {seller.verified && (
                  <div className="flex items-center gap-1 text-green-600">
                    <Zap className="w-4 h-4" />
                    <span className="text-sm font-semibold">Verified Seller</span>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Card */}
        <Card className="border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Price</span>
              <span className="text-purple-600 text-2xl">{listing.priceInPi} π</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {paymentSuccess && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <p className="text-sm font-semibold text-green-800">✓ Purchase successful!</p>
                <p className="text-xs text-green-700 mt-1">Your order has been confirmed.</p>
              </div>
            )}

            {paymentError && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-red-800">Payment Error</p>
                  <p className="text-xs text-red-700">{paymentError}</p>
                </div>
              </div>
            )}

            <Button
              onClick={handlePayment}
              disabled={processingPayment || paymentSuccess}
              className="w-full bg-purple-600 hover:bg-purple-700 h-10"
            >
              {processingPayment ? (
                <>
                  <Spinner className="mr-2 h-4 w-4" />
                  Processing Payment...
                </>
              ) : paymentSuccess ? (
                'Payment Complete'
              ) : (
                'Pay with Pi Network'
              )}
            </Button>

            <div className="text-xs text-gray-500 text-center space-y-1 pt-2 border-t">
              <p>Secure payment powered by Pi Network</p>
              <p>Scopes: username, payments</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
