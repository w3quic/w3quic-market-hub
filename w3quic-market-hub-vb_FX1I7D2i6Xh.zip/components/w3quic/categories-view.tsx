'use client'

import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CATEGORY_ICONS, CATEGORY_COLORS } from './ui-utilities'

const CATEGORIES = [
  {
    id: 'products',
    name: 'Products',
    description: 'Buy and sell physical products and goods',
    icon: '📦',
  },
  {
    id: 'services',
    name: 'Services',
    description: 'Professional services and skills',
    icon: '🔧',
  },
  {
    id: 'jobs',
    name: 'Jobs',
    description: 'Job opportunities and employment',
    icon: '💼',
  },
  {
    id: 'vehicles',
    name: 'Vehicles',
    description: 'Cars, bikes, and transportation',
    icon: '🚗',
  },
  {
    id: 'real-estate',
    name: 'Real Estate',
    description: 'Properties, homes, and land',
    icon: '🏠',
  },
]

export function CategoriesView({ onSelectCategory }: { onSelectCategory: (category: string) => void }) {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Browse Categories</h1>
        <p className="text-gray-600">Explore items across all categories</p>
      </div>

      {/* Categories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CATEGORIES.map((category) => (
          <Card
            key={category.id}
            className="hover:shadow-lg cursor-pointer transition-all transform hover:scale-105"
            onClick={() => onSelectCategory(category.id)}
          >
            <CardHeader>
              <div className="text-5xl mb-3">{category.icon}</div>
              <CardTitle>{category.name}</CardTitle>
              <CardDescription>{category.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <button className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                Browse {category.name}
              </button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Stats */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardHeader>
          <CardTitle>Marketplace Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="text-3xl font-bold text-purple-600">5000+</div>
              <p className="text-gray-600">Active Listings</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600">2500+</div>
              <p className="text-gray-600">Happy Buyers</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-600">98%</div>
              <p className="text-gray-600">Satisfaction Rate</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
