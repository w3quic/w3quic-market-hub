'use client'

import { useState, useEffect } from 'react'
import { W3QuicProvider, useW3Quic } from '@/contexts/w3quic-context'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { MarketplaceHome } from './marketplace-home'
import { ListingDetails } from './listing-details'
import { CreateListing } from './create-listing'
import { MyListings } from './my-listings'
import { MyOrders } from './my-orders'
import { MessagesHub } from './messages-hub'
import { SearchListings } from './search-listings'
import { ShoppingCart, Plus, MessageCircle, Package } from 'lucide-react'

type View = 'home' | 'search' | 'listing' | 'create' | 'my-listings' | 'my-orders' | 'messages'

function W3QuicContent() {
  const { piUsername, setPiUsername } = useW3Quic()
  const [view, setView] = useState<View>('home')
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null)

  useEffect(() => {
    // Set default guest username if not set
    if (!piUsername) {
      setPiUsername('Guest')
    }
  }, [piUsername, setPiUsername])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              W3QUIC
            </div>
            <Badge variant="secondary">Market Hub</Badge>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500" />
              {piUsername}
            </Badge>
          </div>
        </div>

        {/* Navigation */}
        <div className="max-w-6xl mx-auto px-4 border-t border-gray-100 flex gap-2 overflow-x-auto">
          <Button
            variant={view === 'home' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('home')}
            className="flex-shrink-0"
          >
            <ShoppingCart className="w-4 h-4 mr-1" />
            Browse
          </Button>
          <Button
            variant={view === 'search' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('search')}
            className="flex-shrink-0"
          >
            Search
          </Button>
          <Button
            variant={view === 'create' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('create')}
            className="flex-shrink-0"
          >
            <Plus className="w-4 h-4 mr-1" />
            Create Listing
          </Button>
          <Button
            variant={view === 'my-listings' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('my-listings')}
            className="flex-shrink-0"
          >
            My Listings
          </Button>
          <Button
            variant={view === 'my-orders' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('my-orders')}
            className="flex-shrink-0"
          >
            <Package className="w-4 h-4 mr-1" />
            Orders
          </Button>
          <Button
            variant={view === 'messages' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setView('messages')}
            className="flex-shrink-0"
          >
            <MessageCircle className="w-4 h-4 mr-1" />
            Messages
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {view === 'home' && <MarketplaceHome onSelectListing={(id) => { setSelectedListingId(id); setView('listing'); }} />}
        {view === 'search' && <SearchListings onSelectListing={(id) => { setSelectedListingId(id); setView('listing'); }} />}
        {view === 'listing' && selectedListingId && <ListingDetails listingId={selectedListingId} piUsername={piUsername} onBack={() => setView('home')} />}
        {view === 'create' && <CreateListing piUsername={piUsername} onCreated={() => setView('my-listings')} />}
        {view === 'my-listings' && <MyListings piUsername={piUsername} />}
        {view === 'my-orders' && <MyOrders piUsername={piUsername} />}
        {view === 'messages' && <MessagesHub piUsername={piUsername} />}
      </main>
    </div>
  )
}

export function W3QuicApp() {
  return (
    <W3QuicProvider>
      <W3QuicContent />
    </W3QuicProvider>
  )
}
