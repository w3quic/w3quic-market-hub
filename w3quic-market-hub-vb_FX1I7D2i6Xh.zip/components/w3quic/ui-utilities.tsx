'use client'

import React from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

// Category Icons
export const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  products: '📦',
  services: '🔧',
  jobs: '💼',
  vehicles: '🚗',
  'real-estate': '🏠',
}

// Category Colors
export const CATEGORY_COLORS: Record<string, string> = {
  products: 'bg-blue-100 text-blue-800',
  services: 'bg-green-100 text-green-800',
  jobs: 'bg-purple-100 text-purple-800',
  vehicles: 'bg-orange-100 text-orange-800',
  'real-estate': 'bg-amber-100 text-amber-800',
}

// Status Badge Component
export function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    active: 'bg-green-100 text-green-800',
    sold: 'bg-gray-100 text-gray-800',
    pending: 'bg-yellow-100 text-yellow-800',
    inactive: 'bg-red-100 text-red-800',
  }
  return (
    <span className={`px-3 py-1 rounded-full text-sm font-medium ${colors[status] || 'bg-gray-100'}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  )
}

// Price Display Component
export function PriceDisplay({ price, currency = 'π' }: { price: number; currency?: string }) {
  return (
    <div className="text-2xl font-bold text-purple-600">
      {currency}
      {price.toFixed(2)}
    </div>
  )
}

// Listing Card Component
export function ListingCard({
  id,
  title,
  category,
  price,
  seller,
  image,
  onClick,
}: {
  id: string
  title: string
  category: string
  price: number
  seller: string
  image?: string
  onClick?: () => void
}) {
  return (
    <Card
      className="hover:shadow-lg transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <CardHeader className="pb-3">
        {image && (
          <div className="w-full h-40 bg-gray-200 rounded-md mb-3 flex items-center justify-center">
            <img src={image} alt={title} className="w-full h-full object-cover rounded-md" />
          </div>
        )}
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{title}</CardTitle>
          <span className={`px-2 py-1 rounded text-xs font-semibold ${CATEGORY_COLORS[category] || 'bg-gray-100'}`}>
            {CATEGORY_ICONS[category]} {category}
          </span>
        </div>
        <CardDescription>by {seller}</CardDescription>
      </CardHeader>
      <CardContent>
        <PriceDisplay price={price} />
      </CardContent>
    </Card>
  )
}

// Loading Spinner
export function LoadingSpinner() {
  return (
    <div className="flex justify-center items-center py-8">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
    </div>
  )
}

// Empty State Component
export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string
  description: string
  action?: { label: string; onClick: () => void }
  icon?: string
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {icon && <div className="text-6xl mb-4">{icon}</div>}
      <h3 className="text-xl font-semibold text-gray-800 mb-2">{title}</h3>
      <p className="text-gray-500 mb-6">{description}</p>
      {action && (
        <Button onClick={action.onClick} variant="default">
          {action.label}
        </Button>
      )}
    </div>
  )
}

// Filter Sidebar Component
export function FilterSidebar({
  categories,
  priceRange,
  onPriceChange,
  selectedCategory,
  onCategoryChange,
}: {
  categories: string[]
  priceRange: [number, number]
  onPriceChange: (range: [number, number]) => void
  selectedCategory: string
  onCategoryChange: (category: string) => void
}) {
  return (
    <Card className="h-fit sticky top-4">
      <CardHeader>
        <CardTitle>Filters</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Category Filter */}
        <div>
          <h4 className="font-semibold text-sm mb-3">Category</h4>
          <div className="space-y-2">
            <button
              onClick={() => onCategoryChange('all')}
              className={`block text-left w-full px-3 py-2 rounded ${
                selectedCategory === 'all' ? 'bg-purple-600 text-white' : 'hover:bg-gray-100'
              }`}
            >
              All Categories
            </button>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => onCategoryChange(cat)}
                className={`block text-left w-full px-3 py-2 rounded ${
                  selectedCategory === cat ? 'bg-purple-600 text-white' : 'hover:bg-gray-100'
                }`}
              >
                {CATEGORY_ICONS[cat]} {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Price Filter */}
        <div>
          <h4 className="font-semibold text-sm mb-3">Price Range</h4>
          <div className="space-y-2">
            <input
              type="range"
              min="0"
              max="10000"
              value={priceRange[1]}
              onChange={(e) => onPriceChange([priceRange[0], parseInt(e.target.value)])}
              className="w-full"
            />
            <div className="text-sm text-gray-600">
              π{priceRange[0]} - π{priceRange[1]}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Breadcrumb Navigation
export function Breadcrumb({ items }: { items: Array<{ label: string; onClick: () => void }> }) {
  return (
    <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <button
            onClick={item.onClick}
            className="hover:text-purple-600 hover:underline"
          >
            {item.label}
          </button>
          {index < items.length - 1 && <span>{'>'}</span>}
        </React.Fragment>
      ))}
    </div>
  )
}

// User Profile Badge
export function UserProfileBadge({
  username,
  rating,
  onProfile,
}: {
  username: string
  rating: number
  onProfile?: () => void
}) {
  return (
    <button
      onClick={onProfile}
      className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-100 transition"
    >
      <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">
        {username.charAt(0).toUpperCase()}
      </div>
      <div className="text-left">
        <div className="font-semibold text-sm">{username}</div>
        <div className="text-xs text-yellow-500">{'⭐'.repeat(Math.min(Math.round(rating), 5))}</div>
      </div>
    </button>
  )
}
