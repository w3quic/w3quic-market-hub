'use client'

import { useW3Quic } from '@/contexts/w3quic-context'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { CheckCircle2, Clock, XCircle } from 'lucide-react'

interface MyOrdersProps {
  piUsername: string
}

const STATUS_ICONS = {
  pending: <Clock className="w-5 h-5 text-yellow-500" />,
  confirmed: <CheckCircle2 className="w-5 h-5 text-blue-500" />,
  completed: <CheckCircle2 className="w-5 h-5 text-green-500" />,
  cancelled: <XCircle className="w-5 h-5 text-red-500" />,
}

const STATUS_COLORS = {
  pending: 'bg-yellow-50 text-yellow-800 border-yellow-200',
  confirmed: 'bg-blue-50 text-blue-800 border-blue-200',
  completed: 'bg-green-50 text-green-800 border-green-200',
  cancelled: 'bg-red-50 text-red-800 border-red-200',
}

export function MyOrders({ piUsername }: MyOrdersProps) {
  const { orders, getOrdersByBuyer } = useW3Quic()

  const userOrders = getOrdersByBuyer(piUsername)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Orders</h1>
        <p className="text-gray-600">{userOrders.length} order{userOrders.length !== 1 ? 's' : ''}</p>
      </div>

      {userOrders.length > 0 ? (
        <div className="space-y-3">
          {userOrders.map(order => (
            <Card key={order.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-1">{order.listingTitle}</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Seller: <span className="font-medium">{order.sellerId}</span>
                    </p>
                    
                    <div className="flex items-center gap-4 text-sm">
                      <div>
                        <p className="text-gray-500">Amount</p>
                        <p className="font-bold text-purple-600">{order.priceInPi} π</p>
                      </div>
                      <div>
                        <p className="text-gray-500">Payment ID</p>
                        <p className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                          {order.payment.paymentId.slice(0, 8)}...
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-500">Ordered</p>
                        <p className="text-xs">{new Date(order.createdAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-3">
                    <div className={`flex items-center gap-2 px-3 py-1 rounded border ${STATUS_COLORS[order.status]}`}>
                      {STATUS_ICONS[order.status]}
                      <span className="text-sm font-semibold capitalize">{order.status}</span>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500 mb-4">You haven&apos;t placed any orders yet</p>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Start Shopping
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
