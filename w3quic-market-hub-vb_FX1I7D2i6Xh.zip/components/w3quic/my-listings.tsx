'use client'

import { useW3Quic } from '@/contexts/w3quic-context'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Eye, Star } from 'lucide-react'
import Image from 'next/image'

interface MyListingsProps {
  piUsername: string
}

export function MyListings({ piUsername }: MyListingsProps) {
  const { listings } = useW3Quic()

  const userListings = listings.filter(l => l.sellerUsername === piUsername)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">My Listings</h1>
        <p className="text-gray-600">{userListings.length} active listing{userListings.length !== 1 ? 's' : ''}</p>
      </div>

      {userListings.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {userListings.map(listing => (
            <Card key={listing.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative h-40 bg-gray-200">
                <Image
                  src={listing.images[0] || '/placeholder.jpg'}
                  alt={listing.title}
                  fill
                  className="object-cover"
                />
              </div>

              <CardContent className="p-4 space-y-3">
                <div>
                  <h3 className="font-semibold line-clamp-2">{listing.title}</h3>
                  <Badge variant="secondary" className="mt-1">{listing.category}</Badge>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-purple-600">{listing.priceInPi} π</span>
                  <div className="flex items-center gap-1 text-gray-500">
                    <Eye className="w-4 h-4" />
                    <span className="text-sm">{listing.views}</span>
                  </div>
                </div>

                <div className="text-xs text-gray-500">
                  Created: {new Date(listing.createdAt).toLocaleDateString()}
                </div>

                <Button variant="outline" className="w-full" size="sm">
                  Edit Listing
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500 mb-4">You haven&apos;t created any listings yet</p>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Create Your First Listing
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
