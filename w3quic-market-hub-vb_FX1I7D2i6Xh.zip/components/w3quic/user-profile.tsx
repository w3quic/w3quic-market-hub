'use client'

import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useW3Quic } from '@/contexts/w3quic-context'

export function UserProfile({
  username,
  onLogout,
  onBack,
}: {
  username: string
  onLogout: () => void
  onBack: () => void
}) {
  const { listings } = useW3Quic()
  const userListings = listings.filter((l) => l.seller === username)

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="text-purple-600 hover:text-purple-700">
          ← Back
        </button>
        <div>
          <h1 className="text-3xl font-bold">{username}</h1>
          <p className="text-gray-600">W3QUIC Marketplace Member</p>
        </div>
      </div>

      {/* Profile Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userListings.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Rating</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{'⭐'.repeat(5)}</div>
            <p className="text-xs text-gray-500">5.0/5.0</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Member Since</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-sm">{new Date().toLocaleDateString()}</div>
          </CardContent>
        </Card>
      </div>

      {/* Verification Status */}
      <Card>
        <CardHeader>
          <CardTitle>Account Verification</CardTitle>
          <CardDescription>Your account status and permissions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="text-green-600">✓</span>
            <span>Pi Network authenticated</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-green-600">✓</span>
            <span>Payment enabled</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-green-600">✓</span>
            <span>Seller verified</span>
          </div>
        </CardContent>
      </Card>

      {/* Account Actions */}
      <div className="flex gap-4">
        <Button variant="outline" onClick={onBack}>
          Continue Shopping
        </Button>
        <Button
          onClick={onLogout}
          className="bg-red-600 hover:bg-red-700"
        >
          Logout
        </Button>
      </div>
    </div>
  )
}
