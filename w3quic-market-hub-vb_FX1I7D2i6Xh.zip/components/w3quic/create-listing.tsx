'use client'

import { useState } from 'react'
import { useW3Quic } from '@/contexts/w3quic-context'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Spinner } from '@/components/ui/spinner'
import { AlertCircle } from 'lucide-react'
import { MarketplaceCategory, Listing } from '@/lib/w3quic-types'

interface CreateListingProps {
  piUsername: string
  onCreated: () => void
}

const CATEGORIES: Array<{ id: MarketplaceCategory; label: string; fields: string[] }> = [
  { id: 'products', label: 'Products', fields: ['stock', 'condition'] },
  { id: 'services', label: 'Services', fields: ['serviceType', 'availability'] },
  { id: 'jobs', label: 'Jobs', fields: ['jobType', 'salaryInPi'] },
  { id: 'vehicles', label: 'Vehicles', fields: ['vehicleType', 'year', 'mileage'] },
  { id: 'real-estate', label: 'Real Estate', fields: ['propertyType', 'bedrooms', 'bathrooms', 'squareFeet'] },
]

export function CreateListing({ piUsername, onCreated }: CreateListingProps) {
  const { addListing } = useW3Quic()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  const [category, setCategory] = useState<MarketplaceCategory>('products')
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priceInPi: '',
    location: '',
    // Product
    stock: '',
    condition: 'new' as const,
    // Service
    serviceType: '',
    availability: 'available' as const,
    // Job
    jobType: 'freelance' as const,
    salaryInPi: '',
    // Vehicle
    vehicleType: '',
    year: '',
    mileage: '',
    // Real Estate
    propertyType: '',
    bedrooms: '',
    bathrooms: '',
    squareFeet: '',
  })

  const selectedCategoryConfig = CATEGORIES.find(c => c.id === category)

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      if (!formData.title.trim()) {
        throw new Error('Title is required')
      }
      if (!formData.description.trim()) {
        throw new Error('Description is required')
      }
      if (!formData.priceInPi || isNaN(parseFloat(formData.priceInPi))) {
        throw new Error('Valid price in Pi is required')
      }

      const newListing: Listing = {
        id: `listing-${Date.now()}`,
        sellerId: piUsername,
        sellerUsername: piUsername,
        title: formData.title,
        description: formData.description,
        category,
        priceInPi: parseFloat(formData.priceInPi),
        images: ['/placeholder.jpg'],
        location: formData.location || undefined,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 0,
        featured: false,
        // Category-specific
        ...(category === 'products' && {
          stock: parseInt(formData.stock) || 1,
          condition: formData.condition as any,
        }),
        ...(category === 'services' && {
          serviceType: formData.serviceType || undefined,
          availability: formData.availability as any,
        }),
        ...(category === 'jobs' && {
          jobType: formData.jobType as any,
          salaryInPi: formData.salaryInPi ? parseFloat(formData.salaryInPi) : undefined,
        }),
        ...(category === 'vehicles' && {
          vehicleType: formData.vehicleType || undefined,
          year: formData.year ? parseInt(formData.year) : undefined,
          mileage: formData.mileage ? parseInt(formData.mileage) : undefined,
        }),
        ...(category === 'real-estate' && {
          propertyType: formData.propertyType || undefined,
          bedrooms: formData.bedrooms ? parseInt(formData.bedrooms) : undefined,
          bathrooms: formData.bathrooms ? parseInt(formData.bathrooms) : undefined,
          squareFeet: formData.squareFeet ? parseInt(formData.squareFeet) : undefined,
        }),
      }

      addListing(newListing)
      onCreated()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create listing')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle>Create New Listing</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Category Selection */}
            <div>
              <label className="block text-sm font-semibold mb-3">Category</label>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className={`p-2 rounded border-2 transition-all text-center text-sm font-medium ${
                      category === cat.id
                        ? 'border-purple-600 bg-purple-50 text-purple-900'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {/* Basic Fields */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-1">Title *</label>
                <Input
                  placeholder="List item title"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold mb-1">Description *</label>
                <textarea
                  placeholder="Describe your listing in detail"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  required
                  className="w-full border border-gray-300 rounded-md p-2 min-h-24 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold mb-1">Price (Pi) *</label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                    value={formData.priceInPi}
                    onChange={(e) => handleInputChange('priceInPi', e.target.value)}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-1">Location</label>
                  <Input
                    placeholder="City, State/Country"
                    value={formData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Category-Specific Fields */}
            {category === 'products' && (
              <div className="space-y-4 p-4 bg-gray-50 rounded border border-gray-200">
                <h3 className="font-semibold">Product Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Stock</label>
                    <Input
                      type="number"
                      min="0"
                      value={formData.stock}
                      onChange={(e) => handleInputChange('stock', e.target.value)}
                      placeholder="Quantity available"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Condition</label>
                    <select
                      value={formData.condition}
                      onChange={(e) => handleInputChange('condition', e.target.value)}
                      className="w-full border border-gray-300 rounded-md p-2"
                    >
                      <option value="new">New</option>
                      <option value="like-new">Like New</option>
                      <option value="good">Good</option>
                      <option value="fair">Fair</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {category === 'services' && (
              <div className="space-y-4 p-4 bg-gray-50 rounded border border-gray-200">
                <h3 className="font-semibold">Service Details</h3>
                <div>
                  <label className="block text-sm font-semibold mb-1">Service Type</label>
                  <Input
                    placeholder="e.g., Web Development, Consulting"
                    value={formData.serviceType}
                    onChange={(e) => handleInputChange('serviceType', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-1">Availability</label>
                  <select
                    value={formData.availability}
                    onChange={(e) => handleInputChange('availability', e.target.value)}
                    className="w-full border border-gray-300 rounded-md p-2"
                  >
                    <option value="available">Available</option>
                    <option value="limited">Limited Availability</option>
                    <option value="unavailable">Unavailable</option>
                  </select>
                </div>
              </div>
            )}

            {category === 'jobs' && (
              <div className="space-y-4 p-4 bg-gray-50 rounded border border-gray-200">
                <h3 className="font-semibold">Job Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold mb-1">Job Type</label>
                    <select
                      value={formData.jobType}
                      onChange={(e) => handleInputChange('jobType', e.target.value)}
                      className="w-full border border-gray-300 rounded-md p-2"
                    >
                      <option value="full-time">Full-time</option>
                      <option value="part-time">Part-time</option>
                      <option value="contract">Contract</option>
                      <option value="freelance">Freelance</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold mb-1">Salary (Pi)</label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={formData.salaryInPi}
                      onChange={(e) => handleInputChange('salaryInPi', e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {category === 'vehicles' && (
              <div className="space-y-4 p-4 bg-gray-50 rounded border border-gray-200">
                <h3 className="font-semibold">Vehicle Details</h3>
                <Input
                  placeholder="Vehicle type (e.g., Sedan, SUV)"
                  value={formData.vehicleType}
                  onChange={(e) => handleInputChange('vehicleType', e.target.value)}
                />
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    type="number"
                    placeholder="Year"
                    value={formData.year}
                    onChange={(e) => handleInputChange('year', e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Mileage"
                    value={formData.mileage}
                    onChange={(e) => handleInputChange('mileage', e.target.value)}
                  />
                </div>
              </div>
            )}

            {category === 'real-estate' && (
              <div className="space-y-4 p-4 bg-gray-50 rounded border border-gray-200">
                <h3 className="font-semibold">Real Estate Details</h3>
                <Input
                  placeholder="Property type (e.g., House, Condo)"
                  value={formData.propertyType}
                  onChange={(e) => handleInputChange('propertyType', e.target.value)}
                />
                <div className="grid grid-cols-3 gap-4">
                  <Input
                    type="number"
                    placeholder="Bedrooms"
                    value={formData.bedrooms}
                    onChange={(e) => handleInputChange('bedrooms', e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Bathrooms"
                    value={formData.bathrooms}
                    onChange={(e) => handleInputChange('bathrooms', e.target.value)}
                  />
                  <Input
                    type="number"
                    placeholder="Sq Ft"
                    value={formData.squareFeet}
                    onChange={(e) => handleInputChange('squareFeet', e.target.value)}
                  />
                </div>
              </div>
            )}

            {/* Submit */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-purple-600 hover:bg-purple-700 h-10"
            >
              {loading ? (
                <>
                  <Spinner className="mr-2 h-4 w-4" />
                  Creating...
                </>
              ) : (
                'Create Listing'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
