'use client'

import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useW3Quic } from '@/contexts/w3quic-context'
import { ListingCard, StatusBadge, EmptyState, PriceDisplay } from './ui-utilities'

export function SellerDashboard({
  username,
  onCreateListing,
}: {
  username: string
  onCreateListing: () => void
}) {
  const { listings } = useW3Quic()
  const sellerListings = listings.filter((l) => l.seller === username)

  // Calculate seller stats
  const stats = {
    totalListings: sellerListings.length,
    activeListings: sellerListings.filter((l) => l.status === 'active').length,
    soldItems: sellerListings.filter((l) => l.status === 'sold').length,
    totalRevenue: sellerListings
      .filter((l) => l.status === 'sold')
      .reduce((sum, l) => sum + l.price, 0),
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Seller Dashboard</h1>
          <p className="text-gray-600">Manage your listings and sales</p>
        </div>
        <Button onClick={onCreateListing} className="bg-purple-600 hover:bg-purple-700">
          + Create Listing
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalListings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Listings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.activeListings}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Sold Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.soldItems}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">π{stats.totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Listings Management */}
      <Card>
        <CardHeader>
          <CardTitle>Your Listings</CardTitle>
          <CardDescription>Manage and track your active and sold items</CardDescription>
        </CardHeader>
        <CardContent>
          {sellerListings.length === 0 ? (
            <EmptyState
              icon="📝"
              title="No listings yet"
              description="Start by creating your first listing to sell items on the marketplace"
              action={{
                label: 'Create Listing',
                onClick: onCreateListing,
              }}
            />
          ) : (
            <div className="space-y-4">
              {sellerListings.map((listing) => (
                <div
                  key={listing.id}
                  className="flex justify-between items-center p-4 border rounded-lg hover:bg-gray-50"
                >
                  <div className="flex-1">
                    <h4 className="font-semibold">{listing.title}</h4>
                    <p className="text-sm text-gray-600">{listing.description}</p>
                    <div className="flex gap-2 mt-2">
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">{listing.category}</span>
                      <StatusBadge status={listing.status} />
                    </div>
                  </div>
                  <div className="text-right">
                    <PriceDisplay price={listing.price} />
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(listing.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
