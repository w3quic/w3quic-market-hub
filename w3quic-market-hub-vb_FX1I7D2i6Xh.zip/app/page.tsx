import { W3QuicApp } from "@/components/w3quic/w3quic-app"

export default function HomePage() {
  return <W3QuicApp />
}
