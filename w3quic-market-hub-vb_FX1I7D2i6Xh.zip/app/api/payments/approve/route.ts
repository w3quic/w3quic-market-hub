import { NextRequest, NextResponse } from 'next/server'

/**
 * POST /api/payments/approve
 * Approves a Pi Network payment on the backend
 * Calls Pi's approval endpoint with PI_API_KEY
 */
export async function POST(request: NextRequest) {
  try {
    const piApiKey = process.env.PI_API_KEY

    if (!piApiKey) {
      return NextResponse.json(
        { error: 'PI_API_KEY is missing' },
        { status: 500 }
      )
    }

    const { paymentId, txid } = await request.json()

    if (!paymentId) {
      return NextResponse.json(
        { error: 'Payment ID is required' },
        { status: 400 }
      )
    }

    console.log(`[Backend] Approving payment: ${paymentId}`)

    // Call Pi's payment approval endpoint
    const piResponse = await fetch(
      `https://api.minepi.com/v2/payments/${paymentId}/approve`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Key ${piApiKey}`,
        },
        body: JSON.stringify({}),
      }
    )

    if (!piResponse.ok) {
      const error = await piResponse.json()
      console.error('[Backend] Pi approval failed:', error)
      return NextResponse.json(error, { status: piResponse.status })
    }

    const approvedPayment = await piResponse.json()
    console.log('[Backend] Payment approved:', approvedPayment)

    return NextResponse.json(approvedPayment)
  } catch (error) {
    console.error('[Backend] Approval error:', error)
    return NextResponse.json(
      {
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
