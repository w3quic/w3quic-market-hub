import { NextRequest, NextResponse } from 'next/server'

/**
 * POST /api/payments/complete
 * Completes a Pi Network payment on the backend
 * Calls Pi's completion endpoint with PI_API_KEY
 */
export async function POST(request: NextRequest) {
  try {
    const piApiKey = process.env.PI_API_KEY

    if (!piApiKey) {
      return NextResponse.json(
        { error: 'PI_API_KEY is missing' },
        { status: 500 }
      )
    }

    const { paymentId, txid } = await request.json()

    if (!paymentId) {
      return NextResponse.json(
        { error: 'Payment ID is required' },
        { status: 400 }
      )
    }

    console.log(`[Backend] Completing payment: ${paymentId}`)

    // Call Pi's payment completion endpoint
    const piResponse = await fetch(
      `https://api.minepi.com/v2/payments/${paymentId}/complete`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Key ${piApiKey}`,
        },
        body: JSON.stringify({
          txid: txid || undefined,
        }),
      }
    )

    if (!piResponse.ok) {
      const error = await piResponse.json()
      console.error('[Backend] Pi completion failed:', error)
      return NextResponse.json(error, { status: piResponse.status })
    }

    const completedPayment = await piResponse.json()
    console.log('[Backend] Payment completed:', completedPayment)

    return NextResponse.json(completedPayment)
  } catch (error) {
    console.error('[Backend] Completion error:', error)
    return NextResponse.json(
      {
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    )
  }
}
