import type { UserPreferences, OfflineData, Product, SellerStore } from "./types"
import { uid } from "./helpers"

export class UXOptimization {
  // Theme Management
  static initializeTheme(preference?: "light" | "dark" | "auto"): "light" | "dark" {
    const selected = preference || "auto"

    if (selected === "auto") {
      if (typeof window !== "undefined") {
        return window.matchMedia("(prefers-color-scheme: dark)").matches
          ? "dark"
          : "light"
      }
      return "light"
    }

    return selected
  }

  static applyTheme(theme: "light" | "dark"): void {
    if (typeof document !== "undefined") {
      if (theme === "dark") {
        document.documentElement.classList.add("dark")
        document.documentElement.style.colorScheme = "dark"
      } else {
        document.documentElement.classList.remove("dark")
        document.documentElement.style.colorScheme = "light"
      }
    }
  }

  static getSystemTheme(): "light" | "dark" {
    if (typeof window !== "undefined") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light"
    }
    return "light"
  }

  // Localization
  static supportedLanguages = {
    en: "English",
    es: "Español",
    fr: "Français",
    de: "Deutsch",
    zh: "中文",
    ja: "日本語",
    ar: "العربية",
  }

  static detectLanguage(): keyof typeof UXOptimization.supportedLanguages {
    if (typeof navigator === "undefined") return "en"

    const lang = navigator.language.split("-")[0].toLowerCase()
    const supported = Object.keys(UXOptimization.supportedLanguages) as Array<
      keyof typeof UXOptimization.supportedLanguages
    >

    return (supported.includes(lang as any) ? lang : "en") as any
  }

  static isRTLLanguage(language: string): boolean {
    return ["ar", "he", "fa", "ur"].includes(language)
  }

  static applyLanguageSettings(language: string): void {
    if (typeof document !== "undefined") {
      document.documentElement.lang = language
      if (UXOptimization.isRTLLanguage(language)) {
        document.documentElement.dir = "rtl"
      } else {
        document.documentElement.dir = "ltr"
      }
    }
  }

  // Offline Mode
  static initializeOfflineMode(userId: string): void {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/sw.js")
        .then(() => {
          console.log("Service Worker registered for offline support")
        })
        .catch((err) => {
          console.warn("Service Worker registration failed:", err)
        })
    }
  }

  static cacheProductsForOffline(
    userId: string,
    products: Product[],
    maxSize: number = 50,
  ): OfflineData {
    const selected = products.slice(0, maxSize)
    const cachedIds = selected.map((p) => p.id)

    if (typeof localStorage !== "undefined") {
      const key = `offline-products-${userId}`
      localStorage.setItem(
        key,
        JSON.stringify({
          products: selected,
          timestamp: Date.now(),
        }),
      )
    }

    return {
      userId,
      cachedProducts: cachedIds,
      cachedPages: [],
      lastSyncTime: Date.now(),
      syncSize: JSON.stringify(selected).length,
    }
  }

  static cacheStoresForOffline(
    userId: string,
    stores: SellerStore[],
  ): OfflineData {
    if (typeof localStorage !== "undefined") {
      const key = `offline-stores-${userId}`
      localStorage.setItem(
        key,
        JSON.stringify({
          stores,
          timestamp: Date.now(),
        }),
      )
    }

    return {
      userId,
      cachedProducts: [],
      cachedPages: stores.map((s) => s.storeName),
      lastSyncTime: Date.now(),
      syncSize: JSON.stringify(stores).length,
    }
  }

  static getCachedProducts(userId: string): Product[] {
    if (typeof localStorage !== "undefined") {
      const key = `offline-products-${userId}`
      const cached = localStorage.getItem(key)
      if (cached) {
        try {
          return JSON.parse(cached).products
        } catch {
          return []
        }
      }
    }
    return []
  }

  // Performance Optimization
  static lazyLoadImages(container: HTMLElement): void {
    if ("IntersectionObserver" in window) {
      const images = container.querySelectorAll("img[data-src]")
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target as HTMLImageElement
            img.src = img.dataset.src || ""
            img.removeAttribute("data-src")
            observer.unobserve(img)
          }
        })
      })

      images.forEach((img) => imageObserver.observe(img))
    }
  }

  static optimizeImageUrl(url: string, width?: number, quality?: number): string {
    // Simulated image optimization with parameters
    const params = new URLSearchParams()
    if (width) params.append("w", width.toString())
    if (quality) params.append("q", quality.toString())

    return params.toString() ? `${url}?${params.toString()}` : url
  }

  static compressData(data: string): string {
    // Simple compression simulation (in production, use gzip)
    return btoa(data) // base64 encoding as placeholder
  }

  static decompressData(compressed: string): string {
    try {
      return atob(compressed)
    } catch {
      return compressed
    }
  }

  // Accessibility
  static improveAccessibility(): void {
    if (typeof document !== "undefined") {
      // Set ARIA labels for dynamic content
      const mainContent = document.querySelector("main")
      if (mainContent && !mainContent.getAttribute("role")) {
        mainContent.setAttribute("role", "main")
      }

      // Ensure proper heading hierarchy
      const headings = document.querySelectorAll("h1, h2, h3, h4, h5, h6")
      headings.forEach((h) => {
        if (!h.getAttribute("id")) {
          h.setAttribute("id", `heading-${uid("acc")}`)
        }
      })

      // Ensure all interactive elements are keyboard accessible
      const buttons = document.querySelectorAll("button, a[href]")
      buttons.forEach((btn) => {
        if (!btn.hasAttribute("tabindex")) {
          btn.setAttribute("tabindex", "0")
        }
      })
    }
  }

  // Responsive Design Support
  static getDeviceType(): "mobile" | "tablet" | "desktop" {
    if (typeof window === "undefined") return "desktop"

    const width = window.innerWidth
    if (width < 768) return "mobile"
    if (width < 1024) return "tablet"
    return "desktop"
  }

  static isTouchDevice(): boolean {
    if (typeof window === "undefined") return false

    return (
      window.matchMedia("(pointer:coarse)").matches ||
      navigator.maxTouchPoints > 0 ||
      /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent,
      )
    )
  }

  // Page Speed Metrics
  static recordPageMetrics(): void {
    if (typeof window !== "undefined" && "performance" in window) {
      const perfData = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming
      if (perfData) {
        const metrics = {
          DNS: perfData.domainLookupEnd - perfData.domainLookupStart,
          TCP: perfData.connectEnd - perfData.connectStart,
          TTFB: perfData.responseStart - perfData.fetchStart,
          DOMContentLoaded: perfData.domContentLoadedEventEnd - perfData.fetchStart,
          LoadComplete: perfData.loadEventEnd - perfData.fetchStart,
        }

        console.log("[Performance Metrics]", metrics)

        // Send to analytics (implement as needed)
        if (typeof localStorage !== "undefined") {
          localStorage.setItem(
            "page-metrics",
            JSON.stringify({
              timestamp: Date.now(),
              metrics,
            }),
          )
        }
      }
    }
  }

  // Notification Preferences
  static createUserPreferences(overrides?: Partial<UserPreferences>): UserPreferences {
    return {
      userId: overrides?.userId || "",
      theme: overrides?.theme || "auto" as any,
      language: overrides?.language || UXOptimization.detectLanguage(),
      notifications: {
        email: overrides?.notifications?.email ?? true,
        push: overrides?.notifications?.push ?? true,
        sms: overrides?.notifications?.sms ?? false,
        inApp: overrides?.notifications?.inApp ?? true,
      },
      offlineMode: overrides?.offlineMode ?? false,
      compactView: overrides?.compactView ?? false,
      currency: overrides?.currency || "pi",
    }
  }

  // Loading States
  static getSkeletonLoader(type: "product" | "store" | "user" | "order"): any {
    const skeletons = {
      product: {
        title: "Skeleton text",
        description: "Skeleton text",
        price: "Skeleton text",
        image: "Skeleton image",
      },
      store: {
        name: "Skeleton text",
        logo: "Skeleton image",
        stats: ["Skeleton", "Skeleton", "Skeleton"],
      },
      user: {
        avatar: "Skeleton image",
        name: "Skeleton text",
        rating: "Skeleton text",
      },
      order: {
        items: ["Skeleton", "Skeleton"],
        total: "Skeleton text",
        status: "Skeleton text",
      },
    }

    return skeletons[type]
  }
}

// Localization Strings (sample)
export const TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    "navbar.home": "Home",
    "navbar.browse": "Browse",
    "navbar.sell": "Sell",
    "navbar.search": "Search products...",
    "common.loading": "Loading...",
    "common.error": "An error occurred",
    "common.success": "Success!",
  },
  es: {
    "navbar.home": "Inicio",
    "navbar.browse": "Explorar",
    "navbar.sell": "Vender",
    "navbar.search": "Buscar productos...",
    "common.loading": "Cargando...",
    "common.error": "Ocurrió un error",
    "common.success": "¡Éxito!",
  },
  fr: {
    "navbar.home": "Accueil",
    "navbar.browse": "Parcourir",
    "navbar.sell": "Vendre",
    "navbar.search": "Rechercher des produits...",
    "common.loading": "Chargement en cours...",
    "common.error": "Une erreur s'est produite",
    "common.success": "Succès!",
  },
}

export const t = (lang: string, key: string): string => {
  return TRANSLATIONS[lang]?.[key] || TRANSLATIONS.en[key] || key
}
