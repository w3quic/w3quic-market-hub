import type { AdCampaign, AdType, AdCampaignStatus, AdMetrics, PromotionalOffer, Category } from "./types"
import { uid } from "./helpers"

/**
 * ADVERTISING PLATFORM
 * Manages featured products, stores, sponsored search, and promotions
 */

/**
 * AD CAMPAIGN MANAGEMENT
 */

export const AD_TYPES: Record<AdType, { label: string; icon: string; description: string }> = {
  "featured-product": {
    label: "Featured Product",
    icon: "Star",
    description: "Highlight your best products on the homepage",
  },
  "featured-store": {
    label: "Featured Store",
    icon: "Store",
    description: "Showcase your store to potential customers",
  },
  "sponsored-search": {
    label: "Sponsored Search",
    icon: "Search",
    description: "Appear at the top of search results",
  },
  promotion: {
    label: "Promotion",
    icon: "Tag",
    description: "Run special offers and discounts",
  },
  "flash-sale": {
    label: "Flash Sale",
    icon: "Zap",
    description: "Create urgency with time-limited deals",
  },
}

export function createAdCampaign(
  createdBy: string,
  type: AdType,
  budget: number,
  startDate: number,
  endDate: number,
  targetId?: string
): AdCampaign {
  return {
    id: uid("campaign"),
    createdBy,
    type,
    targetId,
    budget,
    status: "draft",
    startDate,
    endDate,
    impressions: 0,
    clicks: 0,
    conversions: 0,
    createdAt: Date.now(),
  }
}

export function setDailyBudget(campaign: AdCampaign, dailyBudget: number): AdCampaign {
  if (dailyBudget > campaign.budget) {
    throw new Error("Daily budget cannot exceed total budget")
  }
  return {
    ...campaign,
    dailyBudget,
  }
}

export function setBidAmount(campaign: AdCampaign, bidAmount: number): AdCampaign {
  return {
    ...campaign,
    bidAmount,
  }
}

export function activateCampaign(campaign: AdCampaign, adminId?: string): AdCampaign {
  if (campaign.status !== "draft") {
    throw new Error("Only draft campaigns can be activated")
  }

  return {
    ...campaign,
    status: "active",
    approvedBy: adminId,
  }
}

export function pauseCampaign(campaign: AdCampaign): AdCampaign {
  return {
    ...campaign,
    status: "paused",
  }
}

export function resumeCampaign(campaign: AdCampaign): AdCampaign {
  if (campaign.status !== "paused") {
    throw new Error("Only paused campaigns can be resumed")
  }
  return {
    ...campaign,
    status: "active",
  }
}

export function rejectCampaign(campaign: AdCampaign, reason: string): AdCampaign {
  return {
    ...campaign,
    status: "rejected",
    approvalReason: reason,
  }
}

export function completeCampaign(campaign: AdCampaign): AdCampaign {
  return {
    ...campaign,
    status: "completed",
  }
}

export function autoCompleteCampaign(campaign: AdCampaign): AdCampaign | null {
  if (campaign.status !== "active") return null
  if (Date.now() > campaign.endDate) {
    return completeCampaign(campaign)
  }
  return null
}

/**
 * CAMPAIGN METRICS & TRACKING
 */

export function recordImpression(campaign: AdCampaign): AdCampaign {
  return {
    ...campaign,
    impressions: campaign.impressions + 1,
  }
}

export function recordClick(campaign: AdCampaign): AdCampaign {
  return {
    ...campaign,
    clicks: campaign.clicks + 1,
  }
}

export function recordConversion(campaign: AdCampaign, amount: number = 0): AdCampaign {
  return {
    ...campaign,
    conversions: campaign.conversions + 1,
  }
}

export function calculateAdMetrics(campaign: AdCampaign): AdMetrics {
  const ctr = campaign.impressions > 0 ? (campaign.clicks / campaign.impressions) * 100 : 0
  const conversionRate = campaign.clicks > 0 ? (campaign.conversions / campaign.clicks) * 100 : 0

  // Calculate spend based on impressions/clicks depending on ad type
  let spend = 0
  if (campaign.type === "sponsored-search" && campaign.bidAmount) {
    spend = campaign.clicks * campaign.bidAmount
  } else {
    spend = (campaign.impressions / 1000) * (campaign.dailyBudget || campaign.budget / 30)
  }

  const roi = spend > 0 ? ((campaign.conversions * 50 - spend) / spend) * 100 : 0 // Assume $50 per conversion

  return {
    campaignId: campaign.id,
    impressions: campaign.impressions,
    clicks: campaign.clicks,
    conversions: campaign.conversions,
    spend: Math.round(spend * 100) / 100,
    roi: Math.round(roi * 100) / 100,
    ctr: Math.round(ctr * 100) / 100,
    conversionRate: Math.round(conversionRate * 100) / 100,
  }
}

export const AD_CAMPAIGN_STATUS_COLORS: Record<AdCampaignStatus, string> = {
  draft: "gray",
  active: "green",
  paused: "yellow",
  completed: "blue",
  rejected: "red",
}

/**
 * PROMOTIONAL OFFERS
 */

export function createPromotionalOffer(
  sellerId: string,
  discountType: "percentage" | "fixed" | "bogo" | "tiered",
  discountValue: number,
  startDate: number,
  endDate: number,
  productId?: string,
  category?: Category
): PromotionalOffer {
  return {
    id: uid("promo"),
    sellerId,
    productId,
    discountType,
    discountValue,
    startDate,
    endDate,
    applicableCategory: category,
    currentUses: 0,
    createdAt: Date.now(),
  }
}

export function setMaxDiscountAmount(offer: PromotionalOffer, maxAmount: number): PromotionalOffer {
  return {
    ...offer,
    maxDiscountAmount: maxAmount,
  }
}

export function setMinPurchaseAmount(offer: PromotionalOffer, minAmount: number): PromotionalOffer {
  return {
    ...offer,
    minPurchaseAmount: minAmount,
  }
}

export function setMaxUses(offer: PromotionalOffer, maxUses: number): PromotionalOffer {
  return {
    ...offer,
    maxUses,
  }
}

export function isOfferActive(offer: PromotionalOffer): boolean {
  const now = Date.now()
  return now >= offer.startDate && now <= offer.endDate
}

export function canUseOffer(offer: PromotionalOffer, purchaseAmount: number): boolean {
  if (!isOfferActive(offer)) return false
  if (offer.minPurchaseAmount && purchaseAmount < offer.minPurchaseAmount) return false
  if (offer.maxUses && offer.currentUses >= offer.maxUses) return false
  return true
}

export function applyPromotion(offer: PromotionalOffer, amount: number): { discountAmount: number; finalAmount: number } {
  if (!canUseOffer(offer, amount)) {
    return { discountAmount: 0, finalAmount: amount }
  }

  let discountAmount = 0

  if (offer.discountType === "percentage") {
    discountAmount = (amount * offer.discountValue) / 100
    if (offer.maxDiscountAmount) {
      discountAmount = Math.min(discountAmount, offer.maxDiscountAmount)
    }
  } else if (offer.discountType === "fixed") {
    discountAmount = Math.min(offer.discountValue, amount)
  } else if (offer.discountType === "bogo") {
    // Buy one get one - discount is item price
    discountAmount = amount * offer.discountValue
  } else if (offer.discountType === "tiered") {
    // Tiered discounts based on purchase amount
    if (amount >= 100) discountAmount = amount * (offer.discountValue / 100)
    else if (amount >= 50) discountAmount = amount * ((offer.discountValue / 2) / 100)
  }

  return {
    discountAmount: Math.min(discountAmount, amount),
    finalAmount: Math.max(0, amount - discountAmount),
  }
}

export function incrementOfferUsage(offer: PromotionalOffer): PromotionalOffer {
  return {
    ...offer,
    currentUses: offer.currentUses + 1,
  }
}

/**
 * FEATURED LISTINGS
 */

export interface FeaturedListing {
  id: string
  type: "product" | "store"
  targetId: string
  startDate: number
  endDate: number
  position: number // 1-10
  isSponsored: boolean
  cost: number // in Pi
  impressions: number
  clicks: number
}

export function createFeaturedListing(
  type: "product" | "store",
  targetId: string,
  durationDays: number = 7,
  cost: number = 5.0,
  isSponsored: boolean = false
): FeaturedListing {
  return {
    id: uid("featured"),
    type,
    targetId,
    startDate: Date.now(),
    endDate: Date.now() + durationDays * 24 * 60 * 60 * 1000,
    position: 0,
    isSponsored,
    cost,
    impressions: 0,
    clicks: 0,
  }
}

export function assignFeaturedPosition(listing: FeaturedListing, position: number): FeaturedListing {
  if (position < 1 || position > 10) {
    throw new Error("Position must be between 1 and 10")
  }
  return {
    ...listing,
    position,
  }
}

/**
 * SPONSORED SEARCH
 */

export interface SponsoredSearchResult {
  id: string
  productId: string
  sellerId: string
  bidAmount: number // in Pi per click
  dailyBudget: number
  targetKeywords: string[]
  adCopyHeadline: string
  adCopyDescription: string
  position: number
  isActive: boolean
  createdAt: number
}

export function createSponsoredSearchListing(
  productId: string,
  sellerId: string,
  bidAmount: number,
  dailyBudget: number,
  keywords: string[],
  headline: string,
  description: string
): SponsoredSearchResult {
  return {
    id: uid("sponsored"),
    productId,
    sellerId,
    bidAmount,
    dailyBudget,
    targetKeywords: keywords,
    adCopyHeadline: headline,
    adCopyDescription: description,
    position: 0,
    isActive: true,
    createdAt: Date.now(),
  }
}

export function calculateAdRank(search: SponsoredSearchResult, qualityScore: number = 5): number {
  return search.bidAmount * qualityScore
}

/**
 * AD QUALITY & COMPLIANCE
 */

export interface AdQualityScore {
  relevance: number // 1-10
  ctr: number // 1-10
  landingPageQuality: number // 1-10
  overall: number // 1-10
}

export function evaluateAdQuality(metrics: AdMetrics, campaign: AdCampaign): AdQualityScore {
  // CTR score
  const ctrScore = Math.min(10, (metrics.ctr / 5) * 10) // 5% CTR = 10/10
  // Conversion rate score
  const conversionScore = Math.min(10, (metrics.conversionRate / 3) * 10) // 3% conversion = 10/10
  // Landing page quality (simulated)
  const landingPageScore = 7 // Default

  const overall = Math.round((ctrScore + conversionScore + landingPageScore) / 3)

  return {
    relevance: 7, // Simplified
    ctr: Math.round(ctrScore),
    landingPageQuality: landingPageScore,
    overall,
  }
}

export function shouldOptimizeAd(qualityScore: AdQualityScore): boolean {
  return qualityScore.overall < 6
}

/**
 * AD SPENDING & BUDGETS
 */

export function getRemainingBudget(campaign: AdCampaign, metrics: AdMetrics): number {
  return campaign.budget - metrics.spend
}

export function getDailySpendRate(campaign: AdCampaign, metrics: AdMetrics): number {
  const daysActive = Math.ceil((Date.now() - campaign.startDate) / (24 * 60 * 60 * 1000))
  return daysActive > 0 ? metrics.spend / daysActive : 0
}

export function estimateRemainingDays(campaign: AdCampaign, metrics: AdMetrics): number {
  const remaining = getRemainingBudget(campaign, metrics)
  const dailyRate = getDailySpendRate(campaign, metrics)

  if (dailyRate === 0) {
    return Math.ceil((campaign.endDate - Date.now()) / (24 * 60 * 60 * 1000))
  }

  return Math.ceil(remaining / dailyRate)
}

export function isNearBudgetLimit(campaign: AdCampaign, metrics: AdMetrics, threshold: number = 0.9): boolean {
  const spent = metrics.spend
  return spent / campaign.budget >= threshold
}
