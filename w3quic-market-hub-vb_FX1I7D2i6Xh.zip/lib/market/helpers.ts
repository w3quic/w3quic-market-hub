import type { Product } from "./types"

export function formatPi(n: number): string {
  const v = Math.round(n * 100) / 100
  return `${v % 1 === 0 ? v.toFixed(0) : v.toFixed(2)} π`
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts
  const s = Math.floor(diff / 1000)
  if (s < 60) return "just now"
  const m = Math.floor(s / 60)
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  const d = Math.floor(h / 24)
  if (d < 30) return `${d}d ago`
  return new Date(ts).toLocaleDateString()
}

export function countdown(endsAt: number): string {
  const diff = endsAt - Date.now()
  if (diff <= 0) return "Ended"
  const d = Math.floor(diff / 86400000)
  const h = Math.floor((diff % 86400000) / 3600000)
  const m = Math.floor((diff % 3600000) / 60000)
  const s = Math.floor((diff % 60000) / 1000)
  if (d > 0) return `${d}d ${h}h ${m}m`
  if (h > 0) return `${h}h ${m}m ${s}s`
  return `${m}m ${s}s`
}

export function effectivePrice(p: Product): number {
  if (p.flashDeal && p.flashDeal.endsAt > Date.now()) {
    return Math.round(p.price * (1 - p.flashDeal.discountPercent / 100) * 100) / 100
  }
  return p.price
}

export function isReserved(p: Product, currentUserId: string): boolean {
  return !!(p.reservedUntil && p.reservedUntil > Date.now() && p.reservedBy !== currentUserId)
}

export function estimateDelivery(handlingDays: number): string {
  const start = new Date(Date.now() + handlingDays * 86400000)
  const end = new Date(Date.now() + (handlingDays + 4) * 86400000)
  const fmt = (d: Date) => d.toLocaleDateString(undefined, { month: "short", day: "numeric" })
  return `${fmt(start)} - ${fmt(end)}`
}

export function uid(prefix = ""): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`
}

export function toCSV(rows: Record<string, string | number>[]): string {
  if (rows.length === 0) return ""
  const headers = Object.keys(rows[0])
  const lines = [headers.join(",")]
  for (const r of rows) {
    lines.push(headers.map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(","))
  }
  return lines.join("\n")
}

export function downloadCSV(filename: string, csv: string) {
  const blob = new Blob([csv], { type: "text/csv" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
