import type { Product, SellerStore, UserProfile, Review, Coupon } from "./types"

const now = Date.now()
const day = 86400000

export const CURRENT_USER_ID = "me"

export const SEED_SELLERS: UserProfile[] = [
  {
    id: "seller-techhub", displayName: "TechHub Pi", bio: "Premium electronics & gadgets. Fast shipping, trusted by 1000+ Pioneers.",
    rating: 4.9, ratingCount: 312, reputationScore: 92, joinedAt: now - 400 * day, totalTransactions: 540,
    verification: "verified", favoriteSellers: [], loyaltyPoints: 0, badges: ["top-rated", "fast-shipper", "orders-500", "verified", "early-adopter"],
    isSeller: true, isPremium: true, adminRole: null, referralCode: "TECHHUB", responseTimeMins: 30, disputesResolved: 8, loginStreak: 0, achievements: [],
  },
  {
    id: "seller-stylenest", displayName: "StyleNest", bio: "Curated fashion for every Pioneer. New arrivals weekly.",
    rating: 4.7, ratingCount: 188, reputationScore: 84, joinedAt: now - 220 * day, totalTransactions: 260,
    verification: "trusted", favoriteSellers: [], loyaltyPoints: 0, badges: ["top-rated", "orders-100", "verified"],
    isSeller: true, isPremium: true, adminRole: null, referralCode: "STYLE", responseTimeMins: 90, disputesResolved: 3, loginStreak: 0, achievements: [],
  },
  {
    id: "seller-greenliving", displayName: "Green Living", bio: "Home & garden essentials, eco-friendly and affordable.",
    rating: 4.6, ratingCount: 96, reputationScore: 78, joinedAt: now - 120 * day, totalTransactions: 140,
    verification: "basic", favoriteSellers: [], loyaltyPoints: 0, badges: ["orders-100", "fast-shipper"],
    isSeller: true, isPremium: false, adminRole: null, referralCode: "GREEN", responseTimeMins: 200, disputesResolved: 1, loginStreak: 0, achievements: [],
  },
  {
    id: "seller-prowheels", displayName: "ProWheels", bio: "Quality vehicles and parts. Inspected and verified.",
    rating: 4.5, ratingCount: 54, reputationScore: 71, joinedAt: now - 60 * day, totalTransactions: 70,
    verification: "trusted", favoriteSellers: [], loyaltyPoints: 0, badges: ["verified"],
    isSeller: true, isPremium: false, adminRole: null, referralCode: "WHEELS", responseTimeMins: 150, disputesResolved: 2, loginStreak: 0, achievements: [],
  },
]

export const SEED_STORES: SellerStore[] = [
  { sellerId: "seller-techhub", name: "TechHub Pi", bannerUrl: "", logoUrl: "", description: "Your one-stop shop for premium tech in the Pi ecosystem.", categories: ["New Arrivals", "Best Sellers", "Clearance"], followers: ["me"], followersCount: 1, announcements: [{ title: "Summer Tech Sale", text: "Up to 30% off select gadgets this week only!" }], vacation: { enabled: false }, views: 12400 },
  { sellerId: "seller-stylenest", name: "StyleNest", bannerUrl: "", logoUrl: "", description: "Fashion that fits the future.", categories: ["New Arrivals", "Summer Collection"], followers: [], followersCount: 0, announcements: [{ title: "New Arrivals", text: "Fresh styles just dropped." }], vacation: { enabled: false }, views: 8200 },
  { sellerId: "seller-greenliving", name: "Green Living", bannerUrl: "", logoUrl: "", description: "Sustainable living, delivered.", categories: ["Indoor", "Outdoor"], followers: [], followersCount: 0, announcements: [], vacation: { enabled: false }, views: 3100 },
  { sellerId: "seller-prowheels", name: "ProWheels", bannerUrl: "", logoUrl: "", description: "Drive into the future with Pi.", categories: ["Bikes", "Parts"], followers: [], followersCount: 0, announcements: [], vacation: { enabled: false }, views: 1900 },
]

function img(seed: string) {
  return `/placeholder.svg?height=400&width=400&query=${encodeURIComponent(seed)}`
}

export const SEED_PRODUCTS: Product[] = [
  {
    id: "p-laptop", sellerId: "seller-techhub", title: "UltraBook Pro 14 Laptop", description: "Powerful 14-inch laptop with 16GB RAM, 512GB SSD, and all-day battery life. Perfect for work and creativity. Lightweight aluminum body.",
    price: 480, category: "electronics", subcategory: "Laptops", condition: "new", variations: [
      { id: "v1", name: "8GB / 256GB", price: 480, stock: 5, sku: "UB-8-256" },
      { id: "v2", name: "16GB / 512GB", price: 620, stock: 3, sku: "UB-16-512" },
    ], stock: 8, location: "Singapore", images: [img("silver laptop computer"), img("laptop keyboard closeup")], deliveryOptions: ["Standard", "Express"],
    createdAt: now - 5 * day, updatedAt: now - 2 * day, views: 420, featured: true, sponsored: true, scamScore: 8, hidden: false, handlingTimeDays: 1,
  },
  {
    id: "p-phone", sellerId: "seller-techhub", title: "Pi Phone X Smartphone", description: "Flagship smartphone with stunning OLED display, triple camera system, and fast charging. Unlocked for all networks.",
    price: 320, category: "electronics", subcategory: "Phones", condition: "new", variations: [], stock: 12, location: "Singapore", images: [img("modern black smartphone")], deliveryOptions: ["Standard", "Express"],
    createdAt: now - 8 * day, updatedAt: now - 1 * day, views: 680, featured: true, sponsored: false,
    flashDeal: { discountPercent: 25, endsAt: now + 2 * day }, scamScore: 5, hidden: false, handlingTimeDays: 1,
  },
  {
    id: "p-headphones", sellerId: "seller-techhub", title: "Wireless Noise-Cancelling Headphones", description: "Immersive sound with active noise cancellation. 30-hour battery, plush comfort, and premium build quality.",
    price: 85, category: "electronics", subcategory: "Audio", condition: "new", variations: [], stock: 20, location: "Singapore", images: [img("black wireless headphones")], deliveryOptions: ["Standard"],
    createdAt: now - 3 * day, updatedAt: now - 3 * day, views: 290, featured: false, sponsored: false,
    flashDeal: { discountPercent: 30, endsAt: now + 1 * day }, scamScore: 6, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-jacket", sellerId: "seller-stylenest", title: "Premium Leather Jacket", description: "Genuine leather jacket with timeless design. Soft lining, durable zippers, and a tailored fit for any occasion.",
    price: 120, category: "fashion", subcategory: "Outerwear", condition: "new", variations: [
      { id: "s", name: "Small", price: 120, stock: 4, sku: "LJ-S" },
      { id: "m", name: "Medium", price: 120, stock: 6, sku: "LJ-M" },
      { id: "l", name: "Large", price: 130, stock: 2, sku: "LJ-L" },
    ], stock: 12, location: "Milan", images: [img("brown leather jacket")], deliveryOptions: ["Standard", "Express"],
    createdAt: now - 10 * day, updatedAt: now - 4 * day, views: 210, featured: true, sponsored: false, scamScore: 10, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-sneakers", sellerId: "seller-stylenest", title: "Running Sneakers - Ultra Light", description: "Breathable mesh running shoes with responsive cushioning. Designed for comfort on long runs and daily wear.",
    price: 65, category: "fashion", subcategory: "Shoes", condition: "new", variations: [], stock: 30, location: "Milan", images: [img("white running sneakers")], deliveryOptions: ["Standard"],
    createdAt: now - 6 * day, updatedAt: now - 6 * day, views: 340, featured: false, sponsored: false, scamScore: 7, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-plant", sellerId: "seller-greenliving", title: "Monstera Indoor Plant", description: "Lush Monstera Deliciosa in a ceramic pot. Air-purifying and easy to care for. Brings life to any room.",
    price: 25, category: "home", subcategory: "Plants", condition: "new", variations: [], stock: 15, location: "Amsterdam", images: [img("monstera plant in pot")], deliveryOptions: ["Local"],
    createdAt: now - 4 * day, updatedAt: now - 4 * day, views: 130, featured: false, sponsored: false, scamScore: 4, hidden: false, handlingTimeDays: 1,
  },
  {
    id: "p-lamp", sellerId: "seller-greenliving", title: "Minimalist Desk Lamp", description: "Adjustable LED desk lamp with warm and cool modes. Touch control and USB charging port. Modern matte finish.",
    price: 18, category: "home", subcategory: "Lighting", condition: "new", variations: [], stock: 40, location: "Amsterdam", images: [img("minimalist desk lamp")], deliveryOptions: ["Standard"],
    createdAt: now - 2 * day, updatedAt: now - 2 * day, views: 90, featured: false, sponsored: false, scamScore: 5, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-bike", sellerId: "seller-prowheels", title: "Mountain Bike - Trail Series", description: "21-speed mountain bike with front suspension and disc brakes. Built for rugged trails and city commutes alike.",
    price: 220, category: "vehicles", subcategory: "Bikes", condition: "like-new", variations: [], stock: 3, location: "Denver", images: [img("red mountain bike")], deliveryOptions: ["Local", "Standard"],
    createdAt: now - 12 * day, updatedAt: now - 5 * day, views: 175, featured: false, sponsored: true, scamScore: 12, hidden: false, handlingTimeDays: 3,
  },
  {
    id: "p-watch", sellerId: "seller-techhub", title: "Vintage Collector's Watch (Auction)", description: "Rare vintage automatic watch in excellent condition. A true collector's piece with leather strap and sapphire crystal.",
    price: 150, category: "fashion", subcategory: "Accessories", condition: "good", variations: [], stock: 1, location: "Geneva", images: [img("vintage luxury watch")], deliveryOptions: ["Express"],
    createdAt: now - 1 * day, updatedAt: now - 1 * day, views: 510, featured: false, sponsored: false,
    auction: { startingBid: 100, minIncrement: 5, reserve: 200, endsAt: now + 3 * day, bids: [{ userId: "buyer-anna", amount: 110, at: now - 12 * 3600000 }, { userId: "buyer-leo", amount: 125, at: now - 4 * 3600000 }] },
    scamScore: 9, hidden: false, handlingTimeDays: 1,
  },
  {
    id: "p-camera", sellerId: "seller-techhub", title: "Mirrorless Camera Kit", description: "24MP mirrorless camera with 18-55mm lens. Capture stunning photos and 4K video. Includes battery and strap.",
    price: 410, category: "electronics", subcategory: "Cameras", condition: "good", variations: [], stock: 2, location: "Tokyo", images: [img("mirrorless camera with lens")], deliveryOptions: ["Express"],
    createdAt: now - 7 * day, updatedAt: now - 7 * day, views: 230, featured: false, sponsored: false, scamScore: 11, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-football", sellerId: "seller-prowheels", title: "Pro Match Football", description: "Official size 5 match football with durable stitching and superior grip. FIFA-quality for serious players.",
    price: 12, category: "sports", subcategory: "Football", condition: "new", variations: [], stock: 50, location: "Denver", images: [img("soccer football ball")], deliveryOptions: ["Standard"],
    createdAt: now - 9 * day, updatedAt: now - 9 * day, views: 75, featured: false, sponsored: false, scamScore: 4, hidden: false, handlingTimeDays: 2,
  },
  {
    id: "p-book", sellerId: "seller-greenliving", title: "The Pi Pioneer's Handbook", description: "A comprehensive guide to thriving in the Pi Network ecosystem. Paperback, 320 pages, like-new condition.",
    price: 8, category: "books", subcategory: "Non-fiction", condition: "like-new", variations: [], stock: 18, location: "Amsterdam", images: [img("blue book cover")], deliveryOptions: ["Standard"],
    createdAt: now - 11 * day, updatedAt: now - 11 * day, views: 60, featured: false, sponsored: false, scamScore: 3, hidden: false, handlingTimeDays: 1,
  },
]

export const SEED_REVIEWS: Review[] = [
  { id: "r1", productId: "p-laptop", sellerId: "seller-techhub", buyerId: "buyer-anna", buyerName: "Anna K.", rating: 5, text: "Amazing laptop, super fast delivery. Highly recommend TechHub!", createdAt: now - 3 * day },
  { id: "r2", productId: "p-laptop", sellerId: "seller-techhub", buyerId: "buyer-leo", buyerName: "Leo M.", rating: 4, text: "Great value, works perfectly. Packaging could be better.", createdAt: now - 6 * day },
  { id: "r3", productId: "p-jacket", sellerId: "seller-stylenest", buyerId: "buyer-anna", buyerName: "Anna K.", rating: 5, text: "Beautiful jacket, fits perfectly. Love it!", createdAt: now - 4 * day },
  { id: "r4", productId: "p-phone", sellerId: "seller-techhub", buyerId: "buyer-leo", buyerName: "Leo M.", rating: 5, text: "Best phone I've owned. The flash deal made it a steal.", createdAt: now - 2 * day },
]

export const SEED_COUPONS: Coupon[] = [
  { code: "PI10", discountPercent: 10 },
  { code: "WELCOME", discountPercent: 15 },
  { code: "FLASH20", discountPercent: 20 },
]

export const POPULAR_SEARCHES = ["laptop", "sneakers", "headphones", "plant", "watch", "camera", "bike", "jacket"]

export function makeCurrentUser(): UserProfile {
  return {
    id: CURRENT_USER_ID,
    displayName: "Pi Pioneer",
    bio: "Exploring the Pi marketplace.",
    rating: 5,
    ratingCount: 2,
    reputationScore: 60,
    joinedAt: now - 30 * day,
    totalTransactions: 2,
    verification: "basic",
    favoriteSellers: ["seller-techhub"],
    loyaltyPoints: 45,
    badges: [],
    isSeller: false,
    isPremium: false,
    adminRole: "super",
    referralCode: "PIONEER42",
    responseTimeMins: 60,
    disputesResolved: 0,
    loginStreak: 0,
    achievements: ["first-purchase"],
  }
}
