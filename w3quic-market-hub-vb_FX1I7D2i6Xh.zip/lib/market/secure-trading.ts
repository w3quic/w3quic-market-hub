import type {
  Order, EscrowTransaction, Dispute, DisputeReasonType, ResolutionType,
  BuyerProtection, SellerProtection, RefundRequest, DisputeEvidence, MoneyBackGuarantee,
} from "./types"
import { uid } from "./helpers"

/**
 * ESCROW SYSTEM
 * Holds Pi in escrow until buyer confirms delivery, protecting both parties
 */

export function createEscrow(order: Order): EscrowTransaction {
  return {
    id: uid("escrow"),
    orderId: order.id,
    buyerId: order.buyerId,
    sellerId: order.sellerId,
    amount: order.total,
    status: "held",
    heldAt: Date.now(),
  }
}

export function confirmBuyerReceivedDelivery(escrow: EscrowTransaction): EscrowTransaction {
  return {
    ...escrow,
    buyerConfirmedDelivery: true,
  }
}

export function confirmSellerShipped(escrow: EscrowTransaction): EscrowTransaction {
  return {
    ...escrow,
    sellerConfirmedShipment: true,
  }
}

export function canReleaseEscrow(escrow: EscrowTransaction): boolean {
  return escrow.status === "held" && (escrow.buyerConfirmedDelivery === true || isEscrowExpired(escrow))
}

export function releaseEscrow(escrow: EscrowTransaction): EscrowTransaction {
  return {
    ...escrow,
    status: "released",
    releasedAt: Date.now(),
  }
}

export function refundEscrow(escrow: EscrowTransaction): EscrowTransaction {
  return {
    ...escrow,
    status: "refunded",
    refundedAt: Date.now(),
  }
}

export function disputeEscrow(escrow: EscrowTransaction): EscrowTransaction {
  return {
    ...escrow,
    status: "disputed",
  }
}

const ESCROW_HOLD_DAYS = 14

export function isEscrowExpired(escrow: EscrowTransaction): boolean {
  const heldDuration = Date.now() - escrow.heldAt
  return heldDuration > ESCROW_HOLD_DAYS * 24 * 60 * 60 * 1000
}

/**
 * DISPUTE SYSTEM
 * Handles order disputes with evidence collection and admin resolution
 */

export function createDispute(
  orderId: string,
  escrowId: string,
  buyerId: string,
  sellerId: string,
  reason: DisputeReasonType,
  description: string
): Dispute {
  return {
    id: uid("dispute"),
    orderId,
    escrowId,
    buyerId,
    sellerId,
    reason,
    description,
    buyerEvidence: [],
    sellerEvidence: [],
    buyerMessage: description,
    status: "open",
    openedAt: Date.now(),
    messages: [
      {
        userId: buyerId,
        text: `Dispute opened: ${description}`,
        at: Date.now(),
      },
    ],
  }
}

export function addDisputeEvidence(
  dispute: Dispute,
  userId: string,
  evidence: Omit<DisputeEvidence, "uploadedBy" | "uploadedAt" | "id">
): Dispute {
  const evidenceWithMetadata: DisputeEvidence = {
    ...evidence,
    id: uid("evidence"),
    uploadedBy: userId,
    uploadedAt: Date.now(),
  }

  if (userId === dispute.buyerId) {
    return {
      ...dispute,
      buyerEvidence: [...dispute.buyerEvidence, evidenceWithMetadata],
    }
  } else {
    return {
      ...dispute,
      sellerEvidence: [...dispute.sellerEvidence, evidenceWithMetadata],
    }
  }
}

export function addDisputeMessage(dispute: Dispute, userId: string, text: string): Dispute {
  return {
    ...dispute,
    messages: [
      ...dispute.messages,
      {
        userId,
        text,
        at: Date.now(),
      },
    ],
  }
}

export function resolveDispute(
  dispute: Dispute,
  adminId: string,
  resolutionType: ResolutionType,
  reason: string,
  compensationAmount?: number
): Dispute {
  return {
    ...dispute,
    status: "resolved",
    resolvedAt: Date.now(),
    adminId,
    resolution: {
      type: resolutionType,
      reason,
      compensationAmount,
    },
  }
}

/**
 * BUYER PROTECTION
 * Protects buyers from fraud and non-delivery
 */

export function createBuyerProtection(orderId: string, buyerId: string, amount: number): BuyerProtection {
  const PROTECTION_DAYS = 30
  return {
    orderId,
    buyerId,
    protectionAmount: amount,
    protectionStatus: "active",
    expiresAt: Date.now() + PROTECTION_DAYS * 24 * 60 * 60 * 1000,
  }
}

export function claimBuyerProtection(
  protection: BuyerProtection,
  reason: string
): BuyerProtection {
  if (protection.protectionStatus !== "active") {
    throw new Error("Protection is not active")
  }
  if (Date.now() > protection.expiresAt) {
    throw new Error("Protection has expired")
  }

  return {
    ...protection,
    protectionStatus: "claimed",
    claimedAt: Date.now(),
    claimReason: reason,
  }
}

/**
 * SELLER PROTECTION
 * Protects sellers from chargebacks and false claims
 */

export function createSellerProtection(orderId: string, sellerId: string, amount: number): SellerProtection {
  const PROTECTION_DAYS = 90
  return {
    orderId,
    sellerId,
    protectionAmount: amount,
    protectionStatus: "active",
    expiresAt: Date.now() + PROTECTION_DAYS * 24 * 60 * 60 * 1000,
  }
}

/**
 * REFUND SYSTEM
 * Handles refund requests and workflow
 */

export function createRefundRequest(
  orderId: string,
  buyerId: string,
  sellerId: string,
  amount: number,
  reason: string
): RefundRequest {
  return {
    id: uid("refund"),
    orderId,
    buyerId,
    sellerId,
    amount,
    reason,
    requestedAt: Date.now(),
    status: "pending",
  }
}

export function approveRefund(refund: RefundRequest, adminId: string, notes?: string): RefundRequest {
  return {
    ...refund,
    status: "approved",
    approvedAt: Date.now(),
    adminId,
    sellerNotes: notes,
  }
}

export function completeRefund(refund: RefundRequest): RefundRequest {
  return {
    ...refund,
    status: "completed",
    completedAt: Date.now(),
  }
}

/**
 * MONEY BACK GUARANTEE
 * 30/60 day money back guarantee for buyers
 */

export function createMoneyBackGuarantee(
  orderId: string,
  buyerId: string,
  amount: number,
  guaranteeDays: number = 30
): MoneyBackGuarantee {
  return {
    id: uid("guarantee"),
    orderId,
    buyerId,
    amount,
    guaranteeDays,
    startedAt: Date.now(),
    expiresAt: Date.now() + guaranteeDays * 24 * 60 * 60 * 1000,
    claimed: false,
  }
}

export function claimMoneyBackGuarantee(
  guarantee: MoneyBackGuarantee,
  claimAmount: number = guarantee.amount
): MoneyBackGuarantee {
  if (guarantee.claimed) {
    throw new Error("Guarantee already claimed")
  }
  if (Date.now() > guarantee.expiresAt) {
    throw new Error("Guarantee has expired")
  }

  return {
    ...guarantee,
    claimed: true,
    claimAmount,
  }
}

/**
 * TRUST METRICS & SCORING
 * Calculate seller trustworthiness based on trading history
 */

export interface TrustMetrics {
  disputeRate: number // percentage of orders with disputes
  refundRate: number // percentage of orders refunded
  escrowReleaseRate: number // percentage of escrow successfully released
  avgResponseTime: number // minutes
  trustScore: number // 0-100
  trustLevel: "low" | "medium" | "high" | "premium"
}

export function calculateTrustMetrics(orders: Order[], disputes: Dispute[]): TrustMetrics {
  if (orders.length === 0) {
    return {
      disputeRate: 0,
      refundRate: 0,
      escrowReleaseRate: 0,
      avgResponseTime: 0,
      trustScore: 50, // neutral for new sellers
      trustLevel: "medium",
    }
  }

  const ordersWithDisputes = disputes.length
  const disputeRate = (ordersWithDisputes / orders.length) * 100
  const refundedOrders = orders.filter(o => o.status === "cancelled").length
  const refundRate = (refundedOrders / orders.length) * 100

  // Trust score calculation: lower dispute/refund rates = higher trust
  let trustScore = 100
  trustScore -= disputeRate * 0.5 // up to 50 points for disputes
  trustScore -= refundRate * 0.3 // up to 30 points for refunds
  trustScore = Math.max(0, Math.min(100, trustScore))

  const trustLevel =
    trustScore >= 80 ? "premium" : trustScore >= 60 ? "high" : trustScore >= 40 ? "medium" : "low"

  return {
    disputeRate: Math.round(disputeRate * 10) / 10,
    refundRate: Math.round(refundRate * 10) / 10,
    escrowReleaseRate: 100 - Math.round(refundRate * 10) / 10,
    avgResponseTime: 60, // placeholder
    trustScore: Math.round(trustScore),
    trustLevel,
  }
}
