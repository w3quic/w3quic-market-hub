import type {
  Product,
  SellerStore,
  UserProfile,
  AIRecommendation,
  TrendingData,
  FraudDetection,
  UserBehaviorProfile,
  Category,
  Order,
  Review,
} from "./types"
import { uid } from "./helpers"

export class AIEngine {
  // Product Recommendations
  static generateProductRecommendations(
    userId: string,
    userProfile: UserBehaviorProfile,
    allProducts: Product[],
    userPurchaseHistory: string[] = [],
    topK: number = 10,
  ): AIRecommendation[] {
    const recommendations: AIRecommendation[] = []
    const scored = new Map<string, number>()

    for (const product of allProducts) {
      let score = 0

      // Category preference match (40%)
      if (userProfile.preferredCategories.includes(product.category)) {
        score += 0.4
      }

      // Price range preference (20%)
      const avgPurchase = userProfile.avgPurchaseAmount
      if (Math.abs(product.price - avgPurchase) < avgPurchase * 0.3) {
        score += 0.2
      }

      // Not recently purchased (20%)
      if (!userPurchaseHistory.includes(product.id)) {
        score += 0.2
      }

      // Quality signals (20%)
      if (product.scamScore < 30 && !product.sponsored) {
        score += 0.2
      }

      if (score > 0) {
        scored.set(product.id, score)
      }
    }

    // Sort and take top K
    const sorted = Array.from(scored.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, topK)

    for (const [productId, score] of sorted) {
      const product = allProducts.find((p) => p.id === productId)
      if (product) {
        recommendations.push({
          id: uid("rec"),
          userId,
          type: "product",
          targetId: productId,
          score: Math.min(score, 1),
          reason: `Based on your interest in ${product.category}`,
          clickCount: 0,
          viewCount: 0,
          conversionCount: 0,
        })
      }
    }

    return recommendations
  }

  // Smart Search
  static smartSearch(
    query: string,
    products: Product[],
    sellers: UserProfile[],
    stores: SellerStore[],
  ): {
    products: Product[]
    sellers: UserProfile[]
    stores: SellerStore[]
    suggestions: string[]
  } {
    const lowerQuery = query.toLowerCase()
    const words = lowerQuery.split(/\s+/)

    // Search products
    const productResults = products
      .map((p) => {
        let score = 0
        const title = p.title.toLowerCase()
        const desc = p.description.toLowerCase()

        for (const word of words) {
          if (title.includes(word)) score += 3
          if (desc.includes(word)) score += 1
        }

        // Boost non-scam items
        if (p.scamScore < 30) score += 0.5

        return { product: p, score }
      })
      .filter((r) => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 20)
      .map((r) => r.product)

    // Search sellers
    const sellerResults = sellers
      .filter((s) => {
        const name = s.displayName.toLowerCase()
        return words.some((w) => name.includes(w))
      })
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 5)

    // Search stores
    const storeResults = stores
      .filter((s) => {
        const name = s.storeName.toLowerCase()
        return words.some((w) => name.includes(w))
      })
      .sort((a, b) => b.views - a.views)
      .slice(0, 5)

    // Generate suggestions
    const suggestions = this.generateSearchSuggestions(query, productResults)

    return {
      products: productResults,
      sellers: sellerResults,
      stores: storeResults,
      suggestions,
    }
  }

  private static generateSearchSuggestions(
    query: string,
    results: Product[],
  ): string[] {
    const suggestions = new Set<string>()

    // Category suggestions
    const categories = results.slice(0, 5).map((p) => p.category)
    for (const cat of categories) {
      suggestions.add(`${query} ${cat}`)
    }

    // Brand suggestions (from product titles)
    const brands = results
      .slice(0, 3)
      .map((p) => p.title.split(" ")[0])
      .filter((b) => b.length > 2)
    for (const brand of brands) {
      suggestions.add(`${brand}`)
    }

    return Array.from(suggestions).slice(0, 5)
  }

  // Trending Analysis
  static calculateTrending(
    products: Product[],
    orders: Order[],
    reviews: Review[],
    searches: string[] = [],
  ): TrendingData {
    const today = new Date().toISOString().split("T")[0]

    // Calculate product trends
    const productTrends = new Map<string, number>()
    const last7Days = Date.now() - 7 * 24 * 60 * 60 * 1000

    for (const order of orders) {
      if (order.createdAt > last7Days) {
        for (const item of order.items) {
          const current = productTrends.get(item.productId) || 0
          productTrends.set(item.productId, current + 1)
        }
      }
    }

    // Calculate store trends
    const storeTrends = new Map<string, number>()
    for (const product of products) {
      if (product.updatedAt > last7Days && product.views > 0) {
        const current = storeTrends.get(product.sellerId) || 0
        storeTrends.set(product.sellerId, current + product.views)
      }
    }

    // Search volume trends
    const searchVolume = new Map<string, number>()
    for (const search of searches) {
      const current = searchVolume.get(search) || 0
      searchVolume.set(search, current + 1)
    }

    // Category trends
    const categoryVolume = new Map<string, number>()
    for (const order of orders) {
      if (order.createdAt > last7Days) {
        for (const item of order.items) {
          const product = products.find((p) => p.id === item.productId)
          if (product) {
            const current = categoryVolume.get(product.category) || 0
            categoryVolume.set(product.category, current + 1)
          }
        }
      }
    }

    return {
      date: today,
      products: Array.from(productTrends.entries())
        .map(([id, trend]) => ({ id, trend }))
        .sort((a, b) => b.trend - a.trend)
        .slice(0, 20),
      stores: Array.from(storeTrends.entries())
        .map(([id, trend]) => ({ id, trend }))
        .sort((a, b) => b.trend - a.trend)
        .slice(0, 20),
      searches: Array.from(searchVolume.entries())
        .map(([query, volume]) => ({ query, volume }))
        .sort((a, b) => b.volume - a.volume)
        .slice(0, 20),
      categories: Array.from(categoryVolume.entries())
        .map(([category, volume]) => ({ category: category as Category, volume }))
        .sort((a, b) => b.volume - a.volume),
    }
  }

  // Fraud Detection
  static detectFraudPatterns(
    userId: string,
    user: UserProfile,
    recentOrders: Order[],
    recentPurchases: Order[],
  ): FraudDetection | null {
    const flags: string[] = []
    let suspicionLevel: "low" | "medium" | "high" | "critical" = "low"

    // Check for unusual activity
    const last24hOrders = recentOrders.filter(
      (o) => o.createdAt > Date.now() - 24 * 60 * 60 * 1000,
    )
    if (last24hOrders.length > 10) {
      flags.push("high-order-frequency")
      suspicionLevel = "medium"
    }

    // Check for high spending
    const last24hSpend = last24hOrders.reduce((sum, o) => sum + o.total, 0)
    if (last24hSpend > 100) {
      // 100 Pi
      flags.push("high-spend-24h")
      suspicionLevel = "medium"
    }

    // New user with suspicious activity
    const accountAge = Date.now() - user.joinedAt
    if (accountAge < 7 * 24 * 60 * 60 * 1000) {
      // less than 1 week
      if (suspicionLevel === "medium") {
        suspicionLevel = "high"
        flags.push("new-account-suspicious-activity")
      }
    }

    // Check for rapid location changes
    const locations = new Set(recentOrders.map((o) => o.shippingRegion))
    if (locations.size > 3 && last24hOrders.length > 5) {
      flags.push("rapid-location-changes")
      suspicionLevel = "high"
    }

    // Check for disputes/chargebacks
    const disputedOrders = recentOrders.filter((o) => o.dispute)
    if (disputedOrders.length > 2) {
      flags.push("multiple-disputes")
      suspicionLevel = "high"
    }

    if (flags.length === 0) return null

    return {
      id: uid("fraud"),
      entityType: "user",
      entityId: userId,
      suspicionLevel,
      flags,
      createdAt: Date.now(),
    }
  }

  // Behavioral Profile
  static buildBehaviorProfile(
    user: UserProfile,
    orders: Order[],
    products: Product[],
  ): UserBehaviorProfile {
    // Calculate average purchase amount
    const avgPurchase =
      orders.length > 0
        ? orders.reduce((sum, o) => sum + o.total, 0) / orders.length
        : 0

    // Calculate purchase frequency (orders per day)
    const accountAge = Math.max((Date.now() - user.joinedAt) / (24 * 60 * 60 * 1000), 1)
    const purchaseFrequency = orders.length / accountAge

    // Find preferred categories
    const categoryCount = new Map<Category, number>()
    for (const order of orders) {
      for (const item of order.items) {
        const product = products.find((p) => p.id === item.productId)
        if (product) {
          const count = categoryCount.get(product.category) || 0
          categoryCount.set(product.category, count + 1)
        }
      }
    }

    const preferredCategories = Array.from(categoryCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([cat]) => cat)

    // Determine browse behavior
    let browseBehavior:
      | "quick-browser"
      | "thorough-reader"
      | "impulse-buyer"
      | "comparison-shopper" = "comparison-shopper"

    if (purchaseFrequency > 0.5) {
      browseBehavior = "impulse-buyer"
    } else if (avgPurchase > 50) {
      browseBehavior = "thorough-reader"
    } else if (purchaseFrequency < 0.05) {
      browseBehavior = "quick-browser"
    }

    // Trust score based on account age and transaction history
    const trustScore = Math.min(
      100,
      Math.floor((accountAge / 365) * 20 + user.rating * 10 + user.totalTransactions),
    )

    return {
      userId: user.id,
      avgPurchaseAmount: avgPurchase,
      purchaseFrequency,
      preferredCategories: preferredCategories as Category[],
      browseBehavior,
      trustScore,
      suspiciousBehaviors: [],
    }
  }
}

// Trending patterns
export const TRENDING_CATEGORIES = {
  seasonal: ["electronics", "fashion", "home"],
  holidays: ["gifts", "toys", "food"],
  weekly: ["sports", "books"],
}
