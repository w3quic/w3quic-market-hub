export type Category =
  | "electronics"
  | "fashion"
  | "home"
  | "services"
  | "vehicles"
  | "food"
  | "sports"
  | "books"
  | "toys"
  | "other"

export const CATEGORIES: { id: Category; label: string; icon: string }[] = [
  { id: "electronics", label: "Electronics", icon: "Smartphone" },
  { id: "fashion", label: "Fashion", icon: "Shirt" },
  { id: "home", label: "Home & Garden", icon: "Home" },
  { id: "services", label: "Services", icon: "Wrench" },
  { id: "vehicles", label: "Vehicles", icon: "Car" },
  { id: "food", label: "Food", icon: "UtensilsCrossed" },
  { id: "sports", label: "Sports", icon: "Dumbbell" },
  { id: "books", label: "Books", icon: "BookOpen" },
  { id: "toys", label: "Toys", icon: "ToyBrick" },
  { id: "other", label: "Other", icon: "Package" },
]

export type Condition = "new" | "like-new" | "good" | "fair"
export type VerificationLevel = "none" | "basic" | "trusted" | "verified"
export type AdminRole = "super" | "moderator" | "analyst" | null

export interface Variation {
  id: string
  name: string
  price: number
  stock: number
  sku: string
}

export interface Product {
  id: string
  sellerId: string
  title: string
  description: string
  price: number
  category: Category
  subcategory?: string
  condition: Condition
  variations: Variation[]
  stock: number
  location: string
  images: string[]
  deliveryOptions: string[]
  createdAt: number
  updatedAt: number
  views: number
  featured: boolean
  sponsored: boolean
  // flash deal
  flashDeal?: { discountPercent: number; endsAt: number }
  // auction
  auction?: {
    startingBid: number
    minIncrement: number
    reserve?: number
    endsAt: number
    bids: { userId: string; amount: number; at: number }[]
  }
  scamScore: number
  reservedUntil?: number
  reservedBy?: string
  handlingTimeDays: number
}

export interface SellerStore {
  sellerId: string
  storeName: string
  banner?: string
  logo?: string
  description: string
  categories: string[]
  followers: string[]
  announcement?: { title: string; text: string; published: boolean }
  vacation?: { enabled: boolean; returnDate: string }
  views: number
}

export interface UserProfile {
  id: string
  displayName: string
  bio: string
  rating: number
  ratingCount: number
  reputationScore: number
  joinedAt: number
  totalTransactions: number
  verification: VerificationLevel
  favoriteSellers: string[]
  loyaltyPoints: number
  badges: string[]
  isSeller: boolean
  isPremium: boolean
  premiumActivatedAt?: number
  adminRole: AdminRole
  referralCode: string
  referredBy?: string
  responseTimeMins: number
  disputesResolved: number
  // daily login
  lastLogin?: number
  loginStreak: number
  achievements: string[]
}

export type OrderStatus =
  | "placed"
  | "confirmed"
  | "shipped"
  | "in-transit"
  | "delivered"
  | "completed"
  | "disputed"
  | "cancelled"

export interface OrderItem {
  productId: string
  title: string
  image?: string
  variationId?: string
  variationName?: string
  price: number
  quantity: number
}

export interface Order {
  id: string
  buyerId: string
  sellerId: string
  items: OrderItem[]
  subtotal: number
  discount: number
  shipping: number
  tax: number
  total: number
  loyaltyUsed: number
  status: OrderStatus
  escrowStatus: "held" | "released" | "refunded"
  createdAt: number
  timeline: { status: OrderStatus; at: number }[]
  shippingRegion: string
  estimatedDelivery: string
  dispute?: { reason: string; buyerMsg: string; sellerMsg?: string; resolution?: string; status: "open" | "resolved" }
  reviewed: boolean
}

export interface CartItem {
  productId: string
  variationId?: string
  quantity: number
}

export interface Review {
  id: string
  productId: string
  sellerId: string
  buyerId: string
  buyerName: string
  rating: number
  text: string
  createdAt: number
}

export interface Message {
  id: string
  conversationId: string
  senderId: string
  text: string
  at: number
  offer?: { amount: number; status: "pending" | "accepted" | "rejected" | "countered"; round: number }
}

export interface Conversation {
  id: string
  buyerId: string
  sellerId: string
  productId?: string
  lastMessageAt: number
}

export type NotificationType =
  | "message"
  | "order"
  | "review"
  | "dispute"
  | "flash"
  | "flagged"
  | "auction"
  | "offer"
  | "announcement"
  | "achievement"
  | "reward"

export interface AppNotification {
  id: string
  userId: string
  type: NotificationType
  title: string
  body: string
  at: number
  read: boolean
  link?: string
}

export interface Report {
  id: string
  reporterId: string
  targetType: "product" | "user" | "review" | "message"
  targetId: string
  reason: string
  description: string
  status: "pending" | "resolved" | "dismissed"
  at: number
}

export interface AuditLog {
  id: string
  adminId: string
  action: string
  target: string
  before?: string
  after?: string
  at: number
}

export interface Coupon {
  code: string
  discountPercent: number
}

// ============================================================================
// SECURE TRADING SYSTEM
// ============================================================================

export type DisputeReasonType =
  | "item-not-received"
  | "item-not-as-described"
  | "defective-damaged"
  | "counterfeit"
  | "unauthorized-transaction"
  | "wrong-item"
  | "other"

export type DisputeStatus = "open" | "in-review" | "resolved" | "closed"
export type ResolutionType = "refund-buyer" | "release-to-seller" | "partial-refund" | "no-action"

export interface EscrowTransaction {
  id: string
  orderId: string
  buyerId: string
  sellerId: string
  amount: number // in Pi
  status: "held" | "released" | "refunded" | "disputed"
  heldAt: number
  releasedAt?: number
  refundedAt?: number
  buyerConfirmedDelivery?: boolean
  sellerConfirmedShipment?: boolean
}

export interface DisputeEvidence {
  id: string
  type: "image" | "document" | "message" | "tracking"
  url: string
  uploadedBy: string // buyerId or sellerId
  uploadedAt: number
  description: string
}

export interface Dispute {
  id: string
  orderId: string
  escrowId: string
  buyerId: string
  sellerId: string
  reason: DisputeReasonType
  description: string
  buyerEvidence: DisputeEvidence[]
  sellerEvidence: DisputeEvidence[]
  buyerMessage: string
  sellerMessage?: string
  status: DisputeStatus
  openedAt: number
  resolvedAt?: number
  adminId?: string
  resolution?: {
    type: ResolutionType
    reason: string
    compensationAmount?: number
  }
  messages: {
    userId: string
    text: string
    at: number
  }[]
}

export interface BuyerProtection {
  orderId: string
  buyerId: string
  protectionAmount: number // in Pi
  protectionStatus: "active" | "claimed" | "expired"
  expiresAt: number
  claimedAt?: number
  claimReason?: string
}

export interface SellerProtection {
  orderId: string
  sellerId: string
  protectionAmount: number // in Pi
  protectionStatus: "active" | "claimed" | "expired"
  expiresAt: number
  claimedAt?: number
  claimReason?: string
}

export interface RefundRequest {
  id: string
  orderId: string
  buyerId: string
  sellerId: string
  amount: number // in Pi
  reason: string
  requestedAt: number
  status: "pending" | "approved" | "rejected" | "completed"
  approvedAt?: number
  completedAt?: number
  sellerNotes?: string
  adminId?: string
}

export interface MoneyBackGuarantee {
  id: string
  orderId: string
  buyerId: string
  amount: number // in Pi
  guaranteeDays: number
  startedAt: number
  expiresAt: number
  claimed: boolean
  claimAmount?: number
}

// ============================================================================
// BUSINESS VERIFICATION SYSTEM
// ============================================================================

export type VerificationDocumentType =
  | "business-license"
  | "tax-id"
  | "identity-document"
  | "address-proof"
  | "bank-statement"
  | "incorporation-cert"

export type VerificationStatus = "pending" | "approved" | "rejected" | "expired"

export interface VerificationDocument {
  id: string
  userId: string
  type: VerificationDocumentType
  fileUrl: string
  uploadedAt: number
  expiresAt?: number
  status: VerificationStatus
  rejectionReason?: string
}

export interface BusinessVerification {
  userId: string
  businessName: string
  registrationNumber: string
  businessType: "sole-proprietor" | "partnership" | "corporation" | "llc" | "other"
  documents: VerificationDocument[]
  status: VerificationStatus
  verifiedAt?: number
  approvedBy?: string
  expiresAt?: number
}

export interface IdentityVerification {
  userId: string
  documentType: "passport" | "national-id" | "driver-license" | "visa"
  documentNumber: string
  documentUrl: string
  faceVerificationUrl?: string
  uploadedAt: number
  status: VerificationStatus
  verifiedAt?: number
  approvedBy?: string
  expiresAt?: number
}

export type VerificationBadgeType =
  | "email-verified"
  | "identity-verified"
  | "business-verified"
  | "high-volume-seller"
  | "trusted-seller"
  | "premium-seller"
  | "eco-friendly"

// ============================================================================
// SHIPPING & LOGISTICS SYSTEM
// ============================================================================

export type TrackingStatus =
  | "label-created"
  | "picked-up"
  | "in-transit"
  | "out-for-delivery"
  | "delivered"
  | "exception"
  | "returned"

export interface TrackingUpdate {
  status: TrackingStatus
  location?: string
  timestamp: number
  message: string
}

export interface ShippingLabel {
  id: string
  orderId: string
  trackingNumber: string
  carrier: "dhl" | "fedex" | "ups" | "local" | "other"
  shippingCost: number // in Pi
  estimatedDelivery: string
  createdAt: number
}

export interface Shipment {
  id: string
  orderId: string
  sellerId: string
  buyerId: string
  items: OrderItem[]
  shippingLabel: ShippingLabel
  trackingUpdates: TrackingUpdate[]
  deliveryConfirmedAt?: number
  deliverySignature?: string
  handledBy?: string // delivery person name
  notes?: string
}

export interface DeliveryPreference {
  userId: string
  preferredCarrier: string
  preferredDeliveryType: "standard" | "express" | "overnight" | "scheduled"
  requireSignature: boolean
  allowHoldAtLocation: boolean
  preferredTimeSlots: string[]
}

// ============================================================================
// ADVERTISING PLATFORM
// ============================================================================

export type AdCampaignStatus = "draft" | "active" | "paused" | "completed" | "rejected"
export type AdType = "featured-product" | "featured-store" | "sponsored-search" | "promotion" | "flash-sale"

export interface AdCampaign {
  id: string
  createdBy: string // sellerId
  type: AdType
  targetId?: string // productId or storeId
  budget: number // in Pi
  dailyBudget?: number
  bidAmount?: number
  status: AdCampaignStatus
  startDate: number
  endDate: number
  impressions: number
  clicks: number
  conversions: number
  createdAt: number
  approvedBy?: string
  approvalReason?: string
}

export interface AdMetrics {
  campaignId: string
  impressions: number
  clicks: number
  conversions: number
  spend: number // in Pi
  roi: number
  ctr: number // click-through rate
  conversionRate: number
}

export interface PromotionalOffer {
  id: string
  sellerId: string
  productId?: string
  discountType: "percentage" | "fixed" | "bogo" | "tiered"
  discountValue: number
  maxDiscountAmount?: number
  minPurchaseAmount?: number
  startDate: number
  endDate: number
  applicableCategory?: Category
  maxUses?: number
  currentUses: number
  createdAt: number
}

// ============================================================================
// MARKETPLACE GROWTH & LOYALTY
// ============================================================================

export interface ReferralProgram {
  referrerId: string
  referredUserId: string
  status: "pending" | "completed" | "expired"
  bonusAmount: number // in Pi
  claimedAt?: number
  createdAt: number
}

export interface AffiliateAccount {
  id: string
  userId: string
  commissionRate: number // percentage
  earnings: number // in Pi
  withdrawn: number
  status: "active" | "suspended" | "inactive"
  createdAt: number
}

export interface LoyaltyReward {
  id: string
  userId: string
  type: "purchase" | "review" | "referral" | "daily-checkin" | "achievement"
  pointsEarned: number
  description: string
  createdAt: number
}

export interface Achievement {
  id: string
  code: string
  name: string
  description: string
  icon: string
  requirement: {
    type: "purchases" | "reviews" | "referrals" | "sales" | "rating" | "verification"
    value: number
  }
  rewardPoints: number
  tier: "bronze" | "silver" | "gold" | "platinum"
}

export interface DailyCheckIn {
  userId: string
  date: string
  checkedInAt: number
  streakDays: number
  rewardPoints: number
  bonusMultiplier: number // higher for longer streaks
}

export interface SellerRanking {
  sellerId: string
  rank: number
  tier: "beginner" | "established" | "professional" | "elite"
  score: number
  metrics: {
    responseTime: number
    shippingSpeed: number
    itemAccuracy: number
    communicationRating: number
    overallRating: number
  }
}

export interface ReputationScore {
  userId: string
  score: number // 0-100
  level: "new" | "basic" | "trusted" | "expert" | "elite"
  completedSales: number
  positiveRatings: number
  neutralRatings: number
  negativeRatings: number
  avgResponseTime: number
  firstSaleAt?: number
  consistencyBonus: number
}

// ============================================================================
// ARTIFICIAL INTELLIGENCE & RECOMMENDATIONS
// ============================================================================

export interface AIRecommendation {
  id: string
  userId: string
  type: "product" | "store" | "search" | "category"
  targetId: string
  score: number // 0-1 confidence
  reason: string
  clickCount: number
  viewCount: number
  conversionCount: number
}

export interface TrendingData {
  date: string
  products: { id: string; trend: number }[]
  stores: { id: string; trend: number }[]
  searches: { query: string; volume: number }[]
  categories: { category: Category; volume: number }[]
}

export interface FraudDetection {
  id: string
  entityType: "user" | "product" | "order" | "transaction"
  entityId: string
  suspicionLevel: "low" | "medium" | "high" | "critical"
  flags: string[]
  createdAt: number
  resolvedAt?: number
  resolution?: "approved" | "blocked" | "reviewed"
  adminId?: string
}

export interface UserBehaviorProfile {
  userId: string
  avgPurchaseAmount: number
  purchaseFrequency: number
  preferredCategories: Category[]
  browseBehavior: "quick-browser" | "thorough-reader" | "impulse-buyer" | "comparison-shopper"
  trustScore: number
  suspiciousBehaviors: string[]
}

// ============================================================================
// ADMIN & MARKETPLACE MANAGEMENT
// ============================================================================

export interface MarketplaceAnalytics {
  date: string
  totalUsers: number
  activeUsers: number
  totalOrders: number
  totalRevenue: number // in Pi
  averageOrderValue: number
  conversionRate: number
  topCategories: { category: Category; count: number }[]
  topSellers: { id: string; sales: number }[]
  userRetention: number
  newUsers: number
  churned: number
}

export interface AdminAuditLog {
  id: string
  adminId: string
  action: string
  targetType: string
  targetId: string
  changes: Record<string, any>
  timestamp: number
  ipAddress?: string
}

export interface SellerManagementAction {
  id: string
  sellerId: string
  adminId: string
  action: "suspend" | "restrict" | "warn" | "reinstate" | "tier-change"
  reason: string
  duration?: number // in days
  appliedAt: number
  expiresAt?: number
  notes?: string
}

export interface ProductModerationQueue {
  id: string
  productId: string
  reason: string // policy violation reason
  submittedAt: number
  assignedTo?: string // admin id
  status: "pending" | "approved" | "rejected" | "needs-edit"
  reviewedAt?: number
  decision?: string
}

export interface VerificationApprovalQueue {
  id: string
  userId: string
  type: "business" | "identity"
  documents: VerificationDocument[]
  submittedAt: number
  assignedTo?: string // admin id
  status: "pending" | "approved" | "rejected" | "needs-resubmit"
  reviewedAt?: number
  notes?: string
}

export interface SystemMetrics {
  timestamp: number
  apiLatency: number
  dbLatency: number
  errorRate: number
  activeConnections: number
  memoryUsage: number
  cpuUsage: number
  uptime: number
}

// ============================================================================
// USER EXPERIENCE & PREFERENCES
// ============================================================================

export interface UserPreferences {
  userId: string
  theme: "light" | "dark" | "auto"
  language: "en" | "es" | "fr" | "de" | "zh" | "ja" | "ar"
  notifications: {
    email: boolean
    push: boolean
    sms: boolean
    inApp: boolean
  }
  offlineMode: boolean
  compactView: boolean
  currency: "pi" | "usd" | "eur"
}

export interface OfflineData {
  userId: string
  cachedProducts: string[] // product ids
  cachedPages: string[] // page urls
  lastSyncTime: number
  syncSize: number // in bytes
}
