# Vehicle Marketplace Quick Reference

## ⚡ Quick Facts

- **Product ID:** `6a34c37c8a9e196fe6e7f4f1`
- **Price:** 0.5 Pi
- **Button Component:** `/components/market/vehicle-marketplace-button.tsx`
- **View Component:** `/components/market/vehicle-marketplace-view.tsx`
- **Color Theme:** Amber/Orange (#F59E0B)

## 📍 Button Placements

| Location | File | Component | Variant | Width |
|----------|------|-----------|---------|-------|
| Home Page | `home-view.tsx` | VehicleMarketplaceButton | default | full |
| Profile Page | `profile-view.tsx` | VehicleMarketplaceButton | default | full |
| Seller Dashboard | `seller-view.tsx` | VehicleMarketplaceButton | default/features | full |
| Browse/Marketplace | `browse-view.tsx` | VehicleMarketplaceButton | default | full |
| Navigation | `nav.tsx` + `market-app.tsx` | Routed view | - | - |

## 🔧 Component Usage

### Import
\`\`\`typescript
import { VehicleMarketplaceButton } from "./vehicle-marketplace-button"
\`\`\`

### Basic Usage
\`\`\`tsx
<VehicleMarketplaceButton variant="default" fullWidth={true} />
\`\`\`

### With Features
\`\`\`tsx
<VehicleMarketplaceButton 
  variant="default" 
  fullWidth={true}
  showFeatures={true}
  onSuccess={() => console.log('Purchase success!')}
/>
\`\`\`

### Props
- `onSuccess?: () => void` - Callback after successful purchase
- `variant?: 'default' | 'outline'` - Button style
- `showPriceInLabel?: boolean` - Show price in button text (default: true)
- `showFeatures?: boolean` - Show features list (default: false)
- `fullWidth?: boolean` - Full width button (default: false)

## 🎯 Purchase Flow

1. **User clicks button**
   ↓
2. **SDK initiates Pi payment** via `makePurchase(product.slug)`
   ↓
3. **On success** → Shows success message + navigates to vehicle-marketplace view
   ↓
4. **On error** → Shows error message with specific error code
   ↓
5. **After purchase** → Button shows "Vehicle Marketplace Activated" badge

## 🔐 Activation Check

\`\`\`typescript
// Button automatically checks if user has purchased
const isVehicleMarketplacePurchased = restoredPurchases?.some(
  p => p.productId === product?.slug
);

// If purchased, shows activation badge instead of button
if (isVehicleMarketplacePurchased) {
  return <ActivationBadge />
}
\`\`\`

## 📝 Product Config Reference

\`\`\`typescript
// /lib/product-config.ts
PRODUCT_CONFIG.PRODUCT_6a34c37c8a9e196fe6e7f4f1 // "6a34c37c8a9e196fe6e7f4f1"
\`\`\`

## 🎨 Styling

### Colors
- Background: `from-amber-50 to-amber-100`
- Border: `border-amber-300`
- Button: `from-amber-600 to-amber-700`
- Text: `text-amber-900` / `text-amber-800`

### Sections in Placement Files
\`\`\`tsx
{/* Vehicle Marketplace Featured Section */}
<section className="px-4">
  <div className="rounded-2xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-amber-100 p-4">
    <div className="flex items-start justify-between mb-3">
      <div>
        <h2 className="text-sm font-bold text-amber-900">Vehicle Marketplace</h2>
        <p className="text-xs text-amber-800 mt-1">Buy, sell & trade vehicles</p>
      </div>
      <span className="text-xs font-semibold bg-amber-600 text-white px-2 py-1 rounded-full">0.5 π</span>
    </div>
    <VehicleMarketplaceButton variant="default" fullWidth={true} />
  </div>
</section>
\`\`\`

## 🚀 Navigation

### Navigate to Vehicle Marketplace
\`\`\`typescript
const { go } = useNav()
go({ name: 'vehicle-marketplace' })
\`\`\`

### In Top Bar
Title automatically displays: "Vehicle Marketplace"

## 🔄 State Management

### usePiAuth Hook
\`\`\`typescript
const { products, sdk, restoredPurchases, isAuthenticated } = usePiAuth()
\`\`\`

### Product Finding
\`\`\`typescript
const product = products?.find(
  p => p.id === PRODUCT_CONFIG.PRODUCT_6a34c37c8a9e196fe6e7f4f1
)
const price = product?.price_in_pi // 0.5
\`\`\`

### Purchase Status
\`\`\`typescript
const isPurchased = restoredPurchases?.some(
  p => p.productId === product?.slug
)
\`\`\`

## ⚠️ Error Codes

| Code | Meaning |
|------|---------|
| `product_not_found` | Product not in catalog |
| `purchase_cancelled` | User cancelled purchase |
| `purchase_error` | General payment error |
| `unknown_error` | Unexpected error |

## 📱 Responsive

- Mobile: Full width card sections
- Tablet/Desktop: Same layout, wider container
- All buttons responsive and touch-friendly

## ✅ Verification Checklist

- [ ] Button displays on all 5 locations
- [ ] Price shows 0.5 π
- [ ] Purchase flow works
- [ ] Success toast appears
- [ ] Error messages display correctly
- [ ] Activation badge shows after purchase
- [ ] Navigation to vehicle-marketplace works
- [ ] Works on mobile (portrait/landscape)
- [ ] Works on tablet/desktop
- [ ] Product config loads correctly

## 🆘 Troubleshooting

### Button not showing
- Check `usePiAuth()` is properly initialized
- Verify PRODUCT_CONFIG contains vehicle product ID
- Check product exists in SDK products array

### Purchase not working
- Verify SDK is ready (`!loading` from usePiAuth)
- Check user is authenticated
- Check browser console for error details

### Navigation not working
- Verify `useNav()` is available (inside NavProvider)
- Check view name "vehicle-marketplace" is in nav types
- Check market-app router includes vehicle-marketplace case

### Styling issues
- Check Tailwind CSS is properly configured
- Verify color classes are Tailwind v4 compatible
- Check gradient syntax: `from-amber-50 to-amber-100`
