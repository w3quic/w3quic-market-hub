# Pi Market Hub - Developer Quick Reference

## 🚀 Quick Start

### Animations
\`\`\`tsx
// Entrance animation
<div className="animate-fade-up">Content</div>

// Scale zoom
<div className="animate-scale-in">Content</div>

// Slide effect
<div className="animate-slide-in-right">Content</div>

// Hover scale
<div className="hover:scale-110 transition-transform">Hover me</div>

// Smooth transition
<div className="transition-all duration-300">Smooth</div>
\`\`\`

### Loading States
\`\`\`tsx
import { SkeletonCard, LoadingSpinner } from "@/components/market/ui-bits"

// Show skeleton while loading
<div>{loading ? <SkeletonCard /> : <Content />}</div>

// Show spinner
<LoadingSpinner size="md" />

// Skeleton text
<SkeletonText lines={3} />
\`\`\`

### Success/Error States
\`\`\`tsx
import { SuccessIcon, ErrorIcon } from "@/components/market/ui-bits"

// Success state
<SuccessIcon />

// Error state  
<ErrorIcon />
\`\`\`

### Design System
\`\`\`tsx
import {
  Card,
  Button,
  Badge,
  Alert,
  Section,
  Grid,
  Stack,
  Text,
} from "@/components/market/design-system"

// Card
<Card hover animated>
  <Text variant="h3">Title</Text>
</Card>

// Premium card
<PremiumCard>Premium content</PremiumCard>

// Button
<Button variant="primary" size="md">
  Click me
</Button>

// Badge
<Badge variant="success">New</Badge>

// Alert
<Alert type="success" title="Success" message="Done!" />

// Section
<Section title="My Section">
  Content here
</Section>

// Grid
<Grid cols={2} gap="md">
  {items.map(item => <div key={item}>{item}</div>)}
</Grid>

// Stack
<Stack direction="vertical" gap="md">
  <div>Item 1</div>
  <div>Item 2</div>
</Stack>
\`\`\`

---

## 🎨 Colors

### Usage
\`\`\`tsx
// Primary actions
<div className="bg-primary text-primary-foreground">
  Primary
</div>

// Secondary
<div className="bg-secondary text-secondary-foreground">
  Secondary
</div>

// Success
<div className="bg-green-500 text-white">Success</div>

// Warning
<div className="bg-amber-500 text-white">Warning</div>

// Error
<div className="bg-red-500 text-white">Error</div>
\`\`\`

---

## 📦 Spacing

\`\`\`tsx
// Padding
<div className="p-4">Default padding</div>
<div className="px-3 py-2">Horizontal & vertical</div>

// Margin
<div className="m-4">Default margin</div>
<div className="mx-2 my-4">Margin variants</div>

// Gap
<div className="flex gap-4">
  <div>Item 1</div>
  <div>Item 2</div>
</div>

// Space between
<div className="space-y-4">
  <div>Item 1</div>
  <div>Item 2</div>
</div>
\`\`\`

---

## 🎯 Accessibility

\`\`\`tsx
// Always add aria-labels
<button aria-label="Close menu">X</button>

// Semantic HTML
<button type="button">Click me</button>

// Alt text for images
<img src="..." alt="Description" />

// Focus styles (automatic with Tailwind)
<button className="focus-visible:ring-2 focus-visible:ring-ring">
  Focus visible
</button>

// Keyboard support
<input onKeyDown={(e) => {
  if (e.key === "Enter") handleSubmit()
}} />
\`\`\`

---

## 📱 Responsive

\`\`\`tsx
// Mobile first
<div className="text-sm md:text-base lg:text-lg">
  Responsive text
</div>

// Hidden on mobile
<div className="hidden sm:block">Desktop only</div>

// Mobile only
<div className="sm:hidden">Mobile only</div>

// Responsive columns
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
  {items.map(item => <Card key={item}>{item}</Card>)}
</div>
\`\`\`

---

## 🌙 Dark Mode

\`\`\`tsx
// Automatic with CSS variables
<div className="bg-background text-foreground">
  Works in light and dark
</div>

// Dark specific
<div className="dark:bg-slate-900">
  Dark mode styling
</div>

// All components support dark mode automatically
\`\`\`

---

## 🔄 Transitions

\`\`\`tsx
// Smooth transitions
<div className="transition-all duration-300">
  Changes smoothly
</div>

// Specific properties
<div className="transition-colors duration-200">
  Color changes only
</div>

// Custom timing
<div className="transition-all duration-700 ease-in-out">
  Slower transition
</div>
\`\`\`

---

## 🎬 Common Patterns

### Loading Component
\`\`\`tsx
import { SkeletonCard, LoadingSpinner } from "@/components/market/ui-bits"

export function MyComponent() {
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState(null)

  useEffect(() => {
    fetchData().then(d => {
      setData(d)
      setLoading(false)
    })
  }, [])

  if (loading) return <SkeletonCard />
  return <div>{data?.title}</div>
}
\`\`\`

### Interactive Card
\`\`\`tsx
import { Card } from "@/components/market/design-system"

export function ProductCard({ product }) {
  return (
    <Card
      className="hover:shadow-lg cursor-pointer"
      onClick={() => handleClick(product.id)}
    >
      <img src={product.image} alt={product.title} />
      <h3 className="font-bold mt-2">{product.title}</h3>
      <p className="text-primary font-bold">{product.price}</p>
    </Card>
  )
}
\`\`\`

### Form with Validation
\`\`\`tsx
import { Alert, Button } from "@/components/market/design-system"

export function LoginForm() {
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      await login()
      setError(null)
    } catch (err) {
      setError(err.message)
    }
    setLoading(false)
  }

  return (
    <form onSubmit={handleSubmit}>
      {error && <Alert type="error" message={error} />}
      <input type="email" required />
      <Button type="submit" loading={loading}>
        Login
      </Button>
    </form>
  )
}
\`\`\`

### Section Layout
\`\`\`tsx
import { Section, Grid } from "@/components/market/design-system"
import { ProductCard } from "./product-card"

export function HomePage() {
  const products = []

  return (
    <Section title="Featured Products">
      <Grid cols={2} gap="md">
        {products.map(p => (
          <ProductCard key={p.id} product={p} />
        ))}
      </Grid>
    </Section>
  )
}
\`\`\`

---

## 📊 Typography Variants

\`\`\`tsx
import { Text } from "@/components/market/design-system"

// Heading 1
<Text variant="h1">Large heading</Text>

// Heading 2
<Text variant="h2">Medium heading</Text>

// Heading 3
<Text variant="h3">Small heading</Text>

// Heading 4
<Text variant="h4">Smaller heading</Text>

// Body text
<Text variant="body">Regular body text</Text>

// Caption
<Text variant="caption">Small caption</Text>

// Label
<Text variant="label">LABEL TEXT</Text>
\`\`\`

---

## 🔗 Useful Links

- **Global Styles:** `/app/globals.css`
- **UI Bits:** `/components/market/ui-bits.tsx`
- **Design System:** `/components/market/design-system.tsx`
- **Full Guide:** `/lib/market/UI_UX_OPTIMIZATION_COMPLETE.md`
- **Production Ready:** `/lib/market/PRODUCTION_READINESS_2026.md`

---

## ⚡ Pro Tips

1. **Use className variants:** Always use `cn()` for conditional classes
2. **Mobile first:** Design for mobile, then add desktop styles
3. **Animation performance:** Use transforms instead of position changes
4. **Loading states:** Always show skeleton while loading
5. **Accessibility:** Test with keyboard navigation
6. **Dark mode:** Colors work automatically with CSS variables
7. **Responsive:** Test on actual devices
8. **Performance:** Lazy load images and components

---

## 🐛 Debugging

\`\`\`tsx
// Debug component rendering
console.log("[v0] Component rendered", { props })

// Debug state changes
useEffect(() => {
  console.log("[v0] State updated", { state })
}, [state])

// Debug animations
.animate-fade-up { animation: fade-up 0.4s ease-out both; }
/* Check if animation is applying */

// Debug responsive
// Add border for mobile layout debugging
className="border-2 border-red-500"
\`\`\`

---

## ✅ Pre-Commit Checklist

- [ ] Animation smooth (60fps)
- [ ] Mobile responsive
- [ ] Dark mode works
- [ ] Accessibility labels
- [ ] Loading states
- [ ] Error handling
- [ ] Performance good
- [ ] Tests passing

---

**That's it! Happy coding! 🚀**

For more details, see the full documentation in `/lib/market/`
