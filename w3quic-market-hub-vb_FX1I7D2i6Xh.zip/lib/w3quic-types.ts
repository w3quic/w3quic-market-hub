/**
 * W3QUIC Market Hub - Core Types
 * Extended marketplace types for multiple categories
 */

export type MarketplaceCategory = 'products' | 'services' | 'jobs' | 'vehicles' | 'real-estate'

export interface Listing {
  id: string
  sellerId: string
  sellerUsername: string
  title: string
  description: string
  category: MarketplaceCategory
  subcategory?: string
  priceInPi: number
  images: string[]
  condition?: string
  location?: string
  createdAt: number
  updatedAt: number
  views: number
  featured: boolean
  // Product specific
  stock?: number
  // Service specific
  serviceType?: string
  availability?: string
  // Job specific
  jobType?: 'full-time' | 'part-time' | 'contract' | 'freelance'
  salaryInPi?: number
  // Vehicle specific
  vehicleType?: string
  year?: number
  mileage?: number
  // Real estate specific
  propertyType?: string
  bedrooms?: number
  bathrooms?: number
  squareFeet?: number
}

export interface PiPaymentInfo {
  paymentId: string
  amount: number
  memo: string
  metadata: Record<string, any>
  status: 'pending' | 'approved' | 'completed' | 'failed'
  createdAt: number
  completedAt?: number
}

export interface MarketplaceSeller {
  id: string
  username: string
  displayName?: string
  bio?: string
  avatar?: string
  rating: number
  ratingCount: number
  totalSales: number
  joinedAt: number
  verified: boolean
}

export interface MarketplaceOrder {
  id: string
  buyerId: string
  buyerUsername: string
  sellerId: string
  listingId: string
  listingTitle: string
  priceInPi: number
  payment: PiPaymentInfo
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled'
  createdAt: number
  completedAt?: number
  shippingInfo?: {
    address: string
    city: string
    state: string
    zipCode: string
    country: string
  }
  buyerMessage?: string
}

export interface ConversationMessage {
  id: string
  conversationId: string
  senderId: string
  senderUsername: string
  text: string
  createdAt: number
}

export interface Conversation {
  id: string
  buyerId: string
  sellerId: string
  listingId: string
  lastMessageAt: number
  messages: ConversationMessage[]
}

export interface UserFavorite {
  id: string
  userId: string
  listingId: string
  createdAt: number
}

export interface UserCart {
  userId: string
  items: Array<{
    listingId: string
    quantity: number
    addedAt: number
  }>
}

export interface MarketplaceReview {
  id: string
  orderId: string
  buyerId: string
  buyerUsername: string
  sellerId: string
  rating: number // 1-5
  text: string
  createdAt: number
}
