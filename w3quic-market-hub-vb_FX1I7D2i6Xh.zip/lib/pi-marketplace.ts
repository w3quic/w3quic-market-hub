/**
 * W3QUIC Market Hub - Pi Network Payment Integration
 * Handles all Pi payment operations with proper callbacks and error handling
 */

export interface PiPaymentConfig {
  memo: string
  metadata: {
    productId: string
    category: string
    buyerUsername?: string
    marketplace: string
    [key: string]: any
  }
}

export interface PiPaymentCallbacks {
  onReadyForServerApproval: (paymentId: string) => Promise<void>
  onReadyForServerCompletion: (paymentId: string) => Promise<void>
  onCancel: (paymentId?: string) => void
  onError: (error: Error, paymentId?: string) => void
}

export interface PaymentState {
  paymentId: string
  status: 'pending' | 'approved' | 'completed' | 'cancelled' | 'failed'
  amount: number
  productId: string
  category: string
  timestamp: number
}

// Store payment state in memory during session
const paymentStates = new Map<string, PaymentState>()

/**
 * Initialize Pi SDK and set up payment handlers
 */
export async function initializePiSDK(): Promise<boolean> {
  try {
    if (typeof window.Pi === 'undefined') {
      console.error('[Pi SDK] Pi object not available')
      return false
    }

    await window.Pi.init({
      version: '2.0',
      sandbox: true, // Set to false for mainnet
    })

    console.log('[Pi SDK] Initialized successfully')
    return true
  } catch (error) {
    console.error('[Pi SDK] Initialization failed:', error)
    return false
  }
}

/**
 * Authenticate user with Pi Network
 */
export async function authenticateWithPi(): Promise<string | null> {
  try {
    if (typeof window.Pi === 'undefined') {
      console.error('[Pi Auth] Pi object not available')
      return null
    }

    const scopes = ['username', 'payments']
    const user = await window.Pi.authenticate(scopes)

    if (user && user.username) {
      console.log(`[Pi Auth] Authenticated as: ${user.username}`)
      return user.username
    }

    return null
  } catch (error) {
    console.error('[Pi Auth] Authentication failed:', error)
    return null
  }
}

/**
 * Create a payment for a product purchase
 */
export async function createPiPayment(
  amount: number,
  config: PiPaymentConfig,
  callbacks: PiPaymentCallbacks
): Promise<string | null> {
  try {
    if (typeof window.Pi === 'undefined') {
      throw new Error('Pi object not available')
    }

    console.log(`[Pi Payment] Creating payment for ${amount} Pi...`)

    const paymentId = await window.Pi.createPayment(
      {
        amount,
        memo: config.memo,
        metadata: config.metadata,
      },
      {
        onReadyForServerApproval: async (payment: any) => {
          console.log(`[Pi Payment] Ready for server approval: ${payment.identifier}`)
          paymentStates.set(payment.identifier, {
            paymentId: payment.identifier,
            status: 'approved',
            amount,
            productId: config.metadata.productId,
            category: config.metadata.category,
            timestamp: Date.now(),
          })
          await callbacks.onReadyForServerApproval(payment.identifier)
        },
        onReadyForServerCompletion: async (payment: any) => {
          console.log(`[Pi Payment] Ready for server completion: ${payment.identifier}`)
          const state = paymentStates.get(payment.identifier)
          if (state) {
            state.status = 'completed'
          }
          await callbacks.onReadyForServerCompletion(payment.identifier)
        },
        onCancel: (payment: any) => {
          console.log(`[Pi Payment] User cancelled payment: ${payment.identifier}`)
          paymentStates.delete(payment.identifier)
          callbacks.onCancel(payment.identifier)
        },
        onError: (error: any, payment: any) => {
          console.error(`[Pi Payment] Error: ${error.message}`)
          paymentStates.delete(payment.identifier)
          callbacks.onError(new Error(error.message), payment.identifier)
        },
      }
    )

    console.log(`[Pi Payment] Payment created: ${paymentId}`)
    return paymentId
  } catch (error) {
    console.error('[Pi Payment] Creation failed:', error)
    callbacks.onError(error instanceof Error ? error : new Error(String(error)))
    return null
  }
}

/**
 * Approve payment on backend
 */
export async function approvePaymentOnBackend(paymentId: string): Promise<boolean> {
  try {
    console.log(`[Pi Backend] Approving payment: ${paymentId}`)

    const response = await fetch('/api/payments/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentId }),
    })

    if (!response.ok) {
      throw new Error(`Backend approval failed: ${response.statusText}`)
    }

    const data = await response.json()
    console.log('[Pi Backend] Approval successful:', data)
    return true
  } catch (error) {
    console.error('[Pi Backend] Approval failed:', error)
    return false
  }
}

/**
 * Complete payment on backend
 */
export async function completePaymentOnBackend(paymentId: string): Promise<boolean> {
  try {
    console.log(`[Pi Backend] Completing payment: ${paymentId}`)

    const response = await fetch('/api/payments/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentId }),
    })

    if (!response.ok) {
      throw new Error(`Backend completion failed: ${response.statusText}`)
    }

    const data = await response.json()
    console.log('[Pi Backend] Completion successful:', data)
    return true
  } catch (error) {
    console.error('[Pi Backend] Completion failed:', error)
    return false
  }
}

/**
 * Get stored payment state
 */
export function getPaymentState(paymentId: string): PaymentState | undefined {
  return paymentStates.get(paymentId)
}

/**
 * Get all payment states
 */
export function getAllPaymentStates(): PaymentState[] {
  return Array.from(paymentStates.values())
}

/**
 * Clear old payment states
 */
export function clearOldPaymentStates(olderThanMs: number = 3600000): void {
  const now = Date.now()
  for (const [id, state] of paymentStates.entries()) {
    if (now - state.timestamp > olderThanMs) {
      paymentStates.delete(id)
    }
  }
}
