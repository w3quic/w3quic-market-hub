'use client'

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import {
  Listing,
  MarketplaceOrder,
  MarketplaceSeller,
  Conversation,
  UserFavorite,
  MarketplaceReview,
} from '@/lib/w3quic-types'

interface W3QuicContextType {
  // Auth
  piUsername: string | null
  loading: boolean
  error: string | null
  setPiUsername: (username: string | null) => void
  
  // Listings
  listings: Listing[]
  addListing: (listing: Listing) => void
  getListing: (id: string) => Listing | undefined
  searchListings: (query: string, category?: string) => Listing[]
  
  // Orders
  orders: MarketplaceOrder[]
  createOrder: (order: MarketplaceOrder) => void
  getOrdersByBuyer: (buyerId: string) => MarketplaceOrder[]
  getOrdersBySeller: (sellerId: string) => MarketplaceOrder[]
  
  // Sellers
  sellers: Map<string, MarketplaceSeller>
  addSeller: (seller: MarketplaceSeller) => void
  getSeller: (id: string) => MarketplaceSeller | undefined
  
  // Favorites
  favorites: UserFavorite[]
  addFavorite: (listingId: string) => void
  removeFavorite: (listingId: string) => void
  isFavorited: (listingId: string) => boolean
  
  // Reviews
  reviews: MarketplaceReview[]
  addReview: (review: MarketplaceReview) => void
  getReviewsByProduct: (listingId: string) => MarketplaceReview[]
  
  // Conversations
  conversations: Conversation[]
  createConversation: (conversation: Conversation) => void
  getConversation: (id: string) => Conversation | undefined
}

const W3QuicContext = createContext<W3QuicContextType | undefined>(undefined)

export function W3QuicProvider({ children }: { children: ReactNode }) {
  const [piUsername, setPiUsername] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [listings, setListings] = useState<Listing[]>([])
  const [orders, setOrders] = useState<MarketplaceOrder[]>([])
  const [sellers, setSellers] = useState<Map<string, MarketplaceSeller>>(new Map())
  const [favorites, setFavorites] = useState<UserFavorite[]>([])
  const [reviews, setReviews] = useState<MarketplaceReview[]>([])
  const [conversations, setConversations] = useState<Conversation[]>([])

  // Initialize with seed data
  useEffect(() => {
    // Seed some sample listings for demonstration
    const seedListings: Listing[] = [
      {
        id: '1',
        sellerId: 'seller1',
        sellerUsername: 'john_seller',
        title: 'MacBook Pro 16" 2023',
        description: 'Excellent condition, barely used MacBook Pro',
        category: 'products',
        priceInPi: 150,
        images: ['/placeholder.jpg'],
        condition: 'like-new',
        stock: 1,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 42,
        featured: true,
      },
      {
        id: '2',
        sellerId: 'seller2',
        sellerUsername: 'service_pro',
        title: 'Web Development Services',
        description: 'Full-stack web development for your business',
        category: 'services',
        serviceType: 'development',
        availability: 'available',
        priceInPi: 50,
        images: ['/placeholder.jpg'],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 28,
        featured: false,
      },
      {
        id: '3',
        sellerId: 'seller3',
        sellerUsername: 'job_poster',
        title: 'React Developer Needed',
        description: 'Looking for experienced React developer for 3-month project',
        category: 'jobs',
        jobType: 'contract',
        salaryInPi: 100,
        priceInPi: 100,
        images: ['/placeholder.jpg'],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 15,
        featured: false,
      },
      {
        id: '4',
        sellerId: 'seller4',
        sellerUsername: 'car_dealer',
        title: '2018 Honda Civic',
        description: 'Well-maintained Honda Civic with low mileage',
        category: 'vehicles',
        vehicleType: 'sedan',
        year: 2018,
        mileage: 45000,
        location: 'San Francisco, CA',
        priceInPi: 250,
        images: ['/placeholder.jpg'],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 89,
        featured: true,
      },
      {
        id: '5',
        sellerId: 'seller5',
        sellerUsername: 'realtor',
        title: 'Modern 3BR Home in Downtown',
        description: 'Beautiful modern home in prime location',
        category: 'real-estate',
        propertyType: 'house',
        bedrooms: 3,
        bathrooms: 2,
        squareFeet: 2500,
        location: 'Austin, TX',
        priceInPi: 1000,
        images: ['/placeholder.jpg'],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        views: 156,
        featured: true,
      },
    ]

    setListings(seedListings)

    // Seed sellers
    const seedSellers: MarketplaceSeller[] = [
      { id: 'seller1', username: 'john_seller', displayName: 'John Smith', rating: 4.8, ratingCount: 127, totalSales: 342, joinedAt: Date.now() - 31536000000, verified: true },
      { id: 'seller2', username: 'service_pro', displayName: 'Service Pro', rating: 4.9, ratingCount: 89, totalSales: 156, joinedAt: Date.now() - 31536000000, verified: true },
      { id: 'seller3', username: 'job_poster', displayName: 'Job Poster', rating: 4.7, ratingCount: 34, totalSales: 67, joinedAt: Date.now() - 15768000000, verified: false },
      { id: 'seller4', username: 'car_dealer', displayName: 'Car Dealer', rating: 4.6, ratingCount: 178, totalSales: 412, joinedAt: Date.now() - 47304000000, verified: true },
      { id: 'seller5', username: 'realtor', displayName: 'Real Estate Pro', rating: 4.9, ratingCount: 203, totalSales: 578, joinedAt: Date.now() - 63072000000, verified: true },
    ]

    const sellersMap = new Map(seedSellers.map(s => [s.id, s]))
    setSellers(sellersMap)
  }, [])

  const value: W3QuicContextType = {
    piUsername,
    loading,
    error,
    setPiUsername,
    listings,
    addListing: (listing) => setListings(prev => [...prev, listing]),
    getListing: (id) => listings.find(l => l.id === id),
    searchListings: (query, category) => {
      return listings.filter(l => {
        const matchesQuery = l.title.toLowerCase().includes(query.toLowerCase()) ||
                           l.description.toLowerCase().includes(query.toLowerCase())
        const matchesCategory = !category || l.category === category
        return matchesQuery && matchesCategory
      })
    },
    orders,
    createOrder: (order) => setOrders(prev => [...prev, order]),
    getOrdersByBuyer: (buyerId) => orders.filter(o => o.buyerId === buyerId),
    getOrdersBySeller: (sellerId) => orders.filter(o => o.sellerId === sellerId),
    sellers,
    addSeller: (seller) => setSellers(prev => new Map(prev).set(seller.id, seller)),
    getSeller: (id) => sellers.get(id),
    favorites,
    addFavorite: (listingId) => {
      if (!piUsername) return
      setFavorites(prev => [...prev, { id: `fav-${Date.now()}`, userId: piUsername, listingId, createdAt: Date.now() }])
    },
    removeFavorite: (listingId) => {
      setFavorites(prev => prev.filter(f => f.listingId !== listingId))
    },
    isFavorited: (listingId) => favorites.some(f => f.listingId === listingId),
    reviews,
    addReview: (review) => setReviews(prev => [...prev, review]),
    getReviewsByProduct: (listingId) => reviews.filter(r => r.orderId === listingId),
    conversations,
    createConversation: (conversation) => setConversations(prev => [...prev, conversation]),
    getConversation: (id) => conversations.find(c => c.id === id),
  }

  return (
    <W3QuicContext.Provider value={value}>
      {children}
    </W3QuicContext.Provider>
  )
}

export function useW3Quic() {
  const context = useContext(W3QuicContext)
  if (context === undefined) {
    throw new Error('useW3Quic must be used within W3QuicProvider')
  }
  return context
}
